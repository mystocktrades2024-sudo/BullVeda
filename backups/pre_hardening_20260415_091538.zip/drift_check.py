#!/usr/bin/env python3
"""AI-17: Live-vs-backtest drift alerter.

Compares live win-rate (from tracker history) against backtested WR
(config._meta.last_backtest_wr). Reports overall + per-setup deltas.
Designed to run weekly via launchd/cron; prints a summary and writes
cache/drift_report.json. If drift > threshold, also flags to stdout
with a clear WARN banner so email/cron wrappers can surface it.

Usage:
  python3 drift_check.py                # just summarize
  python3 drift_check.py --slack        # also POST to SLACK_WEBHOOK_URL
  python3 drift_check.py --min-trades 20 --drift-threshold 15
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

_ROOT = Path(__file__).parent


def _load_backtest_wr() -> float | None:
    try:
        cfg = json.loads((_ROOT / "config" / "config.json").read_text())
        val = cfg.get("_meta", {}).get("last_backtest_wr")
        if isinstance(val, (int, float)):
            return float(val) * 100
    except Exception:
        pass
    return None


def _compute_live_stats(min_trades: int):
    try:
        from tracker import compute_stats
        return compute_stats(min_trades=min_trades)
    except Exception as e:
        return {"error": str(e), "sufficient_data": False}


def _per_setup_stats() -> dict:
    """Bucket history by setup_type."""
    try:
        from tracker import _load_history
        h = _load_history()
        trades = h.get("trades", [])
    except Exception:
        return {}
    buckets: dict[str, list] = {}
    for t in trades:
        st = t.get("setup_type") or "Unknown"
        buckets.setdefault(st, []).append(t)
    out = {}
    for st, items in buckets.items():
        if len(items) < 3:
            continue
        wins = sum(1 for t in items if t.get("win"))
        n = len(items)
        try:
            from tracker import wilson_ci as _wci
            lo, hi = _wci(wins, n, 0.95)
            ci_lo_pct = round(lo * 100, 1)
            ci_hi_pct = round(hi * 100, 1)
            ci_width = round((hi - lo) * 100, 1)
        except Exception:
            ci_lo_pct, ci_hi_pct, ci_width = 0.0, 100.0, 100.0
        out[st] = {
            "trades": n,
            "wins": wins,
            "win_rate": round(wins / n * 100, 1),
            # Audit #8 — Wilson CI fields
            "wr_low_95":  ci_lo_pct,
            "wr_high_95": ci_hi_pct,
            "ci_width_pp": ci_width,
        }
    return out


def _post_slack(msg: str) -> None:
    """Post a message to Slack webhook if SLACK_WEBHOOK_URL is set."""
    try:
        from secrets_loader import get_secret
        url = get_secret("SLACK_WEBHOOK_URL", default="")
    except Exception:
        url = os.environ.get("SLACK_WEBHOOK_URL", "")
    if not url:
        print("[slack] SLACK_WEBHOOK_URL not set — skipping")
        return
    try:
        import urllib.request
        data = json.dumps({"text": msg}).encode()
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=10)
        print("[slack] posted")
    except Exception as e:
        print(f"[slack] error: {e}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--min-trades", type=int, default=10,
                    help="Minimum trades before reporting (default 10)")
    ap.add_argument("--drift-threshold", type=float, default=15.0,
                    help="WR drift pts (positive abs) to trigger WARN (default 15)")
    ap.add_argument("--min-alert-n", type=int, default=30,
                    help="Audit #8: per-setup min trades before drift alert (default 30)")
    ap.add_argument("--slack", action="store_true", help="Post to Slack on WARN")
    args = ap.parse_args()

    bt_wr = _load_backtest_wr()
    stats = _compute_live_stats(args.min_trades)
    per_setup = _per_setup_stats()

    report = {
        "as_of": datetime.now().isoformat(timespec="seconds"),
        "backtest_wr": bt_wr,
        "live": stats,
        "by_setup": per_setup,
        "alerts": [],
    }

    print("=" * 72)
    print("SwingTrade Drift Check")
    print("=" * 72)
    print(f"Backtest WR baseline: {bt_wr:.1f}%" if bt_wr is not None else "Backtest WR: unknown (config._meta.last_backtest_wr missing)")

    if not stats.get("sufficient_data"):
        msg = f"Insufficient trade data — need {args.min_trades}+ (have {stats.get('total_trades', 0)})"
        print(msg)
        report["alerts"].append({"level": "INFO", "msg": msg})
    else:
        live_wr = stats.get("win_rate", 0)
        print(f"Live WR ({stats.get('total_trades')} trades): {live_wr:.1f}%")
        if bt_wr is not None:
            delta = live_wr - bt_wr
            abs_delta = abs(delta)
            level = "OK" if abs_delta <= 5 else ("WATCH" if abs_delta <= args.drift_threshold else "WARN")
            marker = "✓" if level == "OK" else ("!" if level == "WATCH" else "🔴")
            msg = f"{marker} Delta vs backtest: {delta:+.1f} pts [{level}]"
            print(msg)
            if level == "WARN":
                report["alerts"].append({"level": "WARN", "msg": msg, "delta": delta})

        # per-direction
        bd = stats.get("by_direction", {})
        if bd:
            print("\nBy direction:")
            for direction in ("long", "short"):
                d = bd.get(direction, {})
                if d.get("trades", 0) >= 3:
                    print(f"  {direction:5s}: {d.get('trades', 0)} trades · WR {d.get('win_rate', 0):.1f}% · PF {d.get('profit_factor', 0):.2f}")

        if per_setup:
            print("\nBy setup (min 3 trades):")
            for st, s in sorted(per_setup.items(), key=lambda kv: -kv[1]["trades"]):
                marker = ""
                ci_note = f" [CI {s.get('wr_low_95', 0):.0f}-{s.get('wr_high_95', 0):.0f}%]"
                if bt_wr is not None:
                    d = s["win_rate"] - bt_wr
                    n = s["trades"]
                    # Audit #8: only alert when sample size is meaningful AND
                    # backtest WR falls outside the live Wilson CI (i.e. the
                    # delta exceeds statistical noise).
                    outside_ci = not (s.get("wr_low_95", 0) <= bt_wr <= s.get("wr_high_95", 100))
                    if abs(d) > args.drift_threshold and n >= args.min_alert_n and outside_ci:
                        marker = f" ← DRIFT {d:+.0f}"
                        report["alerts"].append({
                            "level": "WARN", "setup": st,
                            "msg": f"{st} drifted {d:+.0f} pts (n={n}, CI {s.get('wr_low_95',0):.0f}-{s.get('wr_high_95',0):.0f}%)",
                            "delta": d, "n": n,
                            "wr_low_95": s.get("wr_low_95"), "wr_high_95": s.get("wr_high_95"),
                        })
                    elif abs(d) > args.drift_threshold:
                        # Drift present but below statistical confidence — note, don't alert
                        reason = "n<min" if n < args.min_alert_n else "within CI"
                        marker = f" ← drift {d:+.0f} (muted: {reason})"
                print(f"  {st:24s}: {s['trades']:3d} trades · WR {s['win_rate']:.1f}%{ci_note}{marker}")

    # Persist report
    out_path = _ROOT / "cache" / "drift_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2, default=str))
    print(f"\nReport written to {out_path}")

    # Slack notification for WARN-level alerts
    warn_alerts = [a for a in report["alerts"] if a["level"] == "WARN"]
    if warn_alerts and args.slack:
        lines = ["*SwingTrade drift alert*"] + [f"• {a['msg']}" for a in warn_alerts]
        _post_slack("\n".join(lines))

    return 1 if warn_alerts else 0


if __name__ == "__main__":
    sys.exit(main())
