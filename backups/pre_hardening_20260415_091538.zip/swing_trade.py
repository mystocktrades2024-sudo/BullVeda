"""
SwingTrade — Rules-Based Swing Trading Agent
Main orchestrator: runs the full pipeline from universe building to HTML output.

Usage:
    python3 swing_trade.py                    # Full daily scan
    python3 swing_trade.py deep NVDA          # Deep dive on one ticker
    python3 swing_trade.py history             # Show performance stats
"""

from __future__ import annotations

import json
import logging
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

import pandas as pd
import yfinance as yf

from social_signals import get_social_signals
from data_fetcher import (
    load_config, get_sp500, get_russell1000, fetch_all_zacks_data,
    fetch_market_data, get_stock_info, get_stock_info_batch,
    get_market_regime, get_earnings_date, get_news_sentiment,
    get_insider_activity, get_analyst_data, get_tv_ratings_batch,
    get_stocktwits_data, get_sector_etf_data, get_weekly_data,
    get_options_iv_data, get_earnings_beat_rate,
    get_macro_signals, get_market_breadth, get_extra_fundamentals,
    get_fear_greed, get_congressional_trades, get_reddit_wsb,
    get_live_price, get_unusual_options, get_borrow_rate,
    get_quarterly_revenue_growth,
    get_finnhub_data, get_fmp_data, get_sec_filings,
    get_premarket_volume, get_institutional_trend,
    get_gamma_squeeze_data, get_earnings_estimate_trend,
    get_finviz_bulk, get_finviz_news,
    get_polygon_snapshot, get_polygon_news, get_polygon_options_chain,
    get_finviz_options,
    _TV_EXCHANGE_MAP,
)
from analysis import analyze_ticker, raw_value_score, raw_growth_score, raw_momentum_score
from html_generator import build_dashboard
from tracker import (record_run, evaluate_pending, compute_stats, get_full_history,
                     mark_to_market, compute_stats_by_setup)
from portfolio_tracker import refresh_prices, get_portfolio_summary
from gmail_zacks import fetch_zacks_emails, get_zacks_email_bonus
from alerts import send_scan_alerts
from email_report import send_dashboard_email
from crypto_screener import run_crypto_scan

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    datefmt="%H:%M:%S"
)
log = logging.getLogger("swingtrade")

BASE_DIR = Path(__file__).parent


def _check_connectivity() -> tuple[bool, list[str]]:
    """Verify critical endpoints resolve before scan starts.

    Returns (all_ok, failure_messages). Does NOT abort on failure — caller
    decides whether to enable degraded mode. Uses a 3-second DNS timeout
    per host so total wall-clock stays < 10s even if all fail.
    """
    import socket
    endpoints = [
        ("api.polygon.io", 443),
        ("elite.finviz.com", 443),
        ("finnhub.io", 443),
    ]
    failures: list[str] = []
    _prev_timeout = socket.getdefaulttimeout()
    try:
        socket.setdefaulttimeout(3)
        for host, _port in endpoints:
            try:
                socket.gethostbyname(host)
            except socket.gaierror as e:
                failures.append(f"{host} DNS: {e}")
            except Exception as e:
                failures.append(f"{host}: {e}")
    finally:
        socket.setdefaulttimeout(_prev_timeout)
    return (len(failures) == 0, failures)


def _compute_portfolio_risk(results: list, market_data: dict, spy_close) -> dict:
    """
    Compute portfolio-level risk metrics from the scored results universe.

    Metrics:
    - sector_concentration: top-3 sectors by count + pct of total
    - beta_exposure: avg beta across BUY candidates (beta-adjusted net long exposure)
    - correlation_matrix: pairwise return correlations for BUY candidates (max 10)
    - max_drawdown_flags: any BUY candidates with >40% drawdown from ATH
    - gap_risk_flags: any BUY candidates with high gap risk
    """
    import numpy as np

    buy_results = [r for r in results if r.get("decision", {}).get("verdict") == "BUY"]

    # Sector concentration across all scored results (passed gate)
    sector_counts: dict[str, int] = {}
    for r in results:
        s = r.get("sector", "Unknown")
        sector_counts[s] = sector_counts.get(s, 0) + 1
    total = len(results) or 1
    sector_concentration = sorted(
        [{"sector": k, "count": v, "pct": round(v / total * 100, 1)}
         for k, v in sector_counts.items() if k and k != "Unknown"],
        key=lambda x: x["count"], reverse=True
    )

    # Beta-adjusted exposure for BUY candidates
    betas = []
    for r in buy_results:
        b = r.get("beta")
        try:
            betas.append(float(b))
        except (TypeError, ValueError):
            betas.append(1.0)  # assume market beta if unknown
    avg_beta = round(sum(betas) / len(betas), 2) if betas else None

    # Return correlations for BUY candidates (up to 10)
    correlation_matrix = []
    corr_tickers = [r["ticker"] for r in buy_results[:10] if r["ticker"] in market_data]
    if len(corr_tickers) >= 2 and spy_close is not None:
        try:
            returns = {}
            for t in corr_tickers:
                c = market_data[t]["Close"].squeeze()
                c.index = pd.to_datetime(c.index)
                spy_aligned = spy_close.reindex(c.index, method="nearest")
                # Use last 60 days
                rets = c.pct_change().tail(60).dropna()
                if len(rets) >= 20:
                    returns[t] = rets
            if len(returns) >= 2:
                df_ret = pd.DataFrame(returns).dropna(how="any")
                corr = df_ret.corr().round(2)
                # Convert to list of {t1, t2, corr} pairs (upper triangle only)
                tks = list(corr.columns)
                for i in range(len(tks)):
                    for j in range(i + 1, len(tks)):
                        v = float(corr.iloc[i, j])
                        if not np.isnan(v):
                            correlation_matrix.append({
                                "t1": tks[i], "t2": tks[j], "corr": v,
                                "level": "high" if v > 0.7 else ("med" if v > 0.4 else "low"),
                            })
                correlation_matrix.sort(key=lambda x: abs(x["corr"]), reverse=True)
        except Exception as e:
            log.debug(f"Correlation matrix computation failed: {e}")

    # Flag BUY candidates with high drawdown or gap risk
    drawdown_flags = []
    gap_flags = []
    for r in buy_results:
        dd = r.get("gate", {}).get("drawdown_from_ath")
        if dd is not None and dd > 40:
            drawdown_flags.append({"ticker": r["ticker"], "drawdown_pct": dd})
        gr = r.get("gate", {}).get("gap_risk", {})
        if gr.get("level") == "high":
            gap_flags.append({
                "ticker": r["ticker"],
                "large_gaps_20d": gr.get("large_gaps_20d"),
                "avg_gap_pct": gr.get("avg_gap_pct"),
            })

    return {
        "sector_concentration": sector_concentration[:10],
        "avg_beta": avg_beta,
        "beta_count": len(betas),
        "correlation_matrix": correlation_matrix[:20],
        "drawdown_flags": drawdown_flags,
        "gap_flags": gap_flags,
    }


def _vgm_verdict(score: float, rr: float, vgm: str, growth: str) -> str:
    """Derive VGM verdict from score + grades."""
    if vgm == "A" and score >= 75 and rr >= 3.0:
        return "Strong Buy"
    elif vgm in ("A", "B") and score >= 65 and rr >= 3.0:
        return "Buy"
    elif vgm in ("A", "B") and score >= 55:
        return "Watch"
    elif vgm == "C" and score >= 60:
        return "Watch"
    elif vgm in ("D", "F") or score < 50:
        return "Avoid"
    else:
        return "Watch"


def assign_vgm_grades(results: list[dict]) -> list[dict]:
    """Percentile-rank V/G/M scores across scanned universe. Assigns letter grades + VGM composite."""
    import numpy as np

    def percentile_grade(score, all_scores):
        if not all_scores or score is None:
            return "N/A"
        arr = np.array([s for s in all_scores if s is not None])
        if len(arr) == 0:
            return "N/A"
        pct = float(np.sum(arr <= score)) / len(arr) * 100
        if pct >= 80: return "A"
        elif pct >= 60: return "B"
        elif pct >= 40: return "C"
        elif pct >= 20: return "D"
        else: return "F"

    v_scores = [r.get("raw_value_score") for r in results if r.get("raw_value_score") is not None]
    g_scores = [r.get("raw_growth_score") for r in results if r.get("raw_growth_score") is not None]
    m_scores = [r.get("raw_momentum_score") for r in results if r.get("raw_momentum_score") is not None]

    # Pre-compute VGM composite raw scores for all tickers (needed for percentile ranking)
    all_vgm_raws = []
    for r in results:
        c2 = []
        tw2 = 0.0
        if r.get("raw_value_score") is not None:
            c2.append(r["raw_value_score"] * 0.30); tw2 += 0.30
        if r.get("raw_growth_score") is not None:
            c2.append(r["raw_growth_score"] * 0.40); tw2 += 0.40
        if r.get("raw_momentum_score") is not None:
            c2.append(r["raw_momentum_score"] * 0.30); tw2 += 0.30
        all_vgm_raws.append(sum(c2) / tw2 if tw2 > 0 else None)

    for i, r in enumerate(results):
        v_raw = r.get("raw_value_score")
        g_raw = r.get("raw_growth_score")
        m_raw = r.get("raw_momentum_score")

        r["grade_value"]    = percentile_grade(v_raw, v_scores)
        r["grade_growth"]   = percentile_grade(g_raw, g_scores)
        r["grade_momentum"] = percentile_grade(m_raw, m_scores)

        vgm_raw = all_vgm_raws[i]
        if vgm_raw is not None:
            r["grade_vgm"] = percentile_grade(vgm_raw, [x for x in all_vgm_raws if x is not None])
        else:
            r["grade_vgm"] = "N/A"

        # VGM verdict
        score = r.get("score", 0)
        rr = r.get("plan", {}).get("rr_ratio", 0) if isinstance(r.get("plan"), dict) else 0
        # Also try trade_plan key (used in analyze_ticker result dict)
        if rr == 0:
            rr = r.get("trade_plan", {}).get("rr_ratio", 0) if isinstance(r.get("trade_plan"), dict) else 0
        r["vgm_verdict"] = _vgm_verdict(score, rr, r["grade_vgm"], r.get("grade_growth", "N/A"))

    return results


def run_daily_scan(force_fresh: bool = False):
    """Full daily scan pipeline."""
    cfg = load_config()
    run_date      = datetime.now().strftime("%Y-%m-%d")
    run_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    log.info(f"=== SwingTrade Daily Scan — {run_timestamp} ===")

    # Log rotation — compress >30d logs, delete >90d archives
    try:
        from log_rotation import rotate_logs
        rotate_logs()
    except Exception as e:
        log.debug(f"Log rotation failed: {e}")

    # Daily state backup — snapshot critical JSON state files (idempotent)
    try:
        from state_backup import backup_state
        backup_state()
    except Exception as e:
        log.debug(f"State backup failed: {e}")

    # Pre-scan connectivity check — detect DNS/network outages before they
    # silently kill ~35% of the universe. If any critical endpoint fails to
    # resolve, enable archive-first degraded mode (Fix #1 + #5).
    try:
        _conn_ok, _conn_issues = _check_connectivity()
        if not _conn_ok:
            log.error("Network connectivity check FAILED — scan may produce incomplete results:")
            for _issue in _conn_issues:
                log.error(f"   {_issue}")
            log.warning("Proceeding with DEGRADED MODE (archive-first failover). "
                        "Expect elevated killed-ticker count.")
            try:
                from data_fetcher import enable_degraded_mode as _edm
                _edm()
            except Exception as _edm_e:
                log.debug(f"Could not enable degraded mode: {_edm_e}")
            # Loud alert via Slack/Mac so operator sees it immediately
            try:
                from alerts import send_alert
                send_alert(
                    level="WARN",
                    title="Network connectivity degraded",
                    body=f"DNS/endpoint checks failed: {'; '.join(_conn_issues)}. "
                         f"Scan running in archive-first degraded mode.",
                )
            except Exception:
                pass
        else:
            log.info("  Connectivity check: all endpoints resolve ✓")
    except Exception as _conn_e:
        log.debug(f"Connectivity check skipped: {_conn_e}")

    # Startup config validator — surface issues early, fail-fast on 🔴 critical
    try:
        from config_validator import validate_config
        _cfg_issues = validate_config()
        if _cfg_issues:
            for _i in _cfg_issues:
                if _i.startswith("🔴"):
                    log.error(f"  Config: {_i}")
                else:
                    log.warning(f"  Config: {_i}")
    except Exception as _cve:
        log.debug(f"Config validation skipped: {_cve}")

    # Data freshness guard — abort if SPY OHLC is >48h stale (weekends OK: mon after fri = 72h)
    try:
        from data_fetcher import fetch_market_data as _fmd
        _spy_check = _fmd(["SPY"])
        _spy_df_check = _spy_check.get("SPY") if isinstance(_spy_check, dict) else None
        if _spy_df_check is not None and not _spy_df_check.empty:
            _last_bar = _spy_df_check.index[-1]
            _hours_stale = (datetime.now(_last_bar.tz) - _last_bar).total_seconds() / 3600 if getattr(_last_bar, "tz", None) else (datetime.now() - _last_bar.to_pydatetime()).total_seconds() / 3600
            _wd = datetime.now().weekday()  # 0=Mon..6=Sun
            # Max acceptable staleness: 72h on Mon, 48h otherwise
            _max_stale = 72 if _wd == 0 else 48
            if _hours_stale > _max_stale:
                log.error(f"  🔴 DATA FRESHNESS: SPY last bar is {_hours_stale:.0f}h old (max {_max_stale}h) — aborting scan, check Polygon")
                raise RuntimeError(f"Data >{_max_stale}h stale")
            else:
                log.info(f"  Data freshness: SPY last bar {_hours_stale:.1f}h old ✓")
    except RuntimeError:
        raise
    except Exception as _dfe:
        log.debug(f"Data freshness check skipped: {_dfe}")

    # Step 0: Evaluate any pending trades from prior runs
    evaluated = evaluate_pending(hold_days=5)
    if evaluated:
        log.info(f"Auto-evaluated {evaluated} pending trades")

    # Step 1: Build universe + fetch all Zacks premium data in one browser session
    log.info("Step 1: Building universe + fetching Zacks premium data...")
    sp500 = get_sp500()
    log.info(f"  S&P 500: {len(sp500)} tickers")
    if len(sp500) < 200:
        log.error(f"S&P 500 returned only {len(sp500)} tickers — universe too small, aborting scan")
        return

    universe_cfg = cfg.get("universe", {})
    include_r1000 = universe_cfg.get("include_russell1000", False)
    russell1000 = []
    if include_r1000:
        russell1000 = get_russell1000()
        log.info(f"  Russell 1000: {len(russell1000)} tickers")

    creds_path = cfg.get("zacks_credentials", "")
    full_creds = str(BASE_DIR / creds_path) if not Path(creds_path).is_absolute() else creds_path
    zacks_data = fetch_all_zacks_data(full_creds, force_fresh=force_fresh)
    if zacks_data.get("error"):
        log.warning(f"  Zacks premium: {zacks_data['error']}")
    zacks_r1        = zacks_data.get("zacks_r1", [])
    zacks_r1_scores = zacks_data.get("zacks_r1_scores", {})
    ultimate_data = {
        "overview":      zacks_data.get("ultimate_overview", {}),
        "all_trades":    zacks_data.get("ultimate_all_trades", []),
        "commentary":    zacks_data.get("ultimate_commentary", []),
        "special_reports": zacks_data.get("ultimate_special_reports", []),
        "confidential_commentary": zacks_data.get("confidential_commentary", []),
        "confidential_overview": zacks_data.get("confidential_overview", {}),
        "error":         zacks_data.get("error"),
    }
    tazr_data = {
        "trades":          zacks_data.get("tazr_trades", []),
        "portfolio_stats": zacks_data.get("tazr_portfolio_stats", {}),
        "commentary":      zacks_data.get("tazr_commentary", []),
        "error":           zacks_data.get("error"),
    }

    # Build premium portfolio dicts — all share same structure
    def _build_port(prefix):
        return {
            "trades":          zacks_data.get(f"{prefix}_trades", []),
            "portfolio_stats": zacks_data.get(f"{prefix}_portfolio_stats", {}),
            "commentary":      zacks_data.get(f"{prefix}_commentary", []),
            "error":           zacks_data.get("error"),
        }
    bbt_data          = _build_port("bbt")
    cs_data           = _build_port("counterstrike")
    ht_data           = _build_port("headlinetrader")
    alt_energy_data   = _build_port("alt_energy")
    blockchain_data   = _build_port("blockchain")
    tech_innov_data   = _build_port("tech_innovators")

    log.info(f"  Zacks #1: {len(zacks_r1)} tickers | "
             f"Ultimate: {len(ultimate_data['all_trades'])} open trades | "
             f"Confidential: {len(ultimate_data['confidential_commentary'])} articles")

    # Build universe
    custom = universe_cfg.get("custom_watchlist", [])
    zacks_rank1_only = universe_cfg.get("zacks_rank1_only", False)
    sp500_set    = set(sp500)
    r1000_set    = set(russell1000)
    zacks_r1_set = set(zacks_r1)
    zacks_sell_set = {
        (t["ticker"] if isinstance(t, dict) else t).upper()
        for t in zacks_data.get("zacks_sell_list", [])
        if t
    }
    log.info(f"  Zacks Sell List: {len(zacks_sell_set)} tickers tagged for SHORT priority")

    # Fix #17: Track source for each ticker (first source wins for overlaps)
    ticker_sources: dict[str, str] = {}
    leveraged_set = set(universe_cfg.get("leveraged_watchlist", []))

    if zacks_rank1_only and zacks_r1:
        # Narrow/fast mode: Zacks Rank #1 + custom watchlist
        # Russell 1000 Rank #1 stocks are already inside zacks_r1_set (Zacks ranks all US stocks)
        universe = list(zacks_r1_set | set(custom))
        for t in zacks_r1_set:
            ticker_sources[t] = "zacks_rank1"
        for t in custom:
            ticker_sources.setdefault(t, "custom")
        log.info(f"  Universe (Zacks #1 mode): {len(universe)} "
                 f"(Zacks #1={len(zacks_r1)}, Russell 1000 R#1 included above, custom={len(custom)})")
    else:
        # Full mode: S&P 500 + Russell 1000 (if enabled) + Zacks #1 + custom
        base_set = sp500_set | r1000_set | zacks_r1_set | set(custom)
        universe = list(base_set)
        for t in sp500_set:
            ticker_sources[t] = "sp500"
        for t in r1000_set:
            ticker_sources.setdefault(t, "russell1000")
        for t in zacks_r1_set:
            ticker_sources.setdefault(t, "zacks_rank1")
        for t in custom:
            ticker_sources.setdefault(t, "custom")
        log.info(f"  Universe: {len(universe)} "
                 f"(S&P 500={len(sp500)}, Russell 1000={len(russell1000)}, "
                 f"Zacks #1={len(zacks_r1)}, custom={len(custom)})")

    # Add Zacks premium service tickers to universe
    universe_set = set(universe)
    for svc_data in [tazr_data, bbt_data, cs_data, ht_data, alt_energy_data, blockchain_data, tech_innov_data]:
        for trade in svc_data.get("trades", []):
            t = trade.get("ticker", "").upper().strip()
            if t and t not in universe_set:
                universe.append(t)
                universe_set.add(t)
                ticker_sources[t] = "zacks_premium"

    # Tag leveraged ETFs
    for t in leveraged_set:
        ticker_sources[t] = "leveraged"

    universe = list(dict.fromkeys(universe))  # Dedupe

    # Step 2: Fetch market data + macro context
    log.info("Step 2: Fetching market data...")
    market_data = fetch_market_data(universe, period="1y")
    fill_rate = len(market_data) / len(universe) if universe else 0
    log.info(f"  Got data for {len(market_data)} tickers ({fill_rate:.0%} fill rate)")
    if fill_rate < 0.5:
        log.error(f"Market data fill rate critical ({fill_rate:.0%}) — aborting scan to avoid garbage results")
        return
    if fill_rate < 0.7:
        log.warning(f"Market data fill rate low ({fill_rate:.0%}) — results may be incomplete")

    # Market breadth (uses already-downloaded market_data — no extra download)
    market_breadth = get_market_breadth(market_data)
    log.info(f"  Market breadth: {market_breadth['pct_above_50d']:.0f}% above 50d "
             f"({market_breadth['label_50']}) | "
             f"{market_breadth['pct_above_100d']:.0f}% above 100d ({market_breadth['label_100']})")

    # Get SPY data for relative strength — Polygon primary, yfinance fallback
    from data_fetcher import get_polygon_ohlcv as _gpo
    spy_data = _gpo("SPY", days=365, timespan="day")
    if spy_data is None or spy_data.empty or len(spy_data) < 50:
        spy_data = yf.download("SPY", period="1y", interval="1d", progress=False, auto_adjust=True)
    spy_close = spy_data["Close"].squeeze().dropna() if spy_data is not None and not spy_data.empty else None
    if spy_close is None or len(spy_close) == 0:
        log.warning("  SPY data unavailable — relative strength scores will default to neutral (50)")
        spy_close = None

    # Get market regime (includes VIX + 4-regime classification)
    regime = get_market_regime(breadth=market_breadth)
    vix = regime.get("vix", {})
    vix_cur = regime.get("vix_current", vix.get("vix_current", 20))
    regime4 = regime.get("regime4", "unknown")
    log.info(f"  Market regime: {regime['regime'].upper()} | Regime4: {regime4} | "
             f"(SPY ${regime['spy_price']}) | "
             f"VIX {vix_cur} ({vix.get('regime','?')}) | "
             f"Breadth: {regime.get('breadth_pct_50d', 50):.0f}% above 50d | "
             f"Cycle: {regime.get('market_cycle','?')} | "
             f"SPY today: {regime.get('spy_daily_chg', 0):+.1f}% | "
             f"Dist days: {regime.get('distribution_days', 0)}")

    # Regime transition auto-exit (Risk Controls A+): shrink exposure when regime
    # flips to risk-off/panic. Done before scan to influence sizing this run.
    try:
        import json as _json_rae
        from pathlib import Path as _Path_rae
        _rae_fp = BASE_DIR / "cache" / "regime_last_seen.json"
        _prev_r4 = None
        if _rae_fp.exists():
            _prev_r4 = _json_rae.loads(_rae_fp.read_text()).get("regime4")
        _risk_off_regimes = ("risk_off_trending", "panic")
        # Flipping INTO risk-off: reduce all open position sizes
        if _prev_r4 and _prev_r4 not in _risk_off_regimes and regime4 in _risk_off_regimes:
            from portfolio_tracker import runner_protection_trim, flat_position_exits
            _forced_trims = runner_protection_trim(max_position_pct=10.0, trim_to_pct=5.0)
            if _forced_trims:
                log.warning(f"  🔴 REGIME AUTO-EXIT: risk-off flip ({_prev_r4} → {regime4}) — {len(_forced_trims)} positions flagged for forced trim")
                for _t in _forced_trims:
                    log.warning(f"    TRIM {_t['ticker']}: {_t['current_pct']}% → {_t['target_pct']}% ({_t['shares_to_trim']} shares)")
    except Exception as _rae_e:
        log.debug(f"Regime auto-exit check failed (non-fatal): {_rae_e}")

    # Fix #27: Regime transition alert — diff against last persisted regime
    try:
        import json as _json_rt
        from pathlib import Path as _Path_rt
        _rt_fp = BASE_DIR / "cache" / "regime_last_seen.json"
        _prev_r = None
        _prev_r4 = None
        if _rt_fp.exists():
            _prev = _json_rt.loads(_rt_fp.read_text())
            _prev_r = _prev.get("regime")
            _prev_r4 = _prev.get("regime4")
        _cur_r = regime.get("regime", "unknown")
        if _prev_r and _prev_r != _cur_r:
            _msg = f"REGIME TRANSITION: {_prev_r.upper()} -> {_cur_r.upper()} (regime4: {_prev_r4} -> {regime4})"
            log.warning(_msg)
            try:
                import subprocess as _sp_rt
                _sp_rt.run(["osascript", "-e",
                            f'display notification "{_msg}" with title "SwingTrade Regime Change"'],
                           check=False, timeout=5)
            except Exception:
                pass
        elif _prev_r4 and _prev_r4 != regime4:
            _msg = f"Regime4 shift: {_prev_r4} -> {regime4} (top-level regime unchanged: {_cur_r})"
            log.info(_msg)
        _rt_fp.parent.mkdir(parents=True, exist_ok=True)
        _rt_fp.write_text(_json_rt.dumps({
            "regime": _cur_r, "regime4": regime4, "as_of": str(run_date) if "run_date" in dir() else None,
        }))
    except Exception as _rt_e:
        log.debug(f"Regime transition check failed: {_rt_e}")

    # AI-11: unified VIX mode resolver (single source of truth for tighten/kill/sizing)
    _vix_kill_active = False
    _vix_tighten_active = False
    _vix_mode_info = None
    try:
        import yfinance as _yf
        from analysis import resolve_vix_mode as _resolve_vix
        from data_fetcher import get_polygon_ohlcv as _gpo
        # Polygon primary: I:VIX index (10 days of daily bars), yfinance fallback
        _vix_hist = _gpo("I:VIX", days=10, timespan="day")
        if _vix_hist is None or _vix_hist.empty or len(_vix_hist) < 6:
            _vix_hist = _yf.download("^VIX", period="10d", interval="1d", progress=False, auto_adjust=True)
        _vix_today = None
        _vix_5d_avg = None
        if _vix_hist is not None and not _vix_hist.empty and len(_vix_hist) >= 6:
            _vix_series = _vix_hist["Close"].squeeze().dropna()
            _vix_today = float(_vix_series.iloc[-1])
            _vix_5d_avg = float(_vix_series.iloc[-6:-1].mean())
        _vix_mode_info = _resolve_vix(_vix_today or vix_cur, _vix_5d_avg, cfg)
        if _vix_mode_info["mode"] == "kill":
            _vix_kill_active = True
            log.warning(f"  VIX SPIKE KILL SWITCH: {_vix_mode_info['note']}")
        elif _vix_mode_info["mode"] == "tighten":
            _vix_tighten_active = True
            log.warning(f"  VIX TIGHTEN: {_vix_mode_info['note']}")
        else:
            log.info(f"  VIX mode: {_vix_mode_info['note']}")
    except Exception as _ve:
        log.debug(f"  VIX mode resolver failed (non-fatal): {_ve}")

    # Sector ETF rotation + macro signals (parallel)
    log.info("  Fetching sector ETF rotation + macro signals...")
    with ThreadPoolExecutor(max_workers=3) as _pool:
        _sector_fut  = _pool.submit(get_sector_etf_data, 63)
        _macro_fut   = _pool.submit(get_macro_signals)
        _fg_fut      = _pool.submit(get_fear_greed)
        sector_etf_data = _sector_fut.result()
        macro_signals   = _macro_fut.result()
        fear_greed_data = _fg_fut.result()
    log.info(f"  Fear & Greed: {fear_greed_data.get('value','?')} ({fear_greed_data.get('label','?')}) | "
             f"Yield curve: {macro_signals.get('yield_curve',{}).get('spread','?')} "
             f"({'inverted' if macro_signals.get('yield_curve',{}).get('inverted') else 'normal'})")
    if sector_etf_data:
        leaders = [(e, d["vs_spy_pct"]) for e, d in sector_etf_data.items()
                   if e != "SPY" and d.get("vs_spy_pct", 0) > 0]
        leaders.sort(key=lambda x: x[1], reverse=True)
        log.info(f"  Sector leaders: {', '.join(e for e, _ in leaders[:3])}")
    log.info(f"  Macro risk: {macro_signals.get('risk_signal', '?')} | "
             f"HYG {macro_signals.get('hyg', {}).get('trend', '?')} | "
             f"DXY {macro_signals.get('dxy', {}).get('trend', '?')}")

    # Step 3: Price/Volume filter
    log.info("Step 3: Applying price/volume filters...")
    min_price = cfg.get("filters", {}).get("min_price", 5)
    max_price = cfg.get("filters", {}).get("max_price", 100)
    min_dv = cfg.get("filters", {}).get("min_daily_dollar_volume", 10_000_000)

    qualified = {}
    # Track why each Zacks #1 ticker was excluded from analysis
    zacks_r1_missing: dict[str, str] = {}

    # Mark Zacks #1 tickers that got no market data at all
    for t in zacks_r1:
        if t not in market_data:
            zacks_r1_missing[t] = "No market data (Yahoo + tvDatafeed both failed)"

    # Detect if market is currently open (NYSE: Mon-Fri 9:30–16:00 ET)
    try:
        from zoneinfo import ZoneInfo
        _now_et = datetime.now(ZoneInfo("America/New_York"))
    except ImportError:
        import pytz
        _now_et = datetime.now(pytz.timezone("America/New_York"))
    _market_open = (_now_et.weekday() < 5 and
                    (9 * 60 + 30) <= (_now_et.hour * 60 + _now_et.minute) <= (16 * 60))

    # Pre-fetch live prices only for Zacks #1 tickers (high-value subset, not all 705)
    # Avoids 700+ serial yfinance calls during market hours
    _live_prices: dict[str, float] = {}
    if _market_open and zacks_r1_set:
        _live_targets = list(zacks_r1_set & set(market_data.keys()))
        with ThreadPoolExecutor(max_workers=16) as _lp_pool:
            _lp_futures = {_lp_pool.submit(get_live_price, t): t for t in _live_targets}
            for _fut in as_completed(_lp_futures):
                _t = _lp_futures[_fut]
                try:
                    _p = _fut.result(timeout=5)
                    if _p:
                        _live_prices[_t] = _p
                except Exception as _lpe:
                    log.debug(f"Live price fetch failed for {_t}: {_lpe}")

    for ticker, df in market_data.items():
        try:
            # Use last non-NaN close — intraday sessions leave today's close as NaN
            close_series = df["Close"].dropna()
            if close_series.empty:
                if ticker in zacks_r1_set:
                    zacks_r1_missing[ticker] = "No valid close price data"
                continue
            price = float(close_series.iloc[-1])
            # During market hours: use pre-fetched live quote for Zacks #1 tickers
            if _market_open and ticker in _live_prices:
                live = _live_prices[ticker]
                if abs(live - price) / price < 0.10:  # sanity: within 10%
                    price = live
            # Use last available volume (may include today's partial volume)
            vol_series = df["Volume"].dropna()
            vol = float(vol_series.iloc[-1]) if not vol_series.empty else 0.0
            avg_vol = float(df["Volume"].rolling(20).mean().dropna().iloc[-1]) if len(df) >= 20 else vol
            daily_dv = avg_vol * price

            if min_price <= price <= max_price and daily_dv >= min_dv:
                qualified[ticker] = df
            elif ticker in zacks_r1_set:
                # Record why this Zacks #1 stock was filtered out
                if price < min_price or price > max_price:
                    zacks_r1_missing[ticker] = f"Price ${price:.2f} outside ${min_price}–${max_price} range"
                else:
                    zacks_r1_missing[ticker] = (
                        f"Volume ${daily_dv/1e6:.1f}M/day below ${min_dv/1e6:.0f}M minimum"
                    )
        except Exception:
            if ticker in zacks_r1_set and ticker not in zacks_r1_missing:
                zacks_r1_missing[ticker] = "Data parse error"

    log.info(f"  Qualified: {len(qualified)} tickers")
    log.info(f"  Zacks #1 excluded before analysis: {len(zacks_r1_missing)}")
    total_scanned = len(market_data)

    # Step 3.5: Fast OHLCV pre-screen — reduce enrichment universe before any API calls
    # Scores every qualified ticker using only in-memory price/volume data (zero HTTP requests).
    # Keeps top N by score + all Zacks #1 tickers unconditionally.
    def _fast_prescreen_score(df: pd.DataFrame) -> float:
        try:
            close = df["Close"].dropna()
            if len(close) < 50:
                return 0.0
            vol = df["Volume"].dropna()
            price = float(close.iloc[-1])

            e8  = float(close.ewm(span=8,  adjust=False).mean().iloc[-1])
            e21 = float(close.ewm(span=21, adjust=False).mean().iloc[-1])
            e50 = float(close.ewm(span=50, adjust=False).mean().iloc[-1])

            score = 0.0

            # EMA stack: cleanly trending vs partial vs weak
            # Also detect pullbacks to rising 50 SMA (high RS stocks pulling back)
            sma50_10d = float(close.iloc[-60:-50].mean()) if len(close) >= 60 else e50
            sma50_rising = e50 > sma50_10d * 1.001

            if price > e8 > e21 > e50:
                score += 4.0
            elif price > e21 > e50:
                score += 2.0
            elif price > e50:
                score += 1.0
            elif price > e50 * 0.97 and sma50_rising:
                score += 2.5  # Pullback to rising 50 SMA — valid setup, don't cut
            elif price > e50 * 0.95 and sma50_rising:
                score += 1.5  # Deeper pullback but 50 SMA still rising

            # RSI: want 50-70 (bullish momentum, not extended)
            delta = close.diff()
            gain = delta.where(delta > 0, 0.0).ewm(com=13, adjust=False).mean()
            loss = (-delta.where(delta < 0, 0.0)).ewm(com=13, adjust=False).mean()
            loss_val = float(loss.iloc[-1])
            rsi = float(100 - 100 / (1 + float(gain.iloc[-1]) / loss_val)) if loss_val > 0 else 50.0
            if   50 <= rsi <= 70: score += 3.0
            elif 45 <= rsi <  50: score += 1.0
            elif rsi > 70:        score += 1.0  # extended — partial credit

            # Relative volume: accumulation signal
            if len(vol) >= 20:
                avg_vol = float(vol.rolling(20).mean().iloc[-1])
                rvol = float(vol.iloc[-1]) / max(avg_vol, 1)
                if   rvol >= 2.0: score += 2.0
                elif rvol >= 1.5: score += 1.0

            # 5-day momentum
            if len(close) >= 6:
                ret5 = (float(close.iloc[-1]) / float(close.iloc[-6]) - 1) * 100
                if   ret5 >= 3.0:  score += 1.0
                elif ret5 <= -5.0: score -= 2.0

            return round(min(10.0, max(0.0, score)), 1)
        except Exception:
            return 0.0

    _max_enrich = cfg.get("performance", {}).get("max_enrichment_tickers", 350)
    if len(qualified) > _max_enrich:
        _prescores      = {t: _fast_prescreen_score(df) for t, df in qualified.items()}
        _zr1_qualified  = [t for t in qualified if t in zacks_r1_set]
        _non_zr1_sorted = sorted(
            [(t, s) for t, s in _prescores.items() if t not in zacks_r1_set],
            key=lambda x: x[1], reverse=True
        )
        _slots          = max(0, _max_enrich - len(_zr1_qualified))
        _selected       = set(_zr1_qualified) | {t for t, _ in _non_zr1_sorted[:_slots]}
        qualified       = {t: df for t, df in qualified.items() if t in _selected}
        log.info(f"  Pre-screen: {len(_prescores)} → {len(qualified)} tickers "
                 f"({len(_zr1_qualified)} Zacks #1 guaranteed + "
                 f"{len(_selected) - len(_zr1_qualified)} top-ranked by OHLCV score)")
    else:
        log.info(f"  Pre-screen: {len(qualified)} tickers (under {_max_enrich} threshold, no cut)")

    # Step 4: Fetch fundamentals + enrichment for qualified tickers
    log.info("Step 4: Fetching fundamentals & enrichment...")
    tickers_to_analyze = list(qualified.keys())

    # Fetch info in parallel
    infos = get_stock_info_batch(tickers_to_analyze, max_workers=16)

    # Lazy weekly fetch: only needed for weekly EMA alignment (±2 pt bonus).
    # Pre-screen with a fast EMA trend check — skip tickers in clear downtrends.
    def _quick_is_trending(df):
        try:
            c = df["Close"].squeeze()
            if len(c) < 50:
                return False
            e21 = float(c.ewm(span=21, adjust=False).mean().iloc[-1])
            e50 = float(c.ewm(span=50, adjust=False).mean().iloc[-1])
            return float(c.iloc[-1]) > e50 and e21 > e50
        except Exception:
            return False

    weekly_candidates = [t for t in tickers_to_analyze if _quick_is_trending(qualified[t])]
    log.info(f"  Fetching weekly OHLCV (lazy: {len(weekly_candidates)}/{len(tickers_to_analyze)} trending)...")
    weekly_data = get_weekly_data(weekly_candidates)
    log.info(f"  Weekly data: {len(weekly_data)} tickers")

    # Fetch earnings, news, insider, analyst, StockTwits, options IV, beat rate,
    # congressional trades, and Reddit WSB all in parallel (congressional/WSB moved
    # out of per-ticker analysis thread to avoid N×serial API calls)
    earnings_data       = {}
    news_data           = {}
    insider_data        = {}
    analyst_data        = {}
    stocktwits_data     = {}
    options_iv_data     = {}
    beat_rate_data      = {}
    extra_fund_data     = {}
    congressional_data  = {}
    reddit_wsb_data     = {}
    uoa_data            = {}
    borrow_data         = {}
    finnhub_data        = {}
    fmp_data            = {}
    sec_data            = {}
    premarket_data      = {}
    inst_trend_data     = {}
    gamma_data          = {}
    eps_trend_data      = {}

    # FINVIZ bulk fetch — one call covers all tickers, must complete before per-ticker analysis
    log.info("  Fetching FINVIZ Elite bulk data (5 views)...")
    try:
        finviz_bulk = get_finviz_bulk()
        log.info(f"  FINVIZ bulk: {len(finviz_bulk)} tickers loaded")
    except Exception as _fvz_err:
        log.warning(f"  FINVIZ bulk failed: {_fvz_err}")
        finviz_bulk = {}

    # FINVIZ news — single call, used for market-wide news enrichment
    try:
        finviz_news_list = get_finviz_news()
        log.info(f"  FINVIZ news: {len(finviz_news_list)} articles")
    except Exception:
        finviz_news_list = []

    # Polygon bulk snapshot — 1 API call for all tickers (price, change, volume)
    log.info("  Fetching Polygon bulk snapshot...")
    try:
        polygon_snapshot = get_polygon_snapshot(tickers_to_analyze)
        log.info(f"  Polygon snapshot: {len(polygon_snapshot)} tickers")
    except Exception as _pe:
        log.warning(f"  Polygon snapshot failed: {_pe}")
        polygon_snapshot = {}

    polygon_news_data  = {}
    polygon_opts_data  = {}

    with ThreadPoolExecutor(max_workers=64) as pool:
        earn_futures        = {pool.submit(get_earnings_date,       t): t for t in tickers_to_analyze}
        news_futures        = {pool.submit(get_news_sentiment,      t): t for t in tickers_to_analyze}
        insider_futures     = {pool.submit(get_insider_activity,    t): t for t in tickers_to_analyze}
        analyst_futures     = {pool.submit(get_analyst_data,        t): t for t in tickers_to_analyze}
        stocktwits_futures  = {pool.submit(get_stocktwits_data,     t): t for t in tickers_to_analyze}
        options_futures     = {pool.submit(get_options_iv_data,     t): t for t in tickers_to_analyze}
        beat_futures        = {pool.submit(get_earnings_beat_rate,  t): t for t in tickers_to_analyze}
        extra_fund_futures  = {pool.submit(get_extra_fundamentals,  t): t for t in tickers_to_analyze}
        cong_futures        = {pool.submit(get_congressional_trades, t): t for t in tickers_to_analyze}
        wsb_futures         = {pool.submit(get_reddit_wsb,           t): t for t in tickers_to_analyze}
        uoa_futures         = {pool.submit(get_unusual_options,      t): t for t in tickers_to_analyze}
        borrow_futures      = {pool.submit(get_borrow_rate,          t): t for t in tickers_to_analyze}
        finnhub_futures     = {pool.submit(get_finnhub_data,             t): t for t in tickers_to_analyze}
        fmp_futures         = {pool.submit(get_fmp_data,                 t): t for t in tickers_to_analyze}
        sec_futures         = {pool.submit(get_sec_filings,              t): t for t in tickers_to_analyze}
        premarket_futures   = {pool.submit(get_premarket_volume,         t): t for t in tickers_to_analyze}
        inst_trend_futures  = {pool.submit(get_institutional_trend,      t): t for t in tickers_to_analyze}
        gamma_futures       = {pool.submit(get_gamma_squeeze_data,       t): t for t in tickers_to_analyze}
        eps_trend_futures   = {pool.submit(get_earnings_estimate_trend,  t): t for t in tickers_to_analyze}
        poly_news_futures   = {pool.submit(get_polygon_news, t, 8): t for t in tickers_to_analyze}
        # FINVIZ Elite options chain — nearest Friday expiry, full strike/IV/Greeks/OI
        from datetime import date as _date, timedelta as _td
        _today = _date.today()
        _days_ahead = (4 - _today.weekday()) % 7 or 7
        _nearest_expiry = (_today + _td(days=_days_ahead)).isoformat()
        poly_opts_futures   = {pool.submit(get_finviz_options, t, _nearest_expiry): t for t in tickers_to_analyze}

        for fut in as_completed(earn_futures):
            t = earn_futures[fut]
            try:    earnings_data[t] = fut.result()
            except: earnings_data[t] = {"earnings_date": None, "days_to_earnings": None, "earnings_risk": False}

        for fut in as_completed(news_futures):
            t = news_futures[fut]
            try:    news_data[t] = fut.result()
            except: news_data[t] = {"score": 0, "bias": "neutral"}

        for fut in as_completed(insider_futures):
            t = insider_futures[fut]
            try:    insider_data[t] = fut.result()
            except: insider_data[t] = {"buys": 0, "sells": 0, "sentiment": "neutral"}

        for fut in as_completed(analyst_futures):
            t = analyst_futures[fut]
            try:    analyst_data[t] = fut.result()
            except: analyst_data[t] = {}

        for fut in as_completed(stocktwits_futures):
            t = stocktwits_futures[fut]
            try:    stocktwits_data[t] = fut.result()
            except: stocktwits_data[t] = {}

        for fut in as_completed(options_futures):
            t = options_futures[fut]
            try:    options_iv_data[t] = fut.result()
            except: options_iv_data[t] = {}

        for fut in as_completed(beat_futures):
            t = beat_futures[fut]
            try:    beat_rate_data[t] = fut.result()
            except: beat_rate_data[t] = {}

        for fut in as_completed(extra_fund_futures):
            t = extra_fund_futures[fut]
            try:    extra_fund_data[t] = fut.result()
            except: extra_fund_data[t] = {}

        for fut in as_completed(cong_futures):
            t = cong_futures[fut]
            try:    congressional_data[t] = fut.result()
            except: congressional_data[t] = {}

        for fut in as_completed(wsb_futures):
            t = wsb_futures[fut]
            try:    reddit_wsb_data[t] = fut.result()
            except: reddit_wsb_data[t] = {}

        for fut in as_completed(uoa_futures):
            t = uoa_futures[fut]
            try:    uoa_data[t] = fut.result()
            except: uoa_data[t] = {}

        for fut in as_completed(borrow_futures):
            t = borrow_futures[fut]
            try:    borrow_data[t] = fut.result()
            except: borrow_data[t] = {}


        for fut in as_completed(finnhub_futures):
            t = finnhub_futures[fut]
            try:    finnhub_data[t] = fut.result()
            except: finnhub_data[t] = {}

        for fut in as_completed(fmp_futures):
            t = fmp_futures[fut]
            try:    fmp_data[t] = fut.result()
            except: fmp_data[t] = {}

        for fut in as_completed(sec_futures):
            t = sec_futures[fut]
            try:    sec_data[t] = fut.result()
            except: sec_data[t] = {}

        for fut in as_completed(premarket_futures):
            t = premarket_futures[fut]
            try:    premarket_data[t] = fut.result()
            except: premarket_data[t] = {}

        for fut in as_completed(inst_trend_futures):
            t = inst_trend_futures[fut]
            try:    inst_trend_data[t] = fut.result()
            except: inst_trend_data[t] = {}

        for fut in as_completed(gamma_futures):
            t = gamma_futures[fut]
            try:    gamma_data[t] = fut.result()
            except: gamma_data[t] = {}

        for fut in as_completed(eps_trend_futures):
            t = eps_trend_futures[fut]
            try:    eps_trend_data[t] = fut.result()
            except: eps_trend_data[t] = {}

        for fut in as_completed(poly_news_futures):
            t = poly_news_futures[fut]
            try:    polygon_news_data[t] = fut.result()
            except: polygon_news_data[t] = []

        for fut in as_completed(poly_opts_futures):
            t = poly_opts_futures[fut]
            try:    polygon_opts_data[t] = fut.result()
            except: polygon_opts_data[t] = {}

    log.info(f"  Enriched {len(infos)} tickers (incl. congressional + WSB + UOA + borrow + Finnhub + FMP + SEC + pre-mkt + gamma + FINVIZ + Polygon)")

    # Build exchange map from yfinance info for TV scanner
    exchange_map = {t: info.get("exchange", "") for t, info in infos.items()}
    tv_ratings = get_tv_ratings_batch(tickers_to_analyze, exchange_map)
    log.info(f"  TV ratings: {len(tv_ratings)} tickers")

    # Step 5: Analyze all qualified tickers (parallel — 8 workers)
    log.info("Step 5: Running full analysis (parallel)...")
    all_results = []
    killed = []

    def _analyze_one(ticker: str):
        df = qualified[ticker]
        info = infos.get(ticker, {"ticker": ticker})
        earnings = earnings_data.get(ticker, {})
        news = news_data.get(ticker, {})
        insider = insider_data.get(ticker, {})
        zacks_dict = {"rank": 1, "rank_text": "Strong Buy"} if ticker in zacks_r1_set else None
        result = analyze_ticker(
            ticker, df, info, regime, earnings, news,
            insider, spy_close, cfg,
            zacks=zacks_dict,
            tv_rating=tv_ratings.get(ticker),
            weekly_df=weekly_data.get(ticker),
            options_data=options_iv_data.get(ticker),
            beat_rate=beat_rate_data.get(ticker),
            stocktwits=stocktwits_data.get(ticker),
            sector_etf_data=sector_etf_data,
            extra_fund=extra_fund_data.get(ticker),
            congressional=congressional_data.get(ticker),
            reddit_wsb=reddit_wsb_data.get(ticker),
            zacks_sell=ticker in zacks_sell_set,
            analyst=analyst_data.get(ticker, {}),
            uoa=uoa_data.get(ticker),
            borrow=borrow_data.get(ticker),
            finnhub=finnhub_data.get(ticker),
            fmp=fmp_data.get(ticker),
            sec=sec_data.get(ticker),
            breadth=market_breadth,
            premarket=premarket_data.get(ticker),
            inst_trend=inst_trend_data.get(ticker),
            gamma=gamma_data.get(ticker),
            eps_trend=eps_trend_data.get(ticker),
            finviz=finviz_bulk.get(ticker),
            polygon_snapshot=polygon_snapshot.get(ticker),
            polygon_news=polygon_news_data.get(ticker),
            polygon_options=polygon_opts_data.get(ticker),
        )
        result["zacks_rank1"]    = ticker in zacks_r1_set
        result["zacks_vgm"]      = zacks_r1_scores.get(ticker, {})
        result["ticker_source"]  = ticker_sources.get(ticker, "unknown")
        result["analyst"]        = analyst_data.get(ticker, {})
        result["stocktwits"]     = stocktwits_data.get(ticker, {})
        result["finnhub"]        = finnhub_data.get(ticker, {})
        result["fmp"]            = fmp_data.get(ticker, {})
        result["sec_filings"]    = sec_data.get(ticker, {})
        # VGM raw scores (per-ticker, grades assigned post-scan)
        try:
            rev_qoq = get_quarterly_revenue_growth(ticker)
            result["raw_value_score"]    = raw_value_score(info)
            result["raw_growth_score"]   = raw_growth_score(info, revenue_qoq=rev_qoq)
            result["raw_momentum_score"] = raw_momentum_score(df, result.get("technicals", {}).get("indicators", {}))
        except Exception as _vgm_err:
            log.debug(f"  VGM raw scores failed for {ticker}: {_vgm_err}")
            result["raw_value_score"]    = None
            result["raw_growth_score"]   = None
            result["raw_momentum_score"] = None
        return result

    analysis_workers = cfg.get("performance", {}).get("analysis_workers", 8)
    with ThreadPoolExecutor(max_workers=analysis_workers) as pool:
        futures = {pool.submit(_analyze_one, t): t for t in tickers_to_analyze}
        for fut in as_completed(futures):
            ticker = futures[fut]
            try:
                result = fut.result()
                if not result["gate"]["passed"]:
                    killed.append(result)
                else:
                    all_results.append(result)
            except Exception as e:
                log.warning(f"  Analysis failed for {ticker}: {e}")
                if ticker in zacks_r1_set:
                    zacks_r1_missing[ticker] = f"Analysis error: {e}"

    log.info(f"  Analyzed: {len(all_results)} passed, {len(killed)} killed")

    # AI-38: Daily data-quality report — null % per critical field across universe.
    # Alerts if any critical field > 10% null (suggests vendor feed broken).
    try:
        _dq_fields = ("rs_rank", "price", "score")
        _dq_counts = {f: 0 for f in _dq_fields}
        _dq_tech = {"rvol": 0, "rsi": 0, "ema20": 0, "atr": 0}
        _total_dq = len(all_results)
        for _r in all_results:
            for _f in _dq_fields:
                if _r.get(_f) is None:
                    _dq_counts[_f] += 1
            _ind = _r.get("technicals", {}).get("indicators", {}) or {}
            for _k in _dq_tech:
                if _ind.get(_k) is None:
                    _dq_tech[_k] += 1
        if _total_dq > 0:
            _dq_report = []
            for _f, _n in {**_dq_counts, **_dq_tech}.items():
                _pct = _n / _total_dq * 100
                if _pct >= 10:
                    _dq_report.append(f"{_f} {_pct:.0f}% null")
            if _dq_report:
                log.warning(f"  ⚠️  DATA QUALITY: {', '.join(_dq_report)} ({_total_dq} tickers) — check vendor feed")
            else:
                log.info(f"  Data quality: all critical fields <10% null ✓")
    except Exception as _dqe:
        log.debug(f"Data quality report failed: {_dqe}")

    # AI-32: "Why didn't X fire?" — top 10 RS tickers that are NOT BUY; log blocking reason.
    try:
        _top_rs_not_buy = sorted(
            [r for r in all_results
             if r.get("decision", {}).get("verdict") != "BUY"
             and (r.get("rs_rank", 0) or 0) >= 85],
            key=lambda r: r.get("rs_rank", 0),
            reverse=True,
        )[:10]
        if _top_rs_not_buy:
            log.info(f"  Why-not-BUY (top {len(_top_rs_not_buy)} by RS, RS>=85):")
            for _r in _top_rs_not_buy:
                _rsn = (_r.get("decision") or {}).get("reason", "")[:120]
                log.info(f"    {_r['ticker']:6s} RS {_r.get('rs_rank', 0):3d} score {_r.get('score', 0):3.0f} "
                         f"{_r.get('decision',{}).get('verdict','?'):5s} — {_rsn}")
    except Exception as _wbe:
        log.debug(f"why-not-BUY log failed: {_wbe}")

    # Post-score sanity checks (Data Pipeline → A): flag suspicious scores
    _sanity_flags = 0
    for _r in all_results:
        _t = _r.get("ticker", "")
        _sc = float(_r.get("score", 0) or 0)
        _rv = float(_r.get("technicals", {}).get("indicators", {}).get("rvol", 1.0) or 1.0)
        _px = float(_r.get("price", 0) or 0)
        _rs = int(_r.get("rs_rank", 0) or 0)
        # High score but no volume — likely stale signal
        if _sc >= 80 and _rv < 0.5:
            log.warning(f"  ⚠️  SANITY: {_t} score {_sc:.0f} with RVOL {_rv:.2f} (very low) — verify signal")
            _sanity_flags += 1
        # Price < $1 but passed liquidity — likely data error
        if 0 < _px < 1.0:
            log.warning(f"  ⚠️  SANITY: {_t} price ${_px:.3f} (<$1) but passed liquidity — check data")
            _sanity_flags += 1
        # Score > 85 but RS < 50 — inconsistent (high score should have strong RS)
        if _sc >= 85 and _rs > 0 and _rs < 50:
            log.warning(f"  ⚠️  SANITY: {_t} score {_sc:.0f} but RS {_rs} (low) — score inconsistency")
            _sanity_flags += 1
    if _sanity_flags:
        log.info(f"  Sanity checks: {_sanity_flags} flags across {len(all_results)} results")

    # Step 5a-ii: Recompute RS rank as true percentile across the full scanned universe
    # (The per-ticker linear mapping 0.8–1.2 ratio → 0-100 is replaced with cross-sectional rank)
    try:
        all_for_rs = all_results + killed
        ratios = []
        for r in all_for_rs:
            ratio = r.get("technicals", {}).get("indicators", {}).get("rs_ratio")
            ratios.append(float(ratio) if ratio is not None else None)
        valid_ratios = sorted([v for v in ratios if v is not None])
        n_valid = len(valid_ratios)
        if n_valid > 1:
            for r, ratio in zip(all_for_rs, ratios):
                if ratio is None:
                    continue
                # percentile rank: fraction of universe with lower ratio
                pct = int(sum(1 for v in valid_ratios if v < ratio) / n_valid * 100)
                pct = max(0, min(100, pct))
                r["rs_rank"] = pct
                try:
                    r["technicals"]["indicators"]["rs_rank"] = pct
                except (KeyError, TypeError):
                    pass
            log.info(f"  RS percentile re-ranked across {n_valid} tickers")
    except Exception as e:
        log.warning(f"  RS percentile re-rank failed (non-fatal): {e}")

    # Step 5b: Gmail Zacks email bonus
    log.info("Step 5b: Fetching Zacks email signals from Gmail...")
    try:
        gmail_data = fetch_zacks_emails(days=2)
        gmail_count = gmail_data.get("total", 0)
        log.info(f"  Gmail: {gmail_count} Zacks emails | "
                 f"Rank changes: {len(gmail_data.get('rank_changes', {}))} | "
                 f"Trade alerts: {len(gmail_data.get('trade_alerts', []))}")
        # Apply email bonus to scored results
        for result in all_results + killed:
            t = result["ticker"]
            eb = get_zacks_email_bonus(t, gmail_data)
            if eb["bonus"] != 0:
                result["score"] = max(0, min(100, result["score"] + eb["bonus"]))
                result["gmail_bonus"] = eb
                log.info(f"    {t}: Gmail bonus {eb['bonus']:+d} → {result['score']:.0f} "
                         f"({', '.join(eb['signals'])})")
            else:
                result["gmail_bonus"] = eb
    except Exception as e:
        log.warning(f"  Gmail fetch failed (non-fatal): {e}")
        gmail_data = {"emails": [], "rank_changes": {}, "trade_alerts": [],
                      "bull_bear": [], "ticker_mentions": {}}

    # Step 5c: Assign VGM grades (percentile-ranked across full universe)
    log.info("Step 5c: Assigning VGM grades...")
    try:
        all_results = assign_vgm_grades(all_results)
        # Also assign to killed so they show grades in the Killed tab
        killed = assign_vgm_grades(killed)
        log.info(f"  VGM grades assigned to {len(all_results)} passed + {len(killed)} killed")
    except Exception as e:
        log.warning(f"  VGM grading failed (non-fatal): {e}")

    # Step 6: Sort and categorize
    all_results.sort(key=lambda x: x["score"], reverse=True)

    top_n_buy  = cfg.get("output", {}).get("top_n_buy",   5)
    top_n_sell = cfg.get("output", {}).get("top_n_sell",  5)
    top_n_watch = cfg.get("output", {}).get("top_n_watch", 5)
    sector_max = cfg.get("portfolio", {}).get("sector_max_positions", 2)
    # AI-10: industry cap — tighter than sector. Finer concentration control.
    industry_max = cfg.get("portfolio", {}).get("industry_max_positions", 2)

    # Phase 5D: Dynamic sector concentration — adjust by sector performance
    # AI-10: plus industry cap (hard-block, not warn-only)
    sector_buy_count: dict[str, int] = {}
    industry_buy_count: dict[str, int] = {}
    buy_candidates_raw = []
    for r in all_results:
        if r["decision"]["verdict"] != "BUY":
            continue
        sector = r.get("sector", "Unknown")
        industry = r.get("industry", "") or sector  # fall back to sector if no industry
        # Phase 5D: dynamic cap — outperforming sectors get 3, underperforming get 1
        _sec_etf = r.get("technicals", {}).get("indicators", {}).get("sector_etf", "")
        if _sec_etf and sector_etf_data and _sec_etf in sector_etf_data:
            _sec_outperf = sector_etf_data[_sec_etf].get("outperforming", False)
            _dynamic_max = 3 if _sec_outperf else 1
        else:
            _dynamic_max = sector_max

        # Industry cap first (tighter)
        if industry_buy_count.get(industry, 0) >= industry_max:
            r["decision"]["verdict"] = "WATCH"
            r["decision"]["reason"] += (
                f" [industry cap: {industry} already has {industry_buy_count[industry]} BUY(s), limit={industry_max}]"
            )
            continue

        # Then sector cap
        if sector_buy_count.get(sector, 0) >= _dynamic_max:
            r["decision"]["verdict"] = "WATCH"
            r["decision"]["reason"] += (
                f" [sector cap: {sector} already has {sector_buy_count[sector]} BUY(s), limit={_dynamic_max}]"
            )
            continue

        buy_candidates_raw.append(r)
        sector_buy_count[sector] = sector_buy_count.get(sector, 0) + 1
        industry_buy_count[industry] = industry_buy_count.get(industry, 0) + 1

    buy_candidates = buy_candidates_raw[:top_n_buy]

    # VIX spike kill switch — apply to final candidates
    if _vix_kill_active:
        buy_candidates = []
        for r in all_results:
            if r.get("decision", {}).get("verdict") == "BUY" and r.get("direction") != "short":
                r["decision"]["verdict"] = "WATCH"
                r["decision"]["reason"] = f"VIX spike kill switch active — no new longs during risk-off"

    # Phase 5E: Graduated VIX — tighten mode raises score bar by 10 pts
    if _vix_tighten_active:
        for r in all_results:
            if r.get("decision", {}).get("verdict") == "BUY":
                if r.get("score", 0) < 75:  # score must be >= 75 in tighten mode
                    r["decision"]["verdict"] = "WATCH"
                    r["decision"]["reason"] += " [VIX tighten: need 75+ score during VIX spike]"
        buy_candidates = [r for r in buy_candidates if r.get("decision", {}).get("verdict") == "BUY"]

    # AI-25: PDT hard-block — under $25K equity, 4+ same-day round-trips in 5
    # business days triggers the SEC pattern-day-trader restriction. We
    # preempt at 3 to leave headroom (can't undo a trade once submitted).
    try:
        _port_pdt = get_portfolio_summary() if callable(get_portfolio_summary) else {}
        _equity_pdt = float(_port_pdt.get("equity", 5000) or 5000)
        if _equity_pdt < 25_000:
            from datetime import date as _date_pdt, timedelta as _td_pdt
            _today_pdt = _date_pdt.today()
            _lookback_pdt = _today_pdt - _td_pdt(days=7)  # ~5 business days
            _closed_pdt = _port_pdt.get("closed_trades", [])
            _dt_count = 0
            for _t in _closed_pdt:
                _ed = str(_t.get("entry_date", ""))[:10]
                _xd = str(_t.get("exit_date",  ""))[:10]
                if _ed and _xd and _ed == _xd:
                    try:
                        _d = _date_pdt.fromisoformat(_xd)
                        if _d >= _lookback_pdt:
                            _dt_count += 1
                    except Exception:
                        pass
            _pdt_block = cfg.get("portfolio", {}).get("position_management", {}).get("pdt_block_at", 3)
            if _dt_count >= _pdt_block:
                log.warning(f"  🔴 PDT HARD-BLOCK: {_dt_count} same-day round-trips in last 5d (<${_equity_pdt:,.0f} account) — no new BUYs today")
                for r in all_results:
                    if r.get("decision", {}).get("verdict") == "BUY":
                        r["decision"]["verdict"] = "WATCH"
                        r["decision"]["reason"] = f"PDT block: {_dt_count}/3 day-trades in 5d (sub-$25K account)"
    except Exception as _pe:
        log.debug(f"PDT hard-block check failed: {_pe}")

    # AI-47: Weekend risk cap — Friday PT scans cap new longs so weekend gross
    # exposure stays <= 50% (60% into 3-day weekends).
    try:
        _today_weekday = datetime.now().weekday()  # 0=Mon..6=Sun
        if _today_weekday == 4:  # Friday
            _weekend_cap = 0.5
            _port_we = get_portfolio_summary() if callable(get_portfolio_summary) else {}
            _cur_gross = sum(p.get("allocation_pct", 0) or 0 for p in _port_we.get("positions", [])) / 100.0
            if _cur_gross >= _weekend_cap:
                log.warning(f"  ⚠️  WEEKEND RISK CAP: current gross {_cur_gross*100:.0f}% >= {_weekend_cap*100:.0f}% — blocking new longs into weekend")
                for r in all_results:
                    if r.get("decision", {}).get("verdict") == "BUY":
                        r["decision"]["verdict"] = "WATCH"
                        r["decision"]["reason"] = f"Weekend risk cap: gross exposure {_cur_gross*100:.0f}%, cap {_weekend_cap*100:.0f}%"
    except Exception as _we:
        log.debug(f"Weekend cap check failed: {_we}")

    # AI-45: portfolio-level daily loss trigger — halt new positions if day P&L <= -4%
    try:
        _daily_loss_pct = cfg.get("portfolio", {}).get("position_management", {}).get("daily_halt_pct", -4.0)
        _port_summary_dl = get_portfolio_summary() if callable(get_portfolio_summary) else {}
        _positions_dl = _port_summary_dl.get("positions", [])
        _day_pnl_pct = 0.0
        if _positions_dl:
            # Day P&L = sum of today's change per open position, weighted by allocation
            _day_chg_weighted = 0.0
            _total_alloc_dl = 0.0
            for _p in _positions_dl:
                _dc = _p.get("day_chg_pct")
                _alloc = _p.get("allocation_pct", 0) or 0
                if _dc is not None and _alloc > 0:
                    _day_chg_weighted += _dc * _alloc
                    _total_alloc_dl += _alloc
            if _total_alloc_dl > 0:
                _day_pnl_pct = _day_chg_weighted / _total_alloc_dl
        if _day_pnl_pct <= _daily_loss_pct:
            log.warning(f"  🔴 DAILY-LOSS HALT: book down {_day_pnl_pct:.1f}% today (≤{_daily_loss_pct}%) — no new longs")
            buy_candidates = []
            for r in all_results:
                if r.get("decision", {}).get("verdict") == "BUY":
                    r["decision"]["verdict"] = "WATCH"
                    r["decision"]["reason"] = f"Daily-loss halt: portfolio -{abs(_day_pnl_pct):.1f}% today"
    except Exception as e:
        log.debug(f"Daily-loss halt check failed (non-fatal): {e}")

    # Portfolio drawdown kill switch — no new positions if book is -8%
    try:
        _port_summary = get_portfolio_summary() if callable(get_portfolio_summary) else {}
        _positions = _port_summary.get("positions", [])
        _total_alloc = sum(p.get("allocation_pct", 0) for p in _positions)
        if _positions and _total_alloc > 0:
            _open_pnl_pct = sum(
                p.get("unrealized_pnl_pct", 0) * p.get("allocation_pct", 0)
                for p in _positions
            ) / _total_alloc
        else:
            _open_pnl_pct = 0.0
        _kill_threshold = cfg.get("portfolio", {}).get("position_management", {}).get("drawdown_kill_pct", -8.0)
        if _open_pnl_pct <= _kill_threshold:
            log.warning(f"  DRAWDOWN KILL SWITCH: Portfolio P&L {_open_pnl_pct:.1f}% — no new BUY signals")
            buy_candidates = []
            for r in all_results:
                if r.get("decision", {}).get("verdict") == "BUY":
                    r["decision"]["verdict"] = "WATCH"
                    r["decision"]["reason"] = f"Drawdown kill switch active ({_open_pnl_pct:.1f}% open loss)"
    except Exception as e:
        log.debug(f"Portfolio drawdown check failed (non-fatal): {e}")

    # Phase 5A: Circuit breaker — pause after 3 consecutive losses
    try:
        from tracker import compute_stats
        _stats = compute_stats()
        _recent = _stats.get("recent_trades", [])
        # Count consecutive losses from most recent
        _consec_losses = 0
        for _t in reversed(_recent):
            if _t.get("pnl_pct", 0) < 0:
                _consec_losses += 1
            else:
                break
        if _consec_losses >= 3:
            log.warning(f"  CIRCUIT BREAKER: {_consec_losses} consecutive losses — no new BUY signals")
            buy_candidates = []
            for r in all_results:
                if r.get("decision", {}).get("verdict") == "BUY":
                    r["decision"]["verdict"] = "WATCH"
                    r["decision"]["reason"] = f"Circuit breaker: {_consec_losses} consecutive losses — pause trading"
    except Exception as _cb_err:
        log.debug(f"  Circuit breaker check failed (non-fatal): {_cb_err}")

    # Correlation gate — block BUY candidates that are >0.80 correlated to existing positions
    # Avoids false diversification: holding 3 highly correlated tech stocks = 1 concentrated bet
    try:
        from portfolio_tracker import compute_pairwise_correlation, load_portfolio
        _port_data = load_portfolio()
        _open_tickers = [p["ticker"] for p in _port_data.get("positions", []) if p.get("status") == "open"]
        _corr_threshold = cfg.get("portfolio", {}).get("position_management", {}).get("max_correlation", 0.80)
        if _open_tickers and buy_candidates:
            _candidate_tickers = [r["ticker"] for r in buy_candidates]
            _all_tickers = list(set(_open_tickers + _candidate_tickers))
            _corr_matrix = compute_pairwise_correlation(_all_tickers, period="3mo")
            for r in buy_candidates[:]:
                _cand = r["ticker"]
                for _pos_t in _open_tickers:
                    _pair = tuple(sorted((_cand, _pos_t)))
                    _corr = _corr_matrix.get(_pair)
                    if _corr is not None and abs(_corr) > _corr_threshold:
                        r["decision"]["verdict"] = "WATCH"
                        r["decision"]["reason"] += (
                            f" [corr gate: {_corr:.2f} correlation with open {_pos_t} > {_corr_threshold}]"
                        )
                        log.info(f"  Corr gate: {_cand} downgraded (corr {_corr:.2f} with {_pos_t})")
                        break
            buy_candidates = [r for r in buy_candidates if r.get("decision", {}).get("verdict") == "BUY"]
    except Exception as _ce:
        log.debug(f"  Correlation gate check failed (non-fatal): {_ce}")

    # Enforce max gross exposure cap (80% of portfolio)
    try:
        _max_exp = cfg.get("portfolio", {}).get("position_management", {}).get("max_gross_exposure_pct", 80)
        _total_alloc = sum(r.get("trade_plan", {}).get("allocation_pct", 7.5) for r in buy_candidates)
        if _total_alloc > _max_exp:
            # Trim lowest-score candidates until under cap
            buy_candidates.sort(key=lambda x: x.get("score", 0), reverse=True)
            while buy_candidates and sum(r.get("trade_plan", {}).get("allocation_pct", 7.5) for r in buy_candidates) > _max_exp:
                removed = buy_candidates.pop()
                log.info(f"  Exposure cap: removed {removed['ticker']} (total would exceed {_max_exp}%)")
    except Exception as e:
        log.debug(f"Exposure cap check failed (non-fatal): {e}")

    watch_list = [r for r in all_results if r["decision"]["verdict"] == "WATCH"][:top_n_watch]

    # Sell candidates: confirmed SHORT setups (bear_setup score >= 10, bear regime, R:R >= 3:1)
    # Falls back to AVOID stocks in downtrend if no confirmed shorts exist
    sell_candidates = [r for r in all_results if r["decision"]["verdict"] == "SHORT"][:top_n_sell]
    if not sell_candidates:
        sell_candidates = [r for r in all_results
                           if r["direction"] == "short"
                           and r["decision"]["verdict"] == "AVOID"
                           and r.get("bear_setup", {}).get("score", 0) >= 4][:top_n_sell]

    # Price-tier buckets: top 5 BUY per tier ($5–$50, $50–$100, >$100)
    price_tiers_cfg = cfg.get("filters", {}).get("price_tiers", [
        {"label": "$5–$50",   "min": 5,   "max": 50,   "top_n": 5},
        {"label": "$50–$100", "min": 50,  "max": 100,  "top_n": 5},
        {"label": ">$100",    "min": 100, "max": 9999, "top_n": 5},
    ])
    price_tier_results: list[dict] = []
    for tier in price_tiers_cfg:
        t_min, t_max, t_n = tier["min"], tier["max"], tier.get("top_n", 5)
        picks = [r for r in all_results
                 if t_min <= r.get("price", 0) < t_max
                 and r["decision"]["verdict"] in ("BUY", "WATCH")][:t_n]
        price_tier_results.append({
            "label":  tier["label"],
            "min":    t_min,
            "max":    t_max,
            "picks":  picks,
        })

    # Zacks #1 tab: all analyzed stocks that are Zacks Rank #1, sorted by score
    zacks_tab = sorted(
        [r for r in all_results + killed if r.get("zacks_rank1")],
        key=lambda x: x["score"], reverse=True
    )

    # Build industries
    ind_map = {}
    for r in all_results:
        ind = r.get("industry", "Unknown")
        if ind not in ind_map:
            ind_map[ind] = {"scores": [], "tickers": []}
        ind_map[ind]["scores"].append(r["score"])
        ind_map[ind]["tickers"].append(r["ticker"])

    industries = sorted(
        [{"industry": k, "avg_score": sum(v["scores"]) / len(v["scores"]),
          "count": len(v["scores"]), "tickers": v["tickers"]}
         for k, v in ind_map.items() if k != "Unknown"],
        key=lambda x: x["avg_score"], reverse=True
    )

    # Step 6b: Per-index per-tier BUY/SELL rankings
    sp500_set_upper  = {t.upper() for t in sp500}
    r1000_set_upper  = {t.upper() for t in russell1000}
    all_combined = all_results + killed

    def _index_tier_picks(index_set, all_data, max_price, top_n=5):
        """Top BUY and SELL from an index within a price cap."""
        pool = [r for r in all_data
                if r.get("ticker", "").upper() in index_set
                and 0 < r.get("price", 0) <= max_price]
        pool.sort(key=lambda x: x.get("score", 0), reverse=True)
        buys  = [r for r in pool if r["decision"]["verdict"] in ("BUY", "WATCH")][:top_n]
        sells = [r for r in pool if r["decision"]["verdict"] in ("SHORT",)
                 or (r["direction"] == "short" and r.get("bear_setup", {}).get("score", 0) >= 8)]
        sells.sort(key=lambda x: x.get("bear_setup", {}).get("score", 0), reverse=True)
        sells = sells[:top_n]
        return buys, sells

    idx_sp500_100_buy,  idx_sp500_100_sell  = _index_tier_picks(sp500_set_upper, all_combined, 100)
    idx_sp500_250_buy,  idx_sp500_250_sell  = _index_tier_picks(sp500_set_upper, all_combined, 250)
    idx_r1000_100_buy,  idx_r1000_100_sell  = _index_tier_picks(r1000_set_upper, all_combined, 100)
    idx_r1000_250_buy,  idx_r1000_250_sell  = _index_tier_picks(r1000_set_upper, all_combined, 250)

    index_picks = {
        "sp500_100":  {"buy": idx_sp500_100_buy,  "sell": idx_sp500_100_sell},
        "sp500_250":  {"buy": idx_sp500_250_buy,  "sell": idx_sp500_250_sell},
        "r1000_100":  {"buy": idx_r1000_100_buy,  "sell": idx_r1000_100_sell},
        "r1000_250":  {"buy": idx_r1000_250_buy,  "sell": idx_r1000_250_sell},
    }

    # Step 6c: Portfolio risk metrics
    portfolio_risk = _compute_portfolio_risk(all_results, market_data, spy_close)

    # Step 7: Track
    log.info("Step 7: Recording picks...")
    record_run(buy_candidates + list(watch_list[:5]) + list(sell_candidates[:5]),
               run_date, regime_name=regime.get("regime", "unknown"),
               # AI-15: full market-context snapshot per run
               vix=vix_cur,
               breadth_pct_50d=regime.get("breadth_pct_50d"),
               regime4=regime4,
               spy_price=regime.get("spy_price"),
               spy_1m_ret=regime.get("spy_1m_ret"),
               distribution_days=regime.get("distribution_days"))

    # Also log to signal_tracker for drift/attribution. signal_tracker.log_signals
    # expects a flat schema (ticker/price/stop/target1/rr/...), so we transform the
    # screener-shaped candidates into the minimal fields it reads.
    try:
        from signal_tracker import log_signals
        def _flatten_for_signal_log(c):
            plan = c.get("trade_plan") or {}
            ind  = c.get("technicals", {}).get("indicators", {}) or {}
            return {
                "ticker":      c.get("ticker", ""),
                "strategy":    plan.get("setup_type") or c.get("setup_family", "Core Swing"),
                "price":       c.get("price", 0) or 0,
                "stop":        plan.get("stop") or 0,
                "target1":     plan.get("target1") or 0,
                "rr":          plan.get("rr_ratio") or 0,
                "star_rating": c.get("star_rating", 0),
                "score":       c.get("score", 0),
                "rs_rank":     c.get("rs_rank") if c.get("rs_rank") is not None else ind.get("rs_rank", 0),
                "direction":   c.get("direction", "long"),
            }
        _signal_payload = [_flatten_for_signal_log(c) for c in (buy_candidates + list(sell_candidates))]
        log_signals(_signal_payload, run_date=run_date)
    except Exception as e:
        log.warning(f"signal_tracker.log_signals failed: {e}")

    # Refresh MTM / MAE / MFE for older open picks
    try:
        from signal_tracker import update_outcomes
        update_outcomes()
    except Exception as e:
        log.warning(f"signal_tracker.update_outcomes failed: {e}")

    # Step 7b: Social signals (nitter.net RSS — cached 1h)
    log.info("Step 7b: Fetching social signals...")
    try:
        social_signals_data = get_social_signals()
        log.info(f"  Social: {social_signals_data.get('active_handles', 0)} handles, "
                 f"{social_signals_data.get('total_tickers', 0)} tickers")
    except Exception as e:
        log.warning(f"  Social signals failed: {e}")
        social_signals_data = {}

    # Check WATCH triggers
    from tracker import check_watch_triggers, update_score_history
    _cur_prices = {r["ticker"]: r.get("price", 0) for r in all_results}
    watch_trigger_hits = check_watch_triggers(_cur_prices)
    if watch_trigger_hits:
        log.info(f"  WATCH triggers fired: {[w['ticker'] for w in watch_trigger_hits]}")
    update_score_history(all_results, run_date)

    # Step 7c: Pre-analyze strategy scanner picks so Full Analysis never shows partial data
    log.info("Step 7c: Pre-analyzing strategy scanner picks...")
    _existing_tickers = set(r["ticker"] for r in all_results)
    _strategy_tickers = set()
    try:
        from weekly_pullback import scan_weekly_pullback
        for c in scan_weekly_pullback():
            if c.get("trade_plan", {}).get("rr_ratio", 0) >= 1.0:
                _strategy_tickers.add(c["ticker"])
    except Exception:
        pass
    try:
        from mean_reversion import scan_mean_reversion
        for c in scan_mean_reversion():
            _strategy_tickers.add(c["ticker"])
    except Exception:
        pass

    _need_analyze = _strategy_tickers - _existing_tickers
    if _need_analyze:
        log.info(f"  {len(_need_analyze)} strategy picks need full analysis: {list(_need_analyze)[:10]}")
        from concurrent.futures import ThreadPoolExecutor as _TPE2, as_completed as _ac
        def _analyze_one(t):
            try:
                if t not in market_data:
                    return None
                return analyze_ticker(t, market_data[t], info_map.get(t, {}),
                                      regime, earnings_map.get(t, {}), {}, {},
                                      spy_close, config,
                                      weekly_df=weekly_data.get(t),
                                      sector_etf_data=sector_etf,
                                      finviz=finviz_map.get(t, {}))
            except Exception:
                return None

        with _TPE2(max_workers=4) as pool:
            futs = {pool.submit(_analyze_one, t): t for t in _need_analyze}
            for f in _ac(futs):
                t = futs[f]
                r = f.result()
                if r and r.get("score", 0) > 0:
                    r["ticker_source"] = ticker_sources.get(t, "strategy")
                    all_results.append(r)
        log.info(f"  Pre-analyzed: {len(all_results) - len(_existing_tickers)} added to universe")

    # Step 8: Generate HTML
    log.info("Step 8: Generating HTML dashboard...")
    stats        = compute_stats()
    full_history = get_full_history()
    mtm_data     = mark_to_market()
    setup_stats  = compute_stats_by_setup()
    log.info(f"  Mark-to-market: {len(mtm_data)} picks tracked | "
             f"Setup breakdown: {len(setup_stats.get('by_setup', {}))} setup types, "
             f"{setup_stats.get('total_trades', 0)} completed trades")
    portfolio_summary = get_portfolio_summary()
    refresh_prices()  # update open position P&L

    # Crypto scan — fast (~3–5s), runs in parallel with nothing
    try:
        crypto_data = run_crypto_scan()
        log.info(f"  Crypto: {crypto_data.get('total_passed', 0)} coins passed / "
                 f"top pick score {crypto_data['top_picks'][0]['score'] if crypto_data.get('top_picks') else 0}")
    except Exception as _ce:
        log.warning(f"  Crypto scan failed (non-fatal): {_ce}")
        crypto_data = {}

    bundle = {
        "run_date":         run_date,
        "run_timestamp":    run_timestamp,
        "regime":           regime,
        "buy_candidates":   buy_candidates,
        "sell_candidates":  sell_candidates,
        "watch_list":       watch_list,
        "all_scored":       all_results,
        "killed":           killed,
        "industries":       industries,
        "zacks_tab":        zacks_tab,
        "zacks_r1_full":    zacks_r1,
        "zacks_r1_missing": zacks_r1_missing,
        "zacks_r1_scores":  zacks_r1_scores,
        "ultimate":         ultimate_data,
        "tazr":             tazr_data,
        "bbt":              bbt_data,
        "counterstrike":    cs_data,
        "headlinetrader":   ht_data,
        "alt_energy":       alt_energy_data,
        "blockchain":       blockchain_data,
        "tech_innovators":  tech_innov_data,
        "sector_etf_data":  sector_etf_data,
        "price_tier_results": price_tier_results,
        "market_breadth":   market_breadth,
        "macro_signals":    macro_signals,
        "fear_greed":       fear_greed_data,
        "watch_trigger_hits": watch_trigger_hits,
        "portfolio_risk":   portfolio_risk,
        "portfolio":        portfolio_summary,
        "stats":            stats,
        "full_history":     full_history,
        "mtm_data":         mtm_data,
        "setup_stats":      setup_stats,
        "config":           cfg,
        "total_scanned":    total_scanned,
        "total_passed":     len(all_results),
        "social_signals":   social_signals_data,
        "sp500_list":       sp500,
        "russell1000_list": russell1000,
        "zacks_sell_list":  zacks_data.get("zacks_sell_list", []),
        "index_picks":      index_picks,
        "gmail_zacks":      gmail_data,
        "crypto":           crypto_data,
        "ticker_sources":   ticker_sources,
    }

    output_path = BASE_DIR / cfg.get("output", {}).get("html_output", "cache/dashboard.html")
    html_path = build_dashboard(bundle, output_path)

    # Persist bundle for fast re-render (html_generator changes, no re-scan needed)
    try:
        bundle_path = BASE_DIR / "cache" / "last_bundle.json"
        with open(bundle_path, "w") as _bf:
            json.dump(bundle, _bf, default=str)
    except Exception as _be:
        log.debug(f"Bundle cache write skipped: {_be}")

    log.info(f"=== Done! Dashboard: {html_path} ===")
    log.info(f"  BUY: {len(buy_candidates)} | WATCH: {len(watch_list)} | AVOID/SELL: {len(sell_candidates)} | Killed: {len(killed)}")

    # Unified audit log (2026-04-15) — one row per scan run for attribution joins
    try:
        import audit
        audit.log("scan_run", {
            "buy_count":   len(buy_candidates),
            "watch_count": len(watch_list),
            "sell_count":  len(sell_candidates),
            "killed":      len(killed),
            "regime":      regime.get("regime"),
            "regime4":     regime.get("regime4"),
            "spy_price":   regime.get("spy_price"),
            "vix":         vix_cur,
            "breadth_50":  market_breadth.get("pct_above_50d"),
        })
    except Exception as _ae:
        log.debug(f"audit.log scan_run skipped: {_ae}")

    # ── Killed-tickers drift tracking + alert ────────────────────────
    try:
        from datetime import datetime as _dt_sh
        import json as _json_sh
        _health_file = BASE_DIR / "data" / "scan_health.json"
        _health = {"history": [], "max_keep": 100}
        if _health_file.exists():
            try:
                with open(_health_file) as _hf:
                    _health = _json_sh.load(_hf)
            except Exception:
                pass
        _total_sh = len(buy_candidates) + len(watch_list) + len(sell_candidates) + len(killed)
        _killed_pct = (len(killed) / _total_sh * 100) if _total_sh > 0 else 0
        _health.setdefault("history", []).append({
            "ts": _dt_sh.now().isoformat(),
            "total": _total_sh,
            "killed": len(killed),
            "pct": round(_killed_pct, 2),
        })
        _max_keep = _health.get("max_keep", 100)
        _health["history"] = _health["history"][-_max_keep:]
        _health["max_keep"] = _max_keep
        _health_file.parent.mkdir(exist_ok=True)
        with open(_health_file, "w") as _hf:
            _json_sh.dump(_health, _hf, indent=2, default=str)

        # Alert if drift detected: need >=10 prior scans, gap > 10pp (lowered from 15pp
        # so drift fires sooner; removed the extra absolute-delta gate).
        _hist = _health["history"]
        if len(_hist) >= 11:
            _recent = _hist[-11:-1]  # exclude current
            _avg_pct = sum(h["pct"] for h in _recent) / len(_recent)
            log.info(f"Kill-drift check: {_killed_pct:.1f}% vs avg {_avg_pct:.1f}% (last {len(_recent)} scans)")
            if _killed_pct > _avg_pct + 10:
                log.warning(f"KILLED DRIFT: {_killed_pct:.1f}% killed (avg last 10: {_avg_pct:.1f}%) — dispatching Slack alert")
                try:
                    from alerts import send_alert
                    _sent = send_alert(
                        level="WARN",
                        title="Scan health drift",
                        body=(f"Killed tickers: {_killed_pct:.1f}% "
                              f"(vs avg {_avg_pct:.1f}% over last 10 scans). "
                              f"Data pipeline may have an issue."),
                    )
                    if not _sent:
                        log.warning("Drift alert: Slack webhook not configured or post failed — "
                                    "check SLACK_WEBHOOK_URL (env/.env) or config/config.json → alerts.slack_webhook")
                except Exception as _se:
                    log.error(f"Drift alert dispatch failed: {_se}")
        else:
            log.info(f"Kill-drift check: {_killed_pct:.1f}% killed ({len(_hist)} prior scans — need >=11 for drift alert)")
    except Exception as _sh_e:
        log.debug(f"Killed-drift tracking failed: {_sh_e}")

    # ── Score distribution vs threshold calibration check ────────────
    try:
        from score_distribution_check import check_distribution
        dist = check_distribution()
        if dist.get("warnings"):
            for w in dist["warnings"]:
                log.warning(f"THRESHOLD CALIBRATION: {w}")
            try:
                from alerts import send_alert
                send_alert(level="WARN",
                           title="Score threshold miscalibration",
                           body=dist["warnings"][0])
            except Exception:
                pass
        if dist.get("stats"):
            log.info(f"Score distribution: mean={dist['stats']['mean']}, "
                     f"p90={dist['stats']['p90']}, BUY qualifiers={dist['n_above_buy']}")
    except Exception as _dc_e:
        log.debug(f"Distribution check failed: {_dc_e}")

    # Print quick summary
    print("\n" + "=" * 60)
    print(f"  SWINGTRADE DAILY SCAN — {run_date}")
    print(f"  Regime: {regime['regime'].upper()} | SPY ${regime['spy_price']}")
    print("=" * 60)

    def _print_tier(label, buys, sells):
        print(f"\n  {label}")
        if buys:
            print(f"    BUY:")
            for r in buys:
                plan = r["trade_plan"]
                print(f"      {r['ticker']:6s} ${r['price']:7.2f}  Score:{r['score']:.0f}  "
                      f"R:R {plan['rr_ratio']:.1f}:1  {plan['setup_type']}")
        else:
            print(f"    BUY:  (none)")
        if sells:
            print(f"    SELL:")
            for r in sells:
                bear_sc = r.get("bear_setup", {}).get("score", 0)
                print(f"      {r['ticker']:6s} ${r['price']:7.2f}  Score:{r['score']:.0f}  "
                      f"Bear {bear_sc}/15")
        else:
            print(f"    SELL: (none)")

    _print_tier("🇺🇸 S&P 500  < $100",  idx_sp500_100_buy,  idx_sp500_100_sell)
    _print_tier("🇺🇸 S&P 500  < $250",  idx_sp500_250_buy,  idx_sp500_250_sell)
    _print_tier("📈 Russell 1000 < $100", idx_r1000_100_buy,  idx_r1000_100_sell)
    _print_tier("📈 Russell 1000 < $250", idx_r1000_250_buy,  idx_r1000_250_sell)

    if industries[:5]:
        print(f"\n  STRONGEST INDUSTRIES:")
        for ind in industries[:5]:
            print(f"    {ind['industry'][:35]:35s}  Avg:{ind['avg_score']:.0f}  "
                  f"({ind['count']} stocks)")

    print(f"\n  Dashboard: {html_path}")
    print("=" * 60)

    # Send alerts (Slack + macOS notification)
    try:
        spy_price_float = float(regime.get("spy_price", 0)) or None
        send_scan_alerts(
            buy_candidates=buy_candidates,
            sell_candidates=sell_candidates,
            watch_candidates=list(watch_list),
            regime=regime.get("regime", "unknown"),
            spy_price=spy_price_float,
        )
    except Exception:
        pass  # alerts are non-critical

    # Email dashboard report
    try:
        send_dashboard_email(
            html_path=html_path,
            buy_count=len(buy_candidates),
            sell_count=len(sell_candidates),
            regime=regime.get("regime", "unknown"),
        )
    except Exception:
        pass  # email is non-critical

    # Position-level alerts (stop-approach + T1-hit) — market-hours gated, throttled
    try:
        from position_alerts import run_alerts_pass
        run_alerts_pass()
    except Exception as e:
        log.debug(f"Position alerts pass failed: {e}")

    # Auto-start server so live analysis + portfolio work in the browser
    _auto_start_server()

    return html_path


def _auto_start_server():
    """Start server.py in background if not already running on port 7432."""
    import socket
    import subprocess
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        s.connect(("localhost", 7432))
        s.close()
        log.info("Server already running on localhost:7432")
    except (ConnectionRefusedError, OSError):
        log.info("Starting server on localhost:7432...")
        subprocess.Popen(
            [sys.executable, str(BASE_DIR / "server.py")],
            cwd=str(BASE_DIR),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        import time
        time.sleep(1)
        log.info("Server started — http://localhost:7432/dashboard")


def run_deep_dive(ticker: str):
    """Run full 9-section deep dive on a single ticker (full enrichment, same as daily scan)."""
    cfg = load_config()
    log.info(f"=== Deep Dive: {ticker} ===")

    # Fetch price data + SPY
    data = fetch_market_data([ticker], period="1y")
    if ticker not in data:
        log.error(f"No data for {ticker}")
        return None

    df = data[ticker]
    # Polygon primary, yfinance fallback
    from data_fetcher import get_polygon_ohlcv as _gpo
    spy_data = _gpo("SPY", days=365, timespan="day")
    if spy_data is None or spy_data.empty or len(spy_data) < 50:
        spy_data = yf.download("SPY", period="1y", interval="1d", progress=False)
    spy_close = spy_data["Close"].squeeze().dropna() if spy_data is not None and not spy_data.empty else None
    if spy_close is None or len(spy_close) == 0:
        log.warning("  SPY data unavailable — relative strength will default to neutral")
        spy_close = None

    # Fetch all enrichment data in parallel (matching daily scan)
    log.info(f"  Fetching enrichment data for {ticker}...")
    with ThreadPoolExecutor(max_workers=16) as pool:
        f_info      = pool.submit(get_stock_info, ticker)
        f_regime    = pool.submit(get_market_regime)
        f_earnings  = pool.submit(get_earnings_date, ticker)
        f_news      = pool.submit(get_news_sentiment, ticker)
        f_insider   = pool.submit(get_insider_activity, ticker)
        f_analyst   = pool.submit(get_analyst_data, ticker)
        f_stocktwit = pool.submit(get_stocktwits_data, ticker)
        f_options   = pool.submit(get_options_iv_data, ticker)
        f_beat      = pool.submit(get_earnings_beat_rate, ticker)
        f_extra     = pool.submit(get_extra_fundamentals, ticker)
        f_cong      = pool.submit(get_congressional_trades, ticker)
        f_wsb       = pool.submit(get_reddit_wsb, ticker)
        f_uoa       = pool.submit(get_unusual_options, ticker)
        f_borrow    = pool.submit(get_borrow_rate, ticker)
        f_finnhub   = pool.submit(get_finnhub_data, ticker)
        f_fmp       = pool.submit(get_fmp_data, ticker)
        f_sec       = pool.submit(get_sec_filings, ticker)
        f_weekly    = pool.submit(get_weekly_data, [ticker])
        f_sector    = pool.submit(get_sector_etf_data)
        f_finviz    = pool.submit(get_finviz_bulk)   # Finviz bulk for SMA%, perf%, ownership

        info        = f_info.result()
        regime      = f_regime.result()
        earnings    = f_earnings.result()
        news        = f_news.result()
        insider     = f_insider.result()
        analyst     = f_analyst.result()
        stocktwits  = f_stocktwit.result()
        options     = f_options.result()
        beat_rate   = f_beat.result()
        extra_fund  = f_extra.result()
        congressional = f_cong.result()
        reddit_wsb  = f_wsb.result()
        uoa         = f_uoa.result()
        borrow      = f_borrow.result()
        finnhub     = f_finnhub.result()
        fmp         = f_fmp.result()
        sec         = f_sec.result()
        weekly_all  = f_weekly.result()
        sector_etf_data = f_sector.result()
        finviz_data = f_finviz.result().get(ticker, {})

    weekly_df = weekly_all.get(ticker)

    result = analyze_ticker(ticker, df, info, regime, earnings, news,
                            insider, spy_close, cfg,
                            weekly_df=weekly_df,
                            options_data=options,
                            beat_rate=beat_rate,
                            stocktwits=stocktwits,
                            sector_etf_data=sector_etf_data,
                            extra_fund=extra_fund,
                            congressional=congressional,
                            reddit_wsb=reddit_wsb,
                            analyst=analyst,
                            uoa=uoa,
                            borrow=borrow,
                            finnhub=finnhub,
                            fmp=fmp,
                            sec=sec,
                            finviz=finviz_data)

    # Print detailed report
    print("\n" + "=" * 60)
    print(f"  DEEP DIVE: {ticker} — {info.get('name', ticker)}")
    print("=" * 60)

    gate = result["gate"]
    print(f"\n  GATE: {'PASS' if gate['passed'] else 'FAIL'}")
    if not gate["passed"]:
        for r in gate["reasons"]:
            print(f"    - {r}")

    print(f"\n  FUNDAMENTALS ({result['fundamentals']['score']}/30)")
    for k, v in result["fundamentals"]["details"].items():
        print(f"    {k}: {v}")

    print(f"\n  OPTIONALITY ({result['optionality']['score']}/20)")
    for k, v in result["optionality"]["details"].items():
        print(f"    {k}: {v}")
    print(f"    Bull case: ${result['optionality']['bull_case']}")
    print(f"    Base case: ${result['optionality']['base_case']}")
    print(f"    Bear case: ${result['optionality']['bear_case']}")

    print(f"\n  TECHNICALS ({result['technicals']['score']}/30)")
    for k, v in result["technicals"]["details"].items():
        print(f"    {k}: {v}")

    print(f"\n  SENTIMENT ({result['sentiment']['score']}/10)")
    for k, v in result["sentiment"]["details"].items():
        print(f"    {k}: {v}")

    plan = result["trade_plan"]
    print(f"\n  TRADE PLAN — {plan['setup_type']}")
    print(f"    Entry:    {plan['entry_zone']}")
    print(f"    Stop:     ${plan['stop']}")
    print(f"    Target 1: ${plan['target1']}")
    print(f"    Target 2: ${plan['target2']}")
    print(f"    R:R:      {plan['rr_ratio']:.1f}:1")
    print(f"    Risk:     ${plan['risk_per_share']:.2f}/share")

    print(f"\n  TOTAL SCORE: {result['score']:.0f}/100")
    verdict = result["decision"]
    print(f"  VERDICT: {verdict['verdict']} — {verdict['reason']}")

    print("=" * 60)

    # Also generate a single-ticker HTML
    bundle = {
        "run_date": datetime.now().strftime("%Y-%m-%d"),
        "regime": regime,
        "buy_candidates": [result] if verdict["verdict"] == "BUY" else [],
        "sell_candidates": [result] if verdict["verdict"] == "AVOID" else [],
        "watch_list": [result] if verdict["verdict"] == "WATCH" else [],
        "all_scored": [result],
        "killed": [] if gate["passed"] else [result],
        "industries": [],
        "stats": compute_stats(),
        "config": cfg,
        "total_scanned": 1,
        "total_passed": 1 if gate["passed"] else 0,
    }

    output_path = BASE_DIR / "cache" / f"deep_{ticker}.html"
    html_path = build_dashboard(bundle, output_path)
    print(f"  Report: {html_path}")

    return result


def show_history():
    """Display performance tracking stats with detailed trade table grouped by date."""
    from tracker import get_full_history

    stats = compute_stats()
    history = get_full_history()

    print("\n" + "=" * 120)
    print("  SWINGTRADE PERFORMANCE SUMMARY")
    print("=" * 120)

    if not stats.get("sufficient_data"):
        print(f"  Need {stats.get('min_required', 5) - stats.get('total_trades', 0)} "
              f"more trades ({stats.get('total_trades', 0)}/{stats.get('min_required', 5)})")
        return

    print(f"  Win Rate:       {stats['win_rate']:.0f}%")
    print(f"  Profit Factor:  {stats['profit_factor']:.1f}")
    print(f"  Avg Win:        +{stats['avg_win']:.1f}%")
    print(f"  Avg Loss:       {stats['avg_loss']:.1f}%")
    print(f"  Total Trades:   {stats['total_trades']}")
    print(f"  Best Streak:    {stats['best_streak']}")

    if stats.get("best_trade"):
        b = stats["best_trade"]
        print(f"  Best Trade:     {b['ticker']} +{b['pct_chg']:.1f}%")
    if stats.get("worst_trade"):
        w = stats["worst_trade"]
        print(f"  Worst Trade:    {w['ticker']} {w['pct_chg']:.1f}%")

    # Group trades by date (not datetime)
    if history and history.get("trades"):
        print("\n" + "=" * 130)
        print("  DETAILED TRADE HISTORY (GROUPED BY DATE)")
        print("=" * 130)

        trades_by_date = {}
        for trade in history.get("trades", []):
            date_key = trade.get("run_date", "unknown")
            if date_key not in trades_by_date:
                trades_by_date[date_key] = []
            trades_by_date[date_key].append(trade)

        # Header
        print(f"{'Ticker':<8} {'Date':<12} {'Time':<6} {'Dir':<5} {'Signal':<8} {'Score':<6} {'Entry':<10} "
              f"{'Exit':<10} {'P&L':<8} {'Win?':<5} {'Setup':<30} {'MAE':<7} {'MFE':<7}")
        print("-" * 130)

        # Print trades grouped by date (most recent first)
        for date_key in sorted(trades_by_date.keys(), reverse=True):
            # Sort trades within each date by time
            day_trades = sorted(trades_by_date[date_key],
                               key=lambda t: t.get("run_time", "00:00"), reverse=True)

            for trade in day_trades:
                ticker = trade.get("ticker", "?")
                run_time = trade.get("run_time", "--:--")
                direction = "SHORT" if trade.get("direction") == "short" else "LONG"
                verdict = trade.get("verdict", "?")
                score = f"{trade.get('score', 0):.0f}"
                entry = f"${trade.get('entry_price', 0):.2f}"
                exit_p = f"${trade.get('exit_price', 0):.2f}"
                pnl = f"{trade.get('pct_chg', 0):+.2f}%"
                win = "✓" if trade.get("win") else "✗"
                setup = trade.get("setup_type", "")[:28]
                mae = f"{trade.get('mae', 0):+.1f}%"
                mfe = f"{trade.get('mfe', 0):+.1f}%"

                print(f"{ticker:<8} {date_key:<12} {run_time:<6} {direction:<5} {verdict:<8} {score:<6} {entry:<10} "
                      f"{exit_p:<10} {pnl:<8} {win:<5} {setup:<30} {mae:<7} {mfe:<7}")

    print("=" * 120)


def _build_sample_bundle() -> dict:
    """Generate a realistic sample bundle for UI development (no API calls)."""
    import random, math
    random.seed(42)

    SAMPLES = [
        ("NVDA", "NVIDIA Corp",          "Technology",    "Semiconductors",               87, "BUY",   3.8, 142.50, "Stage 2 Breakout"),
        ("MSFT", "Microsoft Corp",        "Technology",    "Software—Infrastructure",      81, "BUY",   3.2, 418.20, "Weekly Trend Continuation"),
        ("AAPL", "Apple Inc",             "Technology",    "Consumer Electronics",         76, "BUY",   3.0,  189.45, "Bounce off Support"),
        ("GLD",  "SPDR Gold Shares",      "Financials",    "Gold",                         74, "WATCH", 2.8, 225.80, "SAR Reversal"),
        ("FTI",  "TechnipFMC plc",        "Energy",        "Oil & Gas Equipment & Services",64,"BUY",  3.0,  73.89, "Stage 2 Breakout"),
        ("VIRT", "Virtu Financial",        "Financials",    "Capital Markets",              60, "WATCH", 3.0,  48.37, "Stage 2 Breakout"),
        ("WELL", "Welltower Inc",          "Real Estate",   "REIT - Healthcare",            58, "WATCH", 3.0, 207.07, "Bounce off Support"),
        ("MRVL", "Marvell Technology",     "Technology",    "Semiconductors",               55, "WATCH", 3.0, 127.62, "Stage 2 Breakout"),
        ("ANET", "Arista Networks",        "Technology",    "Computer Hardware",            54, "WATCH", 3.0, 146.46, "Breakout"),
        ("NEM",  "Newmont Corp",           "Materials",     "Gold",                         53, "WATCH", 3.0, 120.55, "Weekly Trend Continuation"),
        ("EIX",  "Edison International",   "Utilities",     "Utilities—Regulated Electric", 54, "WATCH", 3.0,  76.09, "Stage 2 Breakout"),
        ("PLTR", "Palantir Technologies",  "Technology",    "Software—Application",         51, "AVOID", 0.0, 127.83, "Distribution"),
        ("PATH", "UiPath Inc",             "Technology",    "Software—Application",         47, "AVOID", 0.0,   9.55, "Breakdown"),
        ("CRM",  "Salesforce Inc",         "Technology",    "Software—Application",         47, "AVOID", 0.0, 164.92, "Distribution"),
        ("NOW",  "ServiceNow Inc",         "Technology",    "Software—Infrastructure",      45, "SHORT", 2.2,  82.69, "Breakdown"),
        ("BSX",  "Boston Scientific",      "Healthcare",    "Medical Devices",              45, "SHORT", 2.5,  61.35, "Breakdown"),
        ("TTD",  "The Trade Desk",         "Technology",    "Software—Application",         39, "SHORT", 2.8,  20.42, "Stage 4 Decline"),
        ("OKTA", "Okta Inc",               "Technology",    "Software—Infrastructure",      42, "SHORT", 2.6,  64.11, "Stage 4 Decline"),
        ("TOST", "Toast Inc",              "Technology",    "Software—Application",         42, "SHORT", 2.4,  25.42, "Breakdown"),
        ("IR",   "Ingersoll Rand",         "Industrials",   "Specialty Industrial Machinery",52,"WATCH",3.0,  86.18, "SAR Reversal"),
        ("BKR",  "Baker Hughes",           "Energy",        "Oil & Gas Equipment & Services",49,"WATCH",3.0,  62.73, "SAR Reversal"),
        ("GEN",  "Gen Digital",            "Technology",    "Software—Infrastructure",      48, "WATCH", 3.0,  18.25, "Breakdown"),
        ("MKC",  "McCormick & Co",         "Consumer Def.", "Packaged Foods",               48, "WATCH", 3.0,  52.87, "Breakdown"),
        ("OMF",  "OneMain Financial",      "Financials",    "Credit Services",              54, "WATCH", 3.0,  56.28, "SAR Reversal"),
        ("CGNX", "Cognex Corp",            "Technology",    "Scientific Instruments",       54, "WATCH", 3.0,  53.51, "Weekly Trend Continuation"),
    ]

    all_scored, killed = [], []
    for tk, name, sector, industry, score, verdict, rr, price, setup in SAMPLES:
        direction = "short" if verdict == "SHORT" else "long"
        stop   = round(price * (0.94 if direction == "long" else 1.06), 2)
        t1     = round(price * (1.08 if direction == "long" else 0.92), 2)
        entry  = round(price * 0.999, 2)
        is_buy = verdict == "BUY"
        r = {
            "ticker": tk, "name": name, "price": price, "score": score,
            "sector": sector, "industry": industry, "direction": direction,
            "rsi":  round(random.uniform(35, 75), 1),
            "rvol": round(random.uniform(0.8, 2.8), 2),
            "rs_rank": random.randint(30, 95),
            "atr_pct": round(random.uniform(1.0, 4.0), 2),
            "squeeze": random.random() > 0.7,
            "zacks_rank1": is_buy and random.random() > 0.4,
            "zacks_sell":  verdict in ("SHORT", "AVOID") and random.random() > 0.5,
            "beta": round(random.uniform(0.6, 1.8), 2),
            "price_tier": f"${int(price//50)*50}–${int(price//50)*50+50}",
            "decision": {"verdict": verdict, "reason": f"{setup} — score {score}"},
            "gate": {"passed": verdict != "KILLED"},
            "fundamentals": {"score": random.randint(10, 28), "bull_drivers": ["Revenue growth"], "bear_risks": [], "details": {}},
            "technicals":   {"score": random.randint(10, 28), "details": {}, "indicators": {}},
            "optionality":  {"score": random.randint(5, 18),  "details": {}, "bull_case": f"+{rr*5:.0f}% in 5d", "base_case": f"+{rr*3:.0f}% in 5d", "bear_case": f"-3% stop"},
            "sentiment":    {"score": random.randint(2, 9),   "details": {}},
            "bear_setup":   {"score": 0 if direction == "long" else random.randint(8, 14), "details": {}},
            "trade_plan": {
                "entry_low": entry, "entry_high": round(entry * 1.005, 2),
                "stop": stop, "target1": t1, "target2": round(price * (1.15 if direction == "long" else 0.86), 2),
                "rr_ratio": rr, "setup_type": setup, "allocation_pct": 7.5,
            },
            "catalyst_tags": ["Earnings beat"] if random.random() > 0.7 else [],
            "trade_thesis": f"{setup} on {tk} — {score}/100 score",
            "conviction": {"label": "High" if score >= 75 else "Medium" if score >= 60 else "Standard"},
            "entry_quality": "good",
            "zacks_vgm": {"value": random.choice(["A","B","C"]), "growth": random.choice(["A","B","C"]), "momentum": random.choice(["A","B","C"]), "vgm": random.choice(["A","B","C"])},
            "analyst": {},
            "stocktwits": {},
        }
        if verdict == "KILLED":
            killed.append(r)
        else:
            all_scored.append(r)

    buy_list = [r["ticker"] for r in all_scored if r["decision"]["verdict"] == "BUY"]
    sell_list = [r["ticker"] for r in all_scored if r["decision"]["verdict"] in ("SHORT", "AVOID")]
    watch_list = [r for r in all_scored if r["decision"]["verdict"] == "WATCH"]

    return {
        "config": {"output": {"html_output": "cache/dashboard.html"}},
        "run_date": datetime.now().strftime("%Y-%m-%d"),
        "buy_candidates":  [r for r in all_scored if r["decision"]["verdict"] == "BUY"],
        "sell_candidates": [r for r in all_scored if r["decision"]["verdict"] in ("SHORT", "AVOID")],
        "watch_list":      watch_list,
        "all_scored":      all_scored,
        "killed":          killed,
        "regime": {
            "regime": "bull", "spy_price": 494.50, "spy_1m_ret": 1.2,
            "above_50ema": True, "above_200sma": True,
            "market_cycle": "mid_bull", "distribution_days": 2,
            "vix": {"vix_current": 18.4, "regime": "normal", "trend": "stable"},
        },
        "market_breadth": {
            "pct_above_50d": 64.0, "label_50": "moderate",
            "pct_above_100d": 58.0, "label_100": "moderate",
        },
        "macro_signals": {
            "risk_signal": "risk-on",
            "yield_curve": {"spread": 0.32, "inverted": False},
            "hyg": {"trend": "up"}, "dxy": {"trend": "down"},
        },
        "sector_etf_data": {},
        "fear_greed": {"value": 58, "label": "Greed"},
        "industries": [],  # built from all_scored in _tab_industries
        "portfolio_risk": {},
        "price_tier_results": [],
        "zacks_r1_full": buy_list,
        "zacks_r1_scores": {r["ticker"]: r["zacks_vgm"] for r in all_scored if r.get("zacks_rank1")},
        "zacks_r1_missing": {},
        "zacks_sell_list_raw": [{"ticker": t, "company": next((r["name"] for r in all_scored if r["ticker"]==t), "")} for t in sell_list],
        "ultimate": {
            "overview": {"description": "Sample data — run a full scan for live data.", "stats": {"Total Trades": "329", "Avg Return": "+18.4%", "Win Rate": "67%"}, "highlights": []},
            "all_trades": [],
            "commentary": [{"title": "Sample Commentary", "author": "Dev Mode", "date": datetime.now().strftime("%m/%d/%y"), "body_text": "This is sample data generated for UI development. Run /swing-trade for live data."}],
            "special_reports": [],
            "confidential_commentary": [],
            "confidential_overview": {},
        },
        "tazr": {"trades": [], "portfolio_stats": {}, "commentary": []},
        "bbt": {"trades": [], "portfolio_stats": {}, "commentary": []},
        "counterstrike": {"trades": [], "portfolio_stats": {}, "commentary": []},
        "headlinetrader": {"trades": [], "portfolio_stats": {}, "commentary": []},
        "alt_energy": {"trades": [], "portfolio_stats": {}, "commentary": []},
        "blockchain": {"trades": [], "portfolio_stats": {}, "commentary": []},
        "tech_innovators": {"trades": [], "portfolio_stats": {}, "commentary": []},
        "social": {},
        "gmail_zacks": {},
        "watch_trigger_hits": [],
        "sp500_list": [r["ticker"] for r in all_scored],
        "russell1000_list": [r["ticker"] for r in all_scored],
        "market_data_count": len(all_scored),
        "total_scanned": len(all_scored),
        "run_timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "scores_table": all_scored,
    }


if __name__ == "__main__":
    args = sys.argv[1:]

    if not args or (len(args) == 1 and args[0].lower() == "--fresh"):
        run_daily_scan(force_fresh="--fresh" in args)
    elif args[0].lower() == "deep" and len(args) > 1:
        run_deep_dive(args[1].upper())
    elif args[0].lower() == "history":
        show_history()
    elif args[0].lower() == "add" and len(args) >= 5:
        # add TICKER ENTRY SHARES STOP TARGET1 [TARGET2]
        from portfolio_tracker import add_position
        ticker = args[1].upper()
        entry = float(args[2])
        shares = int(float(args[3]))
        stop = float(args[4])
        target1 = float(args[5]) if len(args) > 5 else entry * 1.10
        target2 = float(args[6]) if len(args) > 6 else None
        pos = add_position(ticker, entry, shares, stop, target1, target2)
        _entry_px = pos.get('entry_price', pos.get('entry'))
        print(f"Added: {pos['ticker']} {pos['shares']}sh @ ${_entry_px} | Stop ${pos['stop']} | T1 ${pos['target1']}")
    elif args[0].lower() == "close" and len(args) >= 3:
        # close TICKER EXIT_PRICE
        from portfolio_tracker import close_position
        result = close_position(args[1].upper(), float(args[2]))
        if result:
            print(f"Closed: {result['ticker']} @ ${result['exit_price']} | P&L {result['pnl_pct']:+.1f}%")
    elif args[0].lower() in ("regen", "dev"):
        # Re-render dashboard from cached bundle — no scan, no API calls
        bundle_path   = BASE_DIR / "cache" / "last_bundle.json"
        sample_path   = BASE_DIR / "cache" / "sample_bundle.json"
        from html_generator import build_dashboard
        if bundle_path.exists():
            with open(bundle_path) as _bf:
                _bundle = json.load(_bf)
            _cfg = _bundle.get("config", {})
            _out = BASE_DIR / _cfg.get("output", {}).get("html_output", "cache/dashboard.html")
            _path = build_dashboard(_bundle, _out)
            print(f"Dashboard re-rendered from cached bundle: {_path}")
        elif sample_path.exists():
            with open(sample_path) as _bf:
                _bundle = json.load(_bf)
            _cfg = _bundle.get("config", {})
            _out = BASE_DIR / _cfg.get("output", {}).get("html_output", "cache/dashboard.html")
            _path = build_dashboard(_bundle, _out)
            print(f"Dashboard re-rendered from sample bundle: {_path}")
        else:
            print("No cached bundle found. Run a full scan first, or use:")
            print("  python3 swing_trade.py sample   # generate sample dashboard")
    elif args[0].lower() == "sample":
        # Generate a sample dashboard with mock data — no scan, no API calls
        _sample_bundle = _build_sample_bundle()
        _out = BASE_DIR / "cache" / "dashboard.html"
        from html_generator import build_dashboard
        _path = build_dashboard(_sample_bundle, _out)
        # Also save as sample_bundle.json for future dev regen
        _sbp = BASE_DIR / "cache" / "sample_bundle.json"
        _sbp.parent.mkdir(parents=True, exist_ok=True)
        with open(_sbp, "w") as _sf:
            json.dump(_sample_bundle, _sf, default=str)
        print(f"Sample dashboard generated: {_path}")
    else:
        print("Usage:")
        print("  python3 swing_trade.py                              # Daily scan (uses Zacks cache if <20h old)")
        print("  python3 swing_trade.py --fresh                     # Daily scan, force fresh Zacks scrape")
        print("  python3 swing_trade.py regen                       # Re-render dashboard (no re-scan) [alias: dev]")
        print("  python3 swing_trade.py sample                      # Generate sample dashboard with mock data")
        print("  python3 swing_trade.py deep NVDA                   # Deep dive")
        print("  python3 swing_trade.py history                     # Performance stats")
        print("  python3 swing_trade.py add NVDA 89.50 100 83.50 98.00  # Add position")
        print("  python3 swing_trade.py close NVDA 94.00            # Close position")
