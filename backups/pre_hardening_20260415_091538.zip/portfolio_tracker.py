"""
Portfolio state tracker for SwingTrade — Config E defaults.

Maintains data/portfolio_state.json with equity curve, open/closed positions,
trailing stops, and monthly P&L.  Zero external dependencies (json/pathlib/datetime only).
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, date
from pathlib import Path

log = logging.getLogger("portfolio_tracker")

BASE_DIR = Path(__file__).parent
STATE_PATH = BASE_DIR / "data" / "portfolio_state.json"
CONFIG_PATH = BASE_DIR / "config" / "config.json"

# ── Schema versioning ───────────────────────────────────────────────────────
# Bump when the on-disk shape of portfolio_state.json changes.
PORTFOLIO_SCHEMA_VERSION = 2


# ── Config E defaults (loaded from config.json if available) ────────────────

def _load_config_e() -> dict:
    """Return config_e block from config.json, falling back to hardcoded defaults."""
    defaults = {
        "max_positions": 4,
        "pct_per_trade": 0.30,
        "hold_days": 5,
        "max_hold_days": 10,
        "trail_activate_pct": 2.0,
        "trail_atr_mult": 1.25,
        "time_stop_flat_pct": 1.0,
        "exclude_setups": ["52wk Breakout"],
        "verdict_filter": ["BUY"],
        "starting_equity": 5000,
    }
    try:
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
        return cfg.get("portfolio", {}).get("config_e", defaults)
    except (FileNotFoundError, json.JSONDecodeError):
        return defaults


CFG = _load_config_e()


# ── Undo-close queue (in-memory, TTL-bound) ────────────────────────────────
_UNDO_QUEUE: dict = {}  # {undo_id: {"closed_trade": ..., "timestamp": ...}}
UNDO_WINDOW_SECONDS = 60


# ── State persistence ───────────────────────────────────────────────────────

def _empty_state() -> dict:
    today = date.today().isoformat()
    equity = CFG.get("starting_equity", 5000)
    return {
        "_schema_version": PORTFOLIO_SCHEMA_VERSION,
        "equity": equity,
        "cash": equity,
        "positions": [],
        "closed_trades": [],
        "monthly_pnl": {},
        "equity_curve": [{"date": today, "equity": equity}],
        "margin_reserved": 0,
        "equity_audit": [],
    }


def _default_state() -> dict:
    """Fresh default state at the current schema version."""
    return {
        "_schema_version": PORTFOLIO_SCHEMA_VERSION,
        "equity": 5000,
        "cash": 5000,
        "positions": [],
        "closed_trades": [],
        "monthly_pnl": {},
        "margin_reserved": 0,
        "equity_audit": [],
    }


def _migrate_state(state: dict, from_version: int) -> dict:
    """Apply sequential, idempotent migrations from `from_version` to
    PORTFOLIO_SCHEMA_VERSION.  Additive only — never deletes data."""
    if from_version < 1:
        # v0 → v1: unify naming and ensure base keys exist
        if "closed" in state and "closed_trades" not in state:
            state["closed_trades"] = state.pop("closed")
        state.setdefault("closed_trades", [])
        state.setdefault("monthly_pnl", {})
        state.setdefault("positions", [])
        state.setdefault("equity", 5000)
        state.setdefault("cash", 5000)
    if from_version < 2:
        # v1 → v2: margin accounting + equity audit + per-position direction
        state.setdefault("margin_reserved", 0)
        state.setdefault("equity_audit", [])
        for p in state.get("positions", []):
            p.setdefault("direction", "long")
    # Future migrations: add further `if from_version < N:` branches here.
    return state


_LEGACY_CHECKED = False
_LEGACY_PATH = BASE_DIR / "cache" / "portfolio.json"
_LEGACY_MARKER = BASE_DIR / "data" / "_legacy_migration_checked.marker"


def _check_legacy_migration():
    """One-time check: warn if cache/portfolio.json has data not in current state."""
    if _LEGACY_MARKER.exists() or not _LEGACY_PATH.exists():
        return
    try:
        with open(_LEGACY_PATH) as f:
            legacy = json.load(f)
        legacy_positions = legacy.get("positions", [])
        legacy_closed = legacy.get("closed_trades", legacy.get("closed", []))
        if legacy_positions or legacy_closed:
            log.warning(
                "\u26a0\ufe0f  Legacy portfolio data detected in cache/portfolio.json "
                f"({len(legacy_positions)} open positions, {len(legacy_closed)} closed). "
                "This file is NOT being read. If you want to preserve these trades, "
                "run: python3 -c 'from portfolio_tracker import migrate_legacy; "
                "print(migrate_legacy())'"
            )
        # Mark as checked regardless (one-time warning)
        _LEGACY_MARKER.parent.mkdir(parents=True, exist_ok=True)
        _LEGACY_MARKER.write_text(datetime.now().isoformat())
    except Exception as e:
        log.debug(f"Legacy migration check failed: {e}")


def _load_state() -> dict:
    global _LEGACY_CHECKED
    if not _LEGACY_CHECKED:
        _check_legacy_migration()
        _LEGACY_CHECKED = True
    if not STATE_PATH.exists():
        return _default_state()
    with open(STATE_PATH) as f:
        state = json.load(f)
    current = state.get("_schema_version", 0)
    if current < PORTFOLIO_SCHEMA_VERSION:
        state = _migrate_state(state, from_version=current)
        _save_state(state)
        log.info(
            "Migrated portfolio_state from v%s to v%s",
            current, PORTFOLIO_SCHEMA_VERSION,
        )
    return state


def migrate_legacy() -> dict:
    """Manually migrate positions from cache/portfolio.json to data/portfolio_state.json.

    Non-destructive: never deletes the legacy file.
    Idempotent: running twice produces the same state (tickers/closed trades are deduped).
    Merges: skips tickers already in current open positions; skips closed trades
    matching on (ticker, entry_date, exit_date).
    Returns {migrated, skipped, errors, migrated_closed, skipped_closed, errors_closed}.
    """
    if not _LEGACY_PATH.exists():
        return {"error": "No legacy file to migrate"}

    try:
        with open(_LEGACY_PATH) as f:
            legacy = json.load(f)
    except Exception as e:
        return {"error": f"Failed to read legacy: {e}"}

    state = _load_state()
    existing_tickers = {p.get("ticker", "").upper() for p in state.get("positions", [])}

    migrated, skipped, errors = [], [], []
    for leg_pos in legacy.get("positions", []):
        ticker = (leg_pos.get("ticker") or "").upper()
        if not ticker:
            errors.append({"pos": leg_pos, "reason": "no ticker"})
            continue
        if ticker in existing_tickers:
            skipped.append(ticker)
            continue
        try:
            entry = float(leg_pos.get("entry", leg_pos.get("entry_price", 0)))
            shares = int(leg_pos.get("shares", 0))
            current_price = float(leg_pos.get("current_price", entry))
            mapped = {
                "ticker": ticker,
                "direction": leg_pos.get("direction", "long"),
                "entry_price": entry,
                "shares": shares,
                "stop": float(leg_pos.get("stop", 0)),
                "target1": float(leg_pos.get("target1", 0)),
                "target2": leg_pos.get("target2"),
                "setup_type": leg_pos.get("setup", leg_pos.get("setup_type", "")),
                "entry_date": leg_pos.get(
                    "entry_date", datetime.now().strftime("%Y-%m-%d")
                ),
                "allocation_pct": float(leg_pos.get("allocation_pct", 7.5)),
                "notes": leg_pos.get("notes") or "(migrated from legacy)",
                "current_price": current_price,
                "position_size": entry * shares,
                "trail_stop": float(leg_pos.get("stop", 0)),
                "trail_active": False,
                "highest_price": current_price,
            }
            state["positions"].append(mapped)
            existing_tickers.add(ticker)
            migrated.append(ticker)
        except Exception as e:
            errors.append({"ticker": ticker, "reason": str(e)})

    # Closed trades — dedupe by (ticker, entry_date, exit_date)
    existing_closed_keys = {
        (
            (c.get("ticker") or "").upper(),
            c.get("entry_date", ""),
            c.get("exit_date", ""),
        )
        for c in state.get("closed_trades", [])
    }
    legacy_closed = legacy.get("closed_trades", legacy.get("closed", []))
    migrated_closed, skipped_closed, errors_closed = [], [], []
    for leg_c in legacy_closed:
        ticker = (leg_c.get("ticker") or "").upper()
        if not ticker:
            errors_closed.append({"pos": leg_c, "reason": "no ticker"})
            continue
        key = (ticker, leg_c.get("entry_date", ""), leg_c.get("exit_date", ""))
        if key in existing_closed_keys:
            skipped_closed.append(ticker)
            continue
        try:
            entry = float(leg_c.get("entry", leg_c.get("entry_price", 0)))
            exit_price = float(leg_c.get("exit", leg_c.get("exit_price", 0)))
            shares = int(leg_c.get("shares", 0))
            mapped_c = dict(leg_c)
            mapped_c["ticker"] = ticker
            mapped_c.setdefault("direction", "long")
            mapped_c["entry_price"] = entry
            mapped_c["exit_price"] = exit_price
            mapped_c["shares"] = shares
            mapped_c.setdefault(
                "setup_type", leg_c.get("setup", leg_c.get("setup_type", ""))
            )
            mapped_c.setdefault("notes", "(migrated from legacy)")
            state.setdefault("closed_trades", []).append(mapped_c)
            existing_closed_keys.add(key)
            migrated_closed.append(ticker)
        except Exception as e:
            errors_closed.append({"ticker": ticker, "reason": str(e)})

    if migrated or migrated_closed:
        _save_state(state)
        log.info(
            "Legacy migration: %d open, %d closed migrated (skipped %d open, %d closed)",
            len(migrated), len(migrated_closed), len(skipped), len(skipped_closed),
        )

    return {
        "migrated": migrated,
        "skipped": skipped,
        "errors": errors,
        "migrated_closed": migrated_closed,
        "skipped_closed": skipped_closed,
        "errors_closed": errors_closed,
    }


def _save_state(state: dict):
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    state["_schema_version"] = PORTFOLIO_SCHEMA_VERSION
    state["_last_saved"] = datetime.now().isoformat()
    with open(STATE_PATH, "w") as f:
        json.dump(state, f, indent=2, default=str)


# ── Mechanical paper-trading gates (BUY-only, 4/day, 60-day window) ─────────
# Introduced for the Phase-4 paper-trading activation. Policy:
#   - BUY-only for the 60-day window; SHORTs will be re-enabled later.
#   - Hard cap of MAX_DAILY_TRADES trades opened in a single calendar day.
#   - Auto-disable after PAPER_TRADING_DURATION_DAYS so the user can't forget.
#   - Activation is explicit: call activate_paper_trading() or run
#     `python3 executor.py --activate`. No implicit enable.

PAPER_TRADING_MARKER = BASE_DIR / "data" / "paper_trading_start.json"
PAPER_TRADING_DURATION_DAYS = 60
MAX_DAILY_TRADES = 4


def daily_trades_taken_today() -> int:
    """Count how many trades opened today (open + closed) in portfolio state."""
    state = _load_state()
    today = date.today().isoformat()
    open_today = sum(
        1 for p in state.get("positions", [])
        if str(p.get("entry_date", ""))[:10] == today
    )
    closed_today = sum(
        1 for t in state.get("closed_trades", [])
        if str(t.get("entry_date", ""))[:10] == today
    )
    return open_today + closed_today


def can_take_new_trade() -> tuple[bool, str]:
    """Return (ok, reason). False when today's trade count >= MAX_DAILY_TRADES."""
    count = daily_trades_taken_today()
    if count >= MAX_DAILY_TRADES:
        return False, f"Daily trade limit reached ({count}/{MAX_DAILY_TRADES})"
    return True, f"{count}/{MAX_DAILY_TRADES} trades taken today"


def is_paper_trading_enabled() -> tuple[bool, str]:
    """Return (enabled, reason). Reads the marker file; auto-expires after duration."""
    if not PAPER_TRADING_MARKER.exists():
        return False, "Not activated. Run activate_paper_trading() to enable."
    try:
        with open(PAPER_TRADING_MARKER) as f:
            d = json.load(f)
        if not d.get("enabled", False):
            return False, "Paper trading disabled"
        start = date.fromisoformat(d["start_date"])
        elapsed = (date.today() - start).days
        duration = int(d.get("duration_days", PAPER_TRADING_DURATION_DAYS))
        if elapsed >= duration:
            return False, f"Paper trading period ended ({elapsed}d since {start.isoformat()})"
        return True, f"Day {elapsed + 1}/{duration}"
    except Exception as e:
        return False, f"Error reading marker: {e}"


def activate_paper_trading(duration_days: int = PAPER_TRADING_DURATION_DAYS) -> dict:
    """Create the marker file with today's date. Idempotent — overwrites start_date."""
    PAPER_TRADING_MARKER.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "start_date": date.today().isoformat(),
        "duration_days": int(duration_days),
        "enabled": True,
        "direction_filter": "buy_only",
        "max_daily_trades": MAX_DAILY_TRADES,
    }
    with open(PAPER_TRADING_MARKER, "w") as f:
        json.dump(payload, f, indent=2)
    log.info(f"Paper trading ACTIVATED — {duration_days}d duration, BUY-only, cap {MAX_DAILY_TRADES}/day")
    return payload


def disable_paper_trading() -> dict:
    """Flip enabled=False in the marker file. Preserves start_date for audit."""
    if not PAPER_TRADING_MARKER.exists():
        log.info("Paper trading marker missing — nothing to disable")
        return {"enabled": False, "reason": "marker missing"}
    with open(PAPER_TRADING_MARKER) as f:
        d = json.load(f)
    d["enabled"] = False
    d["disabled_at"] = datetime.now().isoformat()
    with open(PAPER_TRADING_MARKER, "w") as f:
        json.dump(d, f, indent=2)
    log.info("Paper trading DISABLED")
    return d


def paper_trading_status() -> dict:
    """Structured status dict for CLI / HTML consumption."""
    enabled, reason = is_paper_trading_enabled()
    marker = {}
    if PAPER_TRADING_MARKER.exists():
        try:
            with open(PAPER_TRADING_MARKER) as f:
                marker = json.load(f)
        except Exception:
            marker = {}
    return {
        "enabled": enabled,
        "reason": reason,
        "daily_count": daily_trades_taken_today(),
        "daily_cap": MAX_DAILY_TRADES,
        "marker": marker,
    }


# ── Diagnostics ─────────────────────────────────────────────────────────────

def get_schema_info() -> dict:
    """Return schema versions of all tracked state files for diagnostics."""
    info: dict = {}
    candidates = [
        ("portfolio", STATE_PATH),
        ("signal_log", BASE_DIR / "data" / "signal_log.json"),
    ]
    for name, path in candidates:
        if not path.exists():
            info[name] = {"exists": False}
            continue
        try:
            with open(path) as f:
                data = json.load(f)
            if isinstance(data, list):
                info[name] = {
                    "current": "list (no version)",
                    "count": len(data),
                }
            else:
                info[name] = {
                    "current": data.get("_schema_version", 0),
                    "last_saved": data.get("_last_saved", "unknown"),
                }
        except Exception as e:
            info[name] = {"error": str(e)}
    return info


# ── Public API ──────────────────────────────────────────────────────────────

def add_position(ticker: str, entry_price: float, shares: int,
                 stop: float, target1: float,
                 target2: float | None = None,
                 setup_type: str = "",
                 direction: str = "long",
                 allocation_pct: float = 7.5,
                 notes: str = "",
                 entry_date: str | None = None) -> dict:
    """
    Open a new position.  Deducts cost from cash (treated as collateral
    for shorts in this paper-trading model — no separate margin handling).
    Returns the new position dict or raises ValueError.
    """
    state = _load_state()
    max_pos = CFG.get("max_positions", 4)

    if len(state["positions"]) >= max_pos:
        raise ValueError(f"Max {max_pos} concurrent positions — close one first.")

    # Reject excluded setups (e.g. 52wk Breakout unless overridden)
    excluded = CFG.get("exclude_setups", [])
    if setup_type in excluded:
        raise ValueError(f"Setup '{setup_type}' is excluded by Config E.")

    position_value = round(entry_price * shares, 2)

    pos = {
        "ticker": ticker.upper(),
        "entry_date": entry_date if entry_date else date.today().isoformat(),
        "entry_price": round(entry_price, 2),
        "shares": int(shares),
        "position_size": position_value,
        "stop": round(stop, 2),
        "trail_stop": round(stop, 2),
        "trail_active": False,
        "highest_price": round(entry_price, 2),
        "setup_type": setup_type,
        "target1": round(target1, 2),
        "target2": round(target2, 2) if target2 else None,
        "direction": direction,
        "allocation_pct": allocation_pct,
        "notes": notes,
    }

    if direction == "long":
        if position_value > state["cash"]:
            raise ValueError(f"Insufficient cash: need ${position_value:.2f}, have ${state['cash']:.2f}")
        state["cash"] = round(state["cash"] - position_value, 2)
    else:  # short — reserve 50% margin, no cash movement
        margin = round(position_value * 0.5, 2)
        available = round(state["cash"] - state.get("margin_reserved", 0), 2)
        if margin > available:
            raise ValueError(
                f"Insufficient margin: need ${margin:.2f} (50% of ${position_value:.2f}), "
                f"available ${available:.2f}"
            )
        state["margin_reserved"] = round(state.get("margin_reserved", 0) + margin, 2)
        pos["margin_reserved"] = margin

    state["positions"].append(pos)
    _save_state(state)
    return pos


def close_position(ticker: str, exit_price: float,
                   exit_reason: str = "manual") -> dict:
    """
    Close an open position by ticker.  Credits proceeds to cash,
    records the trade in closed_trades and updates monthly P&L.
    Returns the closed-trade record.
    """
    state = _load_state()
    ticker = ticker.upper()
    idx = None
    for i, p in enumerate(state["positions"]):
        if p["ticker"] == ticker:
            idx = i
            break
    if idx is None:
        raise ValueError(f"No open position for {ticker}")

    pos = state["positions"].pop(idx)
    direction = pos.get("direction", "long")
    shares = pos["shares"]
    entry_price = pos["entry_price"]
    position_value = pos.get("position_size", round(entry_price * shares, 2))

    if direction == "long":
        proceeds = round(exit_price * shares, 2)
        state["cash"] = round(state["cash"] + proceeds, 2)
        pnl_dollars = round((exit_price - entry_price) * shares, 2)
    else:  # short — no cash moved on open, credit P&L delta only, release margin
        pnl_dollars = round((entry_price - exit_price) * shares, 2)
        state["cash"] = round(state["cash"] + pnl_dollars, 2)
        margin_held = pos.get("margin_reserved", round(position_value * 0.5, 2))
        state["margin_reserved"] = max(
            0, round(state.get("margin_reserved", 0) - margin_held, 2)
        )

    denom = entry_price * shares
    pnl_pct = round((pnl_dollars / denom) * 100, 2) if denom > 0 else 0.0

    today = date.today().isoformat()
    month_key = today[:7]  # e.g. "2026-04"

    trade = {
        "ticker": pos["ticker"],
        "entry_date": pos["entry_date"],
        "exit_date": today,
        "entry_price": pos["entry_price"],
        "exit_price": round(exit_price, 2),
        "shares": shares,
        "direction": direction,
        "pnl_dollars": pnl_dollars,
        "pnl_pct": pnl_pct,
        "exit_reason": exit_reason,
        "setup_type": pos.get("setup_type", ""),
    }

    state["closed_trades"].append(trade)

    # Monthly P&L
    state["monthly_pnl"][month_key] = round(
        state["monthly_pnl"].get(month_key, 0) + pnl_dollars, 2
    )

    # Update equity = cash + invested value of remaining LONG positions (shorts are liabilities, tracked separately)
    invested = sum(
        p["entry_price"] * p["shares"]
        for p in state["positions"]
        if p.get("direction", "long") == "long"
    )
    state["equity"] = round(state["cash"] + invested, 2)

    # Equity curve
    state["equity_curve"].append({"date": today, "equity": state["equity"]})

    _save_state(state)

    # ── Register undo entry (in-memory, TTL-bound) ─────────────────────────
    import uuid as _uuid, time as _time
    undo_id = str(_uuid.uuid4())[:8]
    # Preserve original open-position details so we can reconstruct on undo
    undo_snapshot = dict(trade)
    undo_snapshot["stop"] = pos.get("stop")
    undo_snapshot["target1"] = pos.get("target1")
    undo_snapshot["target2"] = pos.get("target2")
    undo_snapshot["allocation_pct"] = pos.get("allocation_pct", 7.5)
    undo_snapshot["notes"] = pos.get("notes", "")
    undo_snapshot["trail_stop"] = pos.get("trail_stop")
    undo_snapshot["margin_reserved"] = pos.get("margin_reserved")
    _UNDO_QUEUE[undo_id] = {
        "closed_trade": undo_snapshot,
        "timestamp": _time.time(),
    }
    # Cleanup expired entries (>120s)
    _now = _time.time()
    for _k in [k for k, v in _UNDO_QUEUE.items() if _now - v["timestamp"] > 120]:
        _UNDO_QUEUE.pop(_k, None)

    trade["undo_id"] = undo_id
    return trade


def undo_close(undo_id: str) -> dict:
    """Re-open a recently-closed position. Must be called within UNDO_WINDOW_SECONDS."""
    import time
    entry = _UNDO_QUEUE.get(undo_id)
    if not entry:
        raise ValueError("Undo ID not found or expired")
    if time.time() - entry["timestamp"] > UNDO_WINDOW_SECONDS:
        _UNDO_QUEUE.pop(undo_id, None)
        raise ValueError(f"Undo window expired ({UNDO_WINDOW_SECONDS}s)")

    closed = entry["closed_trade"]
    state = _load_state()

    # Remove from closed_trades
    ct = state.get("closed_trades", [])
    state["closed_trades"] = [t for t in ct if not (
        t.get("ticker") == closed["ticker"] and
        t.get("exit_date") == closed.get("exit_date") and
        t.get("exit_price") == closed.get("exit_price")
    )]

    entry_price = closed.get("entry_price", closed.get("entry"))
    shares = closed["shares"]
    # Reconstruct open position
    pos = {
        "ticker": closed["ticker"],
        "direction": closed.get("direction", "long"),
        "entry_price": entry_price,
        "shares": shares,
        "stop": closed.get("stop") if closed.get("stop") is not None else entry_price * 0.95,
        "target1": closed.get("target1") if closed.get("target1") is not None else entry_price * 1.1,
        "target2": closed.get("target2"),
        "setup_type": closed.get("setup_type", closed.get("setup", "")),
        "entry_date": closed.get("entry_date"),
        "allocation_pct": closed.get("allocation_pct", 7.5),
        "notes": closed.get("notes", ""),
        "trail_stop": closed.get("trail_stop") if closed.get("trail_stop") is not None else (closed.get("stop") if closed.get("stop") is not None else entry_price * 0.95),
        "trail_active": False,
        "highest_price": entry_price,
        "current_price": entry_price,
        "position_size": round((entry_price or 0) * (shares or 0), 2),
    }
    state["positions"].append(pos)

    # Restore cash / margin state based on direction
    direction = pos["direction"]
    pnl = closed.get("pnl_dollars", 0)
    if direction == "long":
        # On close we credited proceeds = exit_price * shares to cash.
        # Reverse the full proceeds to restore pre-close cash.
        proceeds = round(closed.get("exit_price", 0) * shares, 2)
        state["cash"] = round(state.get("cash", 0) - proceeds, 2)
    else:  # short — on close we credited pnl to cash and released margin
        margin = closed.get("margin_reserved") or round(pos["position_size"] * 0.5, 2)
        state["margin_reserved"] = round(state.get("margin_reserved", 0) + margin, 2)
        state["cash"] = round(state.get("cash", 0) - pnl, 2)

    # Reverse monthly P&L credit
    exit_date = closed.get("exit_date", "")
    month_key = exit_date[:7] if exit_date else ""
    if month_key and month_key in state.get("monthly_pnl", {}):
        state["monthly_pnl"][month_key] = round(
            state["monthly_pnl"].get(month_key, 0) - pnl, 2
        )

    # Recompute equity
    invested = sum(
        p["entry_price"] * p["shares"]
        for p in state["positions"]
        if p.get("direction", "long") == "long"
    )
    state["equity"] = round(state.get("cash", 0) + invested, 2)

    _save_state(state)
    _UNDO_QUEUE.pop(undo_id, None)

    return {"ok": True, "position": pos, "message": f"Re-opened {pos['ticker']}"}


def update_notes(ticker: str, notes: str) -> dict:
    """Update the notes field on an open position. Returns updated position."""
    state = _load_state()
    ticker = ticker.upper()
    for p in state["positions"]:
        if p["ticker"] == ticker:
            p["notes"] = str(notes)[:500]  # cap at 500 chars
            _save_state(state)
            return {"ticker": ticker, "notes": p["notes"]}
    raise ValueError(f"No open position for {ticker}")


def move_stop_to_breakeven(ticker: str) -> dict:
    """Set the stop (and trail_stop) of the given open position to entry price."""
    state = _load_state()
    ticker = ticker.upper()
    for p in state["positions"]:
        if p["ticker"] == ticker:
            p["stop"] = round(float(p["entry_price"]), 2)
            p["trail_stop"] = max(p.get("trail_stop", 0) or 0, p["stop"])
            _save_state(state)
            return {"ok": True, "ticker": ticker, "new_stop": p["stop"]}
    raise ValueError(f"No open position for {ticker}")


def trail_stop(ticker: str, atr_mult: float = 1.5) -> dict:
    """Move stop to current_price - atr_mult * ATR proxy. Only ratchets up."""
    state = _load_state()
    ticker = ticker.upper()
    for p in state["positions"]:
        if p["ticker"] == ticker:
            cur = float(p.get("current_price") or p["entry_price"])
            atr = abs(float(p["entry_price"]) - float(p.get("stop", p["entry_price"] * 0.97)))
            if atr <= 0:
                atr = float(p["entry_price"]) * 0.02
            new_stop = round(cur - atr_mult * atr, 2)
            prev = float(p.get("trail_stop") or p.get("stop") or 0)
            if new_stop > prev:
                p["trail_stop"] = new_stop
                p["stop"] = new_stop
                p["trail_active"] = True
            _save_state(state)
            return {"ok": True, "ticker": ticker, "new_stop": p.get("trail_stop", p["stop"])}
    raise ValueError(f"No open position for {ticker}")


def partial_close(ticker: str, pct: float = 0.5, exit_price: float | None = None) -> dict:
    """Close ``pct`` fraction of the open position. Remaining shares stay open.

    Records a closed-trade entry for the sold shares and credits cash.
    """
    state = _load_state()
    ticker = ticker.upper()
    for p in state["positions"]:
        if p["ticker"] == ticker:
            total_shares = int(p["shares"])
            close_shares = max(1, int(total_shares * float(pct)))
            if close_shares >= total_shares:
                # Full close — delegate
                return close_position(ticker, float(exit_price or p.get("current_price") or p["entry_price"]), "partial_full")
            px = float(exit_price) if exit_price else float(p.get("current_price") or p["entry_price"])
            proceeds = round(px * close_shares, 2)
            cost_basis = round(float(p["entry_price"]) * close_shares, 2)
            pnl_dollars = round(proceeds - cost_basis, 2)
            pnl_pct = round((px / float(p["entry_price"]) - 1) * 100, 2) if p["entry_price"] else 0.0
            today = date.today().isoformat()
            month_key = today[:7]
            trade = {
                "ticker": ticker,
                "entry_date": p["entry_date"],
                "exit_date": today,
                "entry_price": p["entry_price"],
                "exit_price": round(px, 2),
                "shares": close_shares,
                "pnl_dollars": pnl_dollars,
                "pnl_pct": pnl_pct,
                "exit_reason": "partial_t1",
                "setup_type": p.get("setup_type", ""),
            }
            state["closed_trades"].append(trade)
            state["cash"] = round(state["cash"] + proceeds, 2)
            state["monthly_pnl"][month_key] = round(state["monthly_pnl"].get(month_key, 0) + pnl_dollars, 2)
            # Reduce position in place
            p["shares"] = total_shares - close_shares
            p["position_size"] = round(float(p["entry_price"]) * p["shares"], 2)
            _save_state(state)
            return {"ok": True, "ticker": ticker, "closed_shares": close_shares,
                    "remaining_shares": p["shares"], "pnl_dollars": pnl_dollars}
    raise ValueError(f"No open position for {ticker}")


def adjust_stop(ticker: str, new_stop: float) -> dict:
    """Set an explicit new stop price for an open position."""
    state = _load_state()
    ticker = ticker.upper()
    new_stop = round(float(new_stop), 2)
    if new_stop <= 0:
        raise ValueError("new_stop must be > 0")
    for p in state["positions"]:
        if p["ticker"] == ticker:
            p["stop"] = new_stop
            if new_stop > (p.get("trail_stop") or 0):
                p["trail_stop"] = new_stop
            _save_state(state)
            return {"ok": True, "ticker": ticker, "new_stop": new_stop}
    raise ValueError(f"No open position for {ticker}")


def update_prices(price_map: dict[str, float]) -> list[dict]:
    """
    Update current prices for open positions.  Adjusts trailing stops
    and returns a list of positions whose trail stop was hit.

    price_map: {"FCX": 69.50, "AAPL": 195.20, ...}
    """
    state = _load_state()
    stopped_out = []
    trail_activate_pct = CFG.get("trail_activate_pct", 2.0)
    trail_atr_mult = CFG.get("trail_atr_mult", 1.25)

    for pos in state["positions"]:
        ticker = pos["ticker"]
        if ticker not in price_map:
            continue

        current = price_map[ticker]
        entry = pos["entry_price"]

        # Track highest price
        if current > pos.get("highest_price", entry):
            pos["highest_price"] = round(current, 2)

        # Activate trailing stop once gain >= threshold
        gain_pct = ((current / entry) - 1) * 100 if entry else 0
        if gain_pct >= trail_activate_pct and not pos.get("trail_active", False):
            pos["trail_active"] = True

        # Update trailing stop if active
        if pos.get("trail_active", False):
            # Simple trailing: highest - trail_atr_mult * (entry - original_stop) as ATR proxy
            atr_proxy = abs(entry - pos["stop"])
            new_trail = round(pos["highest_price"] - trail_atr_mult * atr_proxy, 2)
            if new_trail > pos.get("trail_stop", pos["stop"]):
                pos["trail_stop"] = new_trail

        # Check if stop was hit
        effective_stop = pos.get("trail_stop", pos["stop"])
        if current <= effective_stop:
            stopped_out.append(pos)

    # Recalculate equity
    invested = 0
    for pos in state["positions"]:
        ticker = pos["ticker"]
        px = price_map.get(ticker, pos["entry_price"])
        invested += px * pos["shares"]
    state["equity"] = round(state["cash"] + invested, 2)

    today = date.today().isoformat()
    curve = state.get("equity_curve", [])
    if not curve or curve[-1]["date"] != today:
        curve.append({"date": today, "equity": state["equity"]})
    else:
        curve[-1]["equity"] = state["equity"]
    state["equity_curve"] = curve

    _save_state(state)
    return stopped_out


def get_open_slots() -> int:
    """Return number of available position slots."""
    state = _load_state()
    max_pos = CFG.get("max_positions", 4)
    return max(0, max_pos - len(state["positions"]))


def set_equity(new_equity: float, reason: str = "") -> dict:
    """Set portfolio equity. Adjusts cash = new_equity - invested_amount."""
    state = _load_state()
    new_equity = round(float(new_equity), 2)
    if new_equity <= 0:
        raise ValueError("Equity must be positive")

    invested = round(sum(
        p.get("shares", 0) * p.get("entry_price", 0)
        for p in state.get("positions", [])
        if p.get("direction", "long") == "long"
    ), 2)

    if new_equity < invested:
        raise ValueError(f"Equity ${new_equity} less than invested ${invested}. Close positions first.")

    new_cash = round(new_equity - invested, 2)
    old_equity = state.get("equity", 0)
    old_cash = state.get("cash", 0)

    state["equity"] = new_equity
    state["cash"] = new_cash

    # Audit log
    audit = state.setdefault("equity_audit", [])
    audit.append({
        "timestamp": datetime.now().isoformat(),
        "old_equity": old_equity,
        "new_equity": new_equity,
        "old_cash": old_cash,
        "new_cash": new_cash,
        "invested": invested,
        "reason": reason or "manual edit",
    })

    _save_state(state)
    return {"equity": new_equity, "cash": new_cash, "invested": invested}


def get_equity_audit_log(limit: int = 50) -> list[dict]:
    """Return recent equity change audit entries, newest first."""
    state = _load_state()
    audit = state.get("equity_audit", [])
    return list(reversed(audit[-limit:]))


def _add_earnings_context(summary: dict) -> dict:
    """Enrich open positions with ``days_to_earnings`` / ``earnings_date``.

    Uses ``data_fetcher.get_earnings_date`` (which is itself @_mem_cached for 2h,
    so repeated render calls within a scan hit the in-process cache rather than
    re-fetching). Graceful: any failure is swallowed and the position is left
    un-annotated.

    ``get_earnings_date`` returns ``{"earnings_date": "...", "days_to_earnings": N,
    "earnings_risk": bool}`` — we normalize that, and also accept a raw date /
    datetime / ISO string for forward-compat.
    """
    try:
        from data_fetcher import get_earnings_date
    except Exception:
        return summary

    from datetime import date as _d, datetime as _dt
    today = _d.today()
    for p in summary.get("positions", []) or []:
        try:
            tkr = str(p.get("ticker", "") or "").upper()
            if not tkr:
                continue
            res = get_earnings_date(tkr)
            ed_date = None
            delta = None
            if isinstance(res, dict):
                dte = res.get("days_to_earnings")
                raw = res.get("earnings_date")
                if dte is not None:
                    try:
                        delta = int(dte)
                    except Exception:
                        delta = None
                if raw:
                    try:
                        ed_date = _dt.strptime(str(raw)[:10], "%Y-%m-%d").date()
                    except Exception:
                        ed_date = None
            elif isinstance(res, str):
                try:
                    ed_date = _dt.strptime(res[:10], "%Y-%m-%d").date()
                except Exception:
                    ed_date = None
            elif hasattr(res, "year"):
                ed_date = res if not hasattr(res, "date") else res.date() if hasattr(res, "hour") else res
            if delta is None and ed_date is not None:
                delta = (ed_date - today).days
            if delta is not None and 0 <= delta <= 30:
                p["days_to_earnings"] = delta
                if ed_date is not None:
                    p["earnings_date"] = ed_date.isoformat()
        except Exception:
            continue
    return summary


def get_portfolio_summary() -> dict:
    """
    Return a summary dict for the dashboard:
      equity, cash, invested, positions, open_slots, open_pnl,
      closed_pnl, monthly_pnl, equity_curve, win_rate
    """
    state = _load_state()
    max_pos = CFG.get("max_positions", 4)

    # Calculate days_held for each position
    from datetime import date as _date
    _today = _date.today()
    for p in state["positions"]:
        try:
            _entry = _date.fromisoformat(str(p.get("entry_date", ""))[:10])
            p["days_held"] = (_today - _entry).days
        except Exception:
            p["days_held"] = 0

    # Invested = cash committed to longs only (shorts move no cash on open)
    invested = sum(
        p["position_size"] for p in state["positions"]
        if p.get("direction", "long") == "long"
    )
    # Short exposure shown separately for risk display
    short_exposure = sum(
        p["position_size"] for p in state["positions"]
        if p.get("direction", "long") == "short"
    )
    open_count = len(state["positions"])
    closed = state.get("closed_trades", [])
    closed_pnl = sum(t.get("pnl_dollars", 0) for t in closed)
    wins = sum(1 for t in closed if t.get("pnl_dollars", 0) > 0)
    losses = sum(1 for t in closed if t.get("pnl_dollars", 0) <= 0)
    win_rate = round(wins / len(closed) * 100, 1) if closed else 0.0

    _summary = {
        "equity": state.get("equity", CFG.get("starting_equity", 5000)),
        "cash": state.get("cash", 0),
        "invested": round(invested, 2),
        "short_exposure": round(short_exposure, 2),
        "margin_reserved": round(state.get("margin_reserved", 0), 2),
        "positions": state["positions"],
        "open_count": open_count,
        "max_positions": max_pos,
        "open_slots": max(0, max_pos - open_count),
        "closed_pnl": round(closed_pnl, 2),
        "wins": wins,
        "losses": losses,
        "win_rate": win_rate,
        "monthly_pnl": state.get("monthly_pnl", {}),
        "equity_curve": state.get("equity_curve", []),
        "closed_trades": closed,
        "config_label": CFG.get("label", "Config E"),
    }
    # Enrich each open position with days_to_earnings for dashboard badges.
    # Guarded inside the helper; silent no-op if data_fetcher unavailable.
    try:
        _add_earnings_context(_summary)
    except Exception:
        pass
    return _summary


def check_gap_down(ticker: str, threshold: float = -3.0) -> dict | None:
    """AI-46: Detect a gap-down open for a single ticker.

    Compares today's OPEN against the prior day's CLOSE. If the gap is at or
    below ``threshold`` (default -3.0 %), return an EXIT action dict; otherwise
    return ``None``. Uses Polygon snapshot first, then falls back to OHLCV bars.

    Returns: ``{"ticker", "action": "EXIT", "reason", "gap_pct"}`` or ``None``.
    """
    today_open: float | None = None
    prev_close: float | None = None
    try:
        from data_fetcher import get_polygon_snapshot
        snap = get_polygon_snapshot([ticker]) or {}
        data = snap.get(ticker, {}) or {}
        o = data.get("open")
        pc = data.get("prev_close")
        if o and pc:
            today_open = float(o)
            prev_close = float(pc)
    except Exception:
        pass

    if today_open is None or prev_close is None:
        try:
            from data_fetcher import get_polygon_ohlcv
            df = get_polygon_ohlcv(ticker, days=5)
            if df is not None and len(df) >= 2:
                today_open = float(df["Open"].iloc[-1])
                prev_close = float(df["Close"].iloc[-2])
        except Exception:
            return None

    if not today_open or not prev_close or prev_close <= 0:
        return None

    gap_pct = (today_open / prev_close - 1) * 100
    if gap_pct <= threshold:
        return {
            "ticker": ticker,
            "action": "EXIT",
            "reason": f"Gap down {gap_pct:.1f}% at open — binary bad news",
            "gap_pct": round(gap_pct, 2),
        }
    return None


def generate_exit_actions(price_map: dict[str, float] | None = None) -> list[dict]:
    """
    Check all open positions and generate actionable exit/hold/tighten signals.
    Called during each scan to tell the user what to do with existing positions.

    Returns list of actions:
    [
        {"ticker": "NOV", "action": "HOLD", "reason": "Up +3.2%, trail stop moved to $19.20",
         "entry": 18.70, "current": 19.30, "pnl_pct": 3.2, "stop": 19.20, "days_held": 3},
        {"ticker": "FCX", "action": "EXIT", "reason": "Hit T1 target $73.50",
         "entry": 67.80, "current": 73.60, "pnl_pct": 8.5, "stop": 71.00, "days_held": 5},
        {"ticker": "ROIV", "action": "TIGHTEN", "reason": "At breakeven, move stop to $28.50",
         "entry": 28.40, "current": 28.55, "pnl_pct": 0.5, "stop": 28.50, "days_held": 4},
    ]
    """
    state = _load_state()
    positions = state.get("positions", [])
    if not positions:
        return []

    # Fetch live prices if not provided
    gap_map: dict[str, dict] = {}  # ticker -> {"open": float, "prev_close": float}
    if price_map is None:
        try:
            from data_fetcher import get_polygon_snapshot
            tickers = [p["ticker"] for p in positions]
            snap = get_polygon_snapshot(tickers)
            price_map = {}
            for t, data in snap.items():
                px = data.get("price") or data.get("close")
                if px:
                    price_map[t] = float(px)
                o = data.get("open")
                pc = data.get("prev_close")
                if o and pc:
                    gap_map[t] = {"open": float(o), "prev_close": float(pc)}
        except Exception:
            price_map = {}

    GAP_DOWN_THRESHOLD = -3.0  # percent

    trail_activate_pct = CFG.get("trail_activate_pct", 2.0)
    trail_atr_mult = CFG.get("trail_atr_mult", 1.25)
    max_hold_days = CFG.get("max_hold_days", 10)
    hold_days = CFG.get("hold_days", 5)

    actions = []
    today = date.today()

    for pos in positions:
        ticker = pos["ticker"]
        entry = pos["entry_price"]
        current = price_map.get(ticker)
        if current is None:
            current = pos.get("highest_price", entry)

        # Days held
        try:
            entry_dt = date.fromisoformat(pos["entry_date"])
            days_held = (today - entry_dt).days
        except Exception:
            days_held = 0

        pnl_pct = round((current / entry - 1) * 100, 2) if entry else 0.0
        effective_stop = pos.get("trail_stop", pos.get("stop", 0))
        target1 = pos.get("target1", 0)
        atr_proxy = abs(entry - pos.get("stop", entry * 0.97))

        action = None
        reason = ""

        # ── EXIT conditions ──
        # 1. Stop hit
        if current <= effective_stop:
            action = "EXIT"
            reason = f"Stop hit at ${effective_stop:.2f}"
        # 2. Target hit
        elif target1 and current >= target1:
            action = "EXIT"
            reason = f"Hit T1 target ${target1:.2f}"
        # 3. Max hold days exceeded
        elif days_held >= max_hold_days:
            action = "EXIT"
            if pnl_pct >= 0:
                reason = f"Max hold {max_hold_days}d reached — take profit"
            else:
                reason = f"Max hold {max_hold_days}d reached — time stop"

        # ── Gap-down auto-close (AI-46) ──
        # Runs AFTER stop/target/max-hold EXIT checks (so it won't override a known EXIT reason),
        # but BEFORE WARNING/TIGHTEN/TRAIL so binary bad news takes priority.
        if action is None:
            gi = gap_map.get(ticker)
            today_open = gi.get("open") if gi else None
            prev_close = gi.get("prev_close") if gi else None
            if (today_open is None or prev_close is None):
                try:
                    from data_fetcher import get_polygon_ohlcv
                    df = get_polygon_ohlcv(ticker, days=5)
                    if df is not None and len(df) >= 2:
                        today_open = float(df["Open"].iloc[-1])
                        prev_close = float(df["Close"].iloc[-2])
                except Exception:
                    pass
            if today_open and prev_close and prev_close > 0:
                gap_pct = (today_open / prev_close - 1) * 100
                if gap_pct <= GAP_DOWN_THRESHOLD:
                    action = "EXIT"
                    reason = f"Gap down {gap_pct:.1f}% at open — binary bad news"

        # ── WARNING: approaching stop ──
        if action is None and effective_stop > 0 and current > effective_stop:
            stop_distance_pct = (current - effective_stop) / current * 100
            if stop_distance_pct < 1.5:
                action = "WARNING"
                reason = f"Only {stop_distance_pct:.1f}% above stop ${effective_stop:.2f}"

        # ── TIGHTEN: profitable but trail not yet active → suggest moving stop to breakeven ──
        if action is None and pnl_pct > 0 and pnl_pct < trail_activate_pct:
            if effective_stop < entry:
                action = "TIGHTEN"
                new_stop = round(entry + atr_proxy * 0.1, 2)  # just above breakeven
                reason = f"At breakeven, move stop to ${new_stop:.2f}"
                effective_stop = new_stop
            elif days_held >= hold_days and not pos.get("trail_active", False):
                action = "TIGHTEN"
                new_stop = round(current - atr_proxy * 0.5, 2)
                reason = f"Day {days_held} of {hold_days}, tighten stop to ${new_stop:.2f}"
                effective_stop = new_stop

        # ── HOLD: everything on track ──
        if action is None:
            action = "HOLD"
            if pos.get("trail_active", False):
                reason = f"Up {pnl_pct:+.1f}%, trail stop moved to ${effective_stop:.2f}"
            elif pnl_pct >= 0:
                reason = f"Up {pnl_pct:+.1f}% (${current:.2f}), on track"
            else:
                reason = f"Down {pnl_pct:.1f}% (${current:.2f}), stop ${effective_stop:.2f} intact"

        actions.append({
            "ticker": ticker,
            "action": action,
            "reason": reason,
            "entry": entry,
            "current": round(current, 2),
            "pnl_pct": pnl_pct,
            "stop": round(effective_stop, 2),
            "target1": round(target1, 2) if target1 else None,
            "days_held": days_held,
            "max_hold_days": max_hold_days,
            "setup_type": pos.get("setup_type", ""),
            "shares": pos.get("shares", 0),
            "trail_active": pos.get("trail_active", False),
        })

    # Sort: EXIT first, then WARNING, TIGHTEN, HOLD
    _action_order = {"EXIT": 0, "WARNING": 1, "TRIM": 1, "TIGHTEN": 2, "HOLD": 3}
    actions.sort(key=lambda a: _action_order.get(a["action"], 9))
    return actions


def runner_protection_trim(max_position_pct: float = 25.0,
                            trim_to_pct: float = 15.0) -> list[dict]:
    """Suggest TRIM actions when any position exceeds max_position_pct of equity.

    Returns list of {ticker, current_pct, target_pct, shares_to_trim, proceeds}.
    Called by EOD manager; surfaces in dashboard Portfolio tab.
    """
    state = _load_state()
    equity = float(state.get("equity", 5000) or 5000)
    positions = state.get("positions", [])
    trims = []
    for p in positions:
        current_px = float(p.get("current_price") or p.get("entry_price", 0))
        shares = int(p.get("shares", 0))
        value = current_px * shares
        if equity <= 0 or value <= 0:
            continue
        pct = value / equity * 100
        if pct > max_position_pct:
            target_value = equity * (trim_to_pct / 100)
            target_shares = max(1, int(target_value / current_px))
            trim_shares = max(0, shares - target_shares)
            if trim_shares > 0:
                trims.append({
                    "ticker": p["ticker"],
                    "current_pct": round(pct, 1),
                    "target_pct": round(trim_to_pct, 1),
                    "shares_to_trim": trim_shares,
                    "proceeds": round(trim_shares * current_px, 0),
                    "reason": f"Position at {pct:.0f}% of equity exceeds {max_position_pct:.0f}% cap — trim to {trim_to_pct:.0f}%",
                })
    return trims


def flat_position_exits(flat_threshold_pct: float = 1.5,
                        flat_max_days: int = 3) -> list[dict]:
    """Surface positions that are flat (within ±flat_threshold_pct) for too long.

    Capital parked in non-moving positions is dead weight — release it.
    Returns list of tickers to consider closing.
    """
    from datetime import date as _date
    state = _load_state()
    positions = state.get("positions", [])
    today = _date.today()
    flats = []
    for p in positions:
        try:
            entry = float(p.get("entry_price", 0))
            current = float(p.get("current_price") or entry)
            if entry <= 0:
                continue
            pct = abs(current - entry) / entry * 100
            entry_dt = _date.fromisoformat(str(p.get("entry_date", ""))[:10])
            days = (today - entry_dt).days
        except Exception:
            continue
        if days >= flat_max_days and pct < flat_threshold_pct:
            flats.append({
                "ticker": p["ticker"],
                "pct_chg": round((current - entry) / entry * 100, 2),
                "days_held": days,
                "reason": f"Flat {pct:.1f}% after {days} days — release capital",
            })
    return flats


def get_monthly_pnl() -> dict[str, float]:
    """Return monthly P&L history: {"2026-04": -25.50, "2026-05": 340.00, ...}"""
    state = _load_state()
    return state.get("monthly_pnl", {})


# ─────────────────────────────────────────────────────────────────────────────
# Backward-compatibility shims ported from the deprecated portfolio.py module.
# portfolio_tracker.py is now the single source of truth for portfolio state.
# These helpers adapt the previous portfolio.py public API to the
# portfolio_state.json schema (entry_price / closed_trades / position_size).
# ─────────────────────────────────────────────────────────────────────────────

import logging as _logging
from datetime import timedelta as _timedelta

_log_compat = _logging.getLogger("swingtrade.portfolio_tracker.compat")

# Alias so legacy callers that imported PORTFOLIO_PATH keep working.
PORTFOLIO_PATH = STATE_PATH


def load_portfolio() -> dict:
    """
    Return the raw portfolio state dict.

    Legacy callers expect keys 'positions' and 'closed' — we provide both
    'closed_trades' (native) and a 'closed' alias for compatibility.
    """
    state = _load_state()
    if "closed" not in state:
        state["closed"] = state.get("closed_trades", [])
    return state


def refresh_prices() -> list[dict]:
    """
    Fetch current prices for all open positions via yfinance and update P&L.

    Mirrors the legacy portfolio.refresh_prices() behaviour but operates on
    portfolio_state.json (entry_price / position_size fields).
    """
    try:
        import yfinance as yf  # type: ignore
    except ImportError:
        _log_compat.warning("yfinance not available - refresh_prices is a no-op")
        return []

    state = _load_state()
    positions = state.get("positions", [])
    if not positions:
        return []

    tickers = [p["ticker"] for p in positions]
    prices: dict[str, float] = {}
    try:
        raw = yf.download(tickers if len(tickers) > 1 else tickers[0],
                          period="1d", interval="1m", progress=False)
        if len(tickers) == 1:
            if not raw.empty:
                prices[tickers[0]] = float(raw["Close"].iloc[-1])
        else:
            for t in tickers:
                try:
                    prices[t] = float(raw["Close"][t].dropna().iloc[-1])
                except Exception:
                    pass
    except Exception as e:
        _log_compat.warning(f"refresh_prices download failed: {e}")
        return positions

    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    for pos in positions:
        t = pos["ticker"]
        if t not in prices:
            continue
        cur = prices[t]
        entry = float(pos.get("entry_price", 0) or 0)
        if entry <= 0:
            continue
        direction = pos.get("direction", "long")
        if direction == "long":
            pnl_pct = (cur - entry) / entry * 100
        else:
            pnl_pct = (entry - cur) / entry * 100
        pnl_dollars = pnl_pct / 100 * entry * pos.get("shares", 0)
        pos["current_price"] = round(cur, 2)
        pos["unrealized_pnl_pct"] = round(pnl_pct, 2)
        pos["unrealized_pnl_dollars"] = round(pnl_dollars, 2)
        pos["last_updated"] = now

        stop = pos.get("stop", 0) or 0
        t1 = pos.get("target1", 0) or 0
        t2 = pos.get("target2")
        if direction == "long":
            pos["stop_hit"] = cur <= stop
            pos["t1_hit"] = cur >= t1 if t1 else False
            pos["t2_hit"] = bool(t2 and cur >= t2)
        else:
            pos["stop_hit"] = cur >= stop
            pos["t1_hit"] = cur <= t1 if t1 else False
            pos["t2_hit"] = bool(t2 and cur <= t2)

        # Move stop to breakeven only after T1 is confirmed hit.
        try:
            if pos.get("t1_hit"):
                if direction == "long":
                    be_stop = round(entry * 1.005, 2)
                    if pos.get("stop", 0) < be_stop:
                        pos["stop"] = be_stop
                        pos["stop_note"] = "Moved to breakeven after T1"
                elif direction == "short":
                    be_stop = round(entry * 0.995, 2)
                    if pos.get("stop", 9999) > be_stop:
                        pos["stop"] = be_stop
                        pos["stop_note"] = "Moved to breakeven after T1"
            if pos.get("t1_hit") and not pos.get("t1_partial_taken"):
                pos["t1_partial_alert"] = True
        except Exception:
            pass

    _save_state(state)
    return positions


# --- Correlation helpers (ported from portfolio.py) --------------------------
_corr_cache: dict = {}
_CORR_CACHE_TTL_MINUTES = 30


def _get_returns(tickers: list[str], period: str = "3mo"):
    """Download daily returns for tickers; cached for 30 min."""
    try:
        import pandas as pd  # type: ignore
        import yfinance as yf  # type: ignore
    except ImportError:
        _log_compat.warning("pandas/yfinance unavailable - correlation disabled")
        return None

    if not tickers:
        return pd.DataFrame()

    cache_key = f"{sorted(tickers)}|{period}"
    now = datetime.now()
    if cache_key in _corr_cache:
        cached_at, cached_df = _corr_cache[cache_key]
        if now - cached_at < _timedelta(minutes=_CORR_CACHE_TTL_MINUTES):
            return cached_df

    try:
        raw = yf.download(
            tickers if len(tickers) > 1 else tickers[0],
            period=period, interval="1d", progress=False, auto_adjust=True,
        )
        if raw.empty:
            return pd.DataFrame()
        if len(tickers) == 1:
            close = raw["Close"].squeeze().rename(tickers[0])
            prices = pd.DataFrame({tickers[0]: close})
        else:
            prices = raw["Close"] if raw.columns.nlevels > 1 else raw[["Close"]]
        returns = prices.pct_change().dropna(how="all")
        _corr_cache[cache_key] = (now, returns)
        return returns
    except Exception as e:
        _log_compat.warning(f"_get_returns failed for {tickers}: {e}")
        return pd.DataFrame()


def compute_pairwise_correlation(tickers: list[str], period: str = "3mo") -> dict:
    """Pairwise Pearson correlation between tickers using daily returns."""
    try:
        import pandas as pd  # type: ignore
    except ImportError:
        return {}
    if len(tickers) < 2:
        return {}
    returns = _get_returns(tickers, period)
    if returns is None or returns.empty or returns.shape[1] < 2:
        return {}
    available = [t for t in tickers if t in returns.columns]
    if len(available) < 2:
        return {}
    corr_matrix = returns[available].corr(method="pearson")
    pairs: dict = {}
    for i, t1 in enumerate(available):
        for t2 in available[i + 1:]:
            overlap = returns[[t1, t2]].dropna()
            if len(overlap) < 20:
                continue
            val = corr_matrix.loc[t1, t2]
            if pd.isna(val):
                continue
            pair = tuple(sorted([t1, t2]))
            pairs[pair] = round(float(val), 4)
    return pairs


def check_correlation_risk(candidate: str, open_positions: list[str],
                           threshold: float = 0.80, period: str = "3mo",
                           sector_map: dict | None = None) -> dict:
    """Check whether candidate is highly correlated with any open position."""
    candidate = candidate.upper()
    open_positions = [t.upper() for t in open_positions]
    if not open_positions:
        return {
            "has_risk": False, "correlated_with": [],
            "max_correlation": 0.0, "sector_count": {},
            "sector_risk": False,
            "message": "No open positions to compare against",
        }
    all_tickers = [candidate] + open_positions
    pairs = compute_pairwise_correlation(all_tickers, period=period)
    correlated_with = []
    for (t1, t2), corr in pairs.items():
        other = t2 if t1 == candidate else (t1 if t2 == candidate else None)
        if other and corr >= threshold:
            correlated_with.append({"ticker": other, "correlation": corr})
    correlated_with.sort(key=lambda x: x["correlation"], reverse=True)
    max_corr = correlated_with[0]["correlation"] if correlated_with else 0.0

    sector_count: dict[str, int] = {}
    if sector_map is None:
        sector_map = {}
        try:
            import yfinance as yf  # type: ignore
            for t in all_tickers:
                try:
                    info = yf.Ticker(t).info
                    sector_map[t] = info.get("sector") or "Unknown"
                except Exception:
                    sector_map[t] = "Unknown"
        except ImportError:
            sector_map = {t: "Unknown" for t in all_tickers}
    for t in all_tickers:
        sec = sector_map.get(t, "Unknown")
        sector_count[sec] = sector_count.get(sec, 0) + 1
    sector_risk = any(v > 2 for v in sector_count.values())

    return {
        "has_risk": bool(correlated_with) or sector_risk,
        "correlated_with": correlated_with,
        "max_correlation": round(max_corr, 4),
        "sector_count": sector_count,
        "sector_risk": sector_risk,
    }


def get_portfolio_correlation_matrix(period: str = "3mo") -> dict:
    """Full Pearson correlation matrix for all currently open positions."""
    try:
        import numpy as np  # type: ignore
    except ImportError:
        return {"tickers": [], "matrix": [], "high_pairs": [],
                "message": "numpy unavailable"}
    state = _load_state()
    positions = state.get("positions", [])
    tickers = [p["ticker"] for p in positions if p.get("ticker")]
    if len(tickers) < 2:
        return {
            "tickers": tickers,
            "matrix": [[1.0]] if len(tickers) == 1 else [],
            "high_pairs": [],
            "message": "Need at least 2 open positions for a correlation matrix",
        }
    returns = _get_returns(tickers, period)
    if returns is None:
        return {"tickers": tickers, "matrix": [], "high_pairs": [],
                "message": "pandas/yfinance unavailable"}
    available = [t for t in tickers if t in returns.columns]
    if len(available) < 2:
        return {"tickers": tickers, "matrix": [], "high_pairs": [],
                "message": "Insufficient price data for open positions"}
    corr_df = returns[available].corr(method="pearson")
    matrix = []
    for row_t in available:
        row = []
        for col_t in available:
            val = corr_df.loc[row_t, col_t]
            try:
                row.append(None if np.isnan(float(val)) else round(float(val), 4))
            except (TypeError, ValueError):
                row.append(None)
        matrix.append(row)
    HIGH_THRESHOLD = 0.70
    high_pairs = []
    for i, t1 in enumerate(available):
        for t2 in available[i + 1:]:
            val = corr_df.loc[t1, t2]
            try:
                val_f = float(val)
            except (TypeError, ValueError):
                continue
            if not np.isnan(val_f) and val_f >= HIGH_THRESHOLD:
                high_pairs.append({"t1": t1, "t2": t2, "corr": round(val_f, 4)})
    high_pairs.sort(key=lambda x: x["corr"], reverse=True)
    return {"tickers": available, "matrix": matrix, "high_pairs": high_pairs}


# ── CLI convenience ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    summary = get_portfolio_summary()
    print(f"Config: {summary['config_label']}")
    print(f"Equity: ${summary['equity']:,.2f}  |  Cash: ${summary['cash']:,.2f}  |  Invested: ${summary['invested']:,.2f}")
    print(f"Open: {summary['open_count']}/{summary['max_positions']} positions  |  Slots: {summary['open_slots']}")
    print(f"Closed P&L: ${summary['closed_pnl']:+,.2f}  |  W/L: {summary['wins']}W/{summary['losses']}L  ({summary['win_rate']}%)")
    if summary["positions"]:
        print("\nOpen positions:")
        for p in summary["positions"]:
            print(f"  {p['ticker']:6s}  entry ${p['entry_price']:.2f}  x{p['shares']}  "
                  f"stop ${p['stop']:.2f}  trail_stop ${p.get('trail_stop', p['stop']):.2f}  "
                  f"trail_active={p.get('trail_active', False)}  setup={p.get('setup_type', '')}")
    if summary["monthly_pnl"]:
        print("\nMonthly P&L:")
        for month, pnl in sorted(summary["monthly_pnl"].items()):
            print(f"  {month}: ${pnl:+,.2f}")
