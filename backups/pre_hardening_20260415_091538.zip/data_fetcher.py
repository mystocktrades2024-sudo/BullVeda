"""
Data fetching layer for SwingTrade.
Pulls S&P 500 universe, Zacks Rank #1 list, and Yahoo Finance market data.
"""

from __future__ import annotations

import json
import logging
import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import time

import numpy as np
import pandas as pd
import requests
import yfinance as yf
from bs4 import BeautifulSoup

# Optional tvDatafeed fallback
try:
    from tvDatafeed import TvDatafeed, Interval as TvInterval
    _tv_feed = TvDatafeed()
    _TV_DATAFEED = True
except Exception:
    _tv_feed = None
    _TV_DATAFEED = False

log = logging.getLogger("swingtrade.data")

BASE_DIR = Path(__file__).parent
CONFIG_PATH = BASE_DIR / "config" / "config.json"


# ── In-memory TTL cache (prevents redundant API calls within a session) ──────

_mem_cache: dict[str, tuple[float, dict]] = {}

def _mem_cached(ttl_seconds: int = 3600):
    """Decorator: caches function(ticker, ...) → dict in memory for ttl_seconds."""
    def decorator(fn):
        def wrapper(ticker: str, *args, **kwargs):
            key = f"{fn.__name__}_{ticker}"
            now = time.time()
            hit = _mem_cache.get(key)
            if hit and (now - hit[0]) < ttl_seconds:
                return hit[1]
            result = fn(ticker, *args, **kwargs)
            _mem_cache[key] = (now, result)
            return result
        wrapper.__name__ = fn.__name__
        wrapper.__doc__ = fn.__doc__
        return wrapper
    return decorator


# ── Degraded mode (connectivity fallback) ────────────────────────────────────
# Set by swing_trade._check_connectivity() when DNS/endpoint checks fail.
# When True, fetch_ohlcv_with_failover() skips live Polygon and goes straight
# to the local archive/yfinance to avoid cascading connection errors.
_DEGRADED_MODE = False


def enable_degraded_mode() -> None:
    """Skip live API calls, use archive first. Set when DNS/connectivity fails."""
    global _DEGRADED_MODE
    _DEGRADED_MODE = True
    log.warning("DEGRADED MODE enabled: network-first calls disabled, archive-only for this scan")


def disable_degraded_mode() -> None:
    """Re-enable live API calls (primarily for tests)."""
    global _DEGRADED_MODE
    _DEGRADED_MODE = False


def is_degraded_mode() -> bool:
    return _DEGRADED_MODE


# ── Batch retry helper (for snapshot-style calls) ────────────────────────────

def _retry_batch_call(func, args=(), kwargs=None, max_retries=3, base_delay=2, label="batch"):
    """Exponential backoff retry for batch network calls.

    Total wall-clock is bounded to ~ base_delay * (2^max_retries - 1) seconds.
    With defaults (max_retries=3, base_delay=2): 2 + 4 + 8 = 14s max sleep.
    Caller should size max_retries so total stays under 30s per constraints.
    Returns func's result if any attempt succeeds with truthy value, else None.
    """
    if kwargs is None:
        kwargs = {}
    for attempt in range(max_retries):
        try:
            result = func(*args, **kwargs)
            if result:
                return result
        except Exception as e:
            log.warning(f"{label} failed (attempt {attempt+1}/{max_retries}): {e}")
        if attempt < max_retries - 1:
            delay = base_delay * (2 ** attempt)
            log.warning(f"{label} retrying in {delay}s...")
            time.sleep(delay)
    log.error(f"{label}: all {max_retries} retries exhausted")
    return None


# ── Disk cache helpers (JSON, TTL in seconds) ────────────────────────────────

def _cache_read(key: str, ttl_seconds: int) -> dict | None:
    """Return cached dict if fresh, else None."""
    fp = BASE_DIR / "cache" / f"_cache_{key}.json"
    try:
        if fp.exists():
            age = time.time() - fp.stat().st_mtime
            if age < ttl_seconds:
                return json.loads(fp.read_text())
    except Exception as e:
        log.debug(f"Cache read failed for {key}: {e}")
    return None


def _cache_write(key: str, data: dict) -> None:
    """Write dict to disk cache."""
    try:
        fp = BASE_DIR / "cache" / f"_cache_{key}.json"
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(json.dumps(data))
    except Exception as e:
        log.debug(f"Cache write failed for {key}: {e}")


_CONFIG_DEFAULTS = {
    "universe":    {"include_sp500": True, "include_russell1000": True,
                    "zacks_rank1_only": False, "custom_watchlist": []},
    "filters":     {"min_price": 2, "max_price": 250, "min_daily_dollar_volume": 10_000_000},
    "scoring":     {"fundamentals_max": 20, "optionality_max": 25,
                    "technicals_max": 40, "sentiment_max": 15, "raw_total": 100},
    "gates":       {"min_liquidity_daily": 10_000_000, "earnings_blackout_days": 5,
                    "entry_day_spy_drop_pct": -1.5, "distribution_days_no_new": 7},
    "technicals":  {"rsi_period": 14, "ema_fast": 8, "ema_mid": 21, "ema_slow": 50,
                    "sma_200": 200, "atr_period": 14, "min_rr_ratio": 3.0},
    "decisions":   {"buy_min_score": 65, "buy_min_rr": 3.0, "watch_min_score": 50, "avoid_below": 50},
    "portfolio":   {"max_positions": 5, "sector_max_positions": 2},
    "output":      {"top_n_buy": 5, "top_n_sell": 5, "top_n_watch": 5},
    "performance": {"max_enrichment_tickers": 200},
}


def load_config() -> dict:
    with open(CONFIG_PATH) as f:
        cfg = json.load(f)
    # Merge defaults for any missing top-level sections or keys
    for section, defaults in _CONFIG_DEFAULTS.items():
        if section not in cfg:
            log.warning(f"Config missing section '{section}' — using defaults")
            cfg[section] = dict(defaults)
        else:
            for key, val in defaults.items():
                if key not in cfg[section]:
                    log.debug(f"Config '{section}.{key}' missing — default {val}")
                    cfg[section][key] = val
    return cfg


# ── Universe builders ────────────────────────────────────────────────────────

def get_sp500() -> list[str]:
    """Scrape current S&P 500 constituents from Wikipedia."""
    import io
    url = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
    }
    try:
        resp = requests.get(url, headers=headers, timeout=15)
        resp.raise_for_status()
        tables = pd.read_html(io.StringIO(resp.text))
        df = tables[0]
        tickers = df["Symbol"].tolist()
        return [t.replace(".", "-") for t in tickers]
    except Exception as e:
        log.error(f"Failed to fetch S&P 500: {e}")
        return []


def get_russell1000() -> list[str]:
    """
    Fetch current Russell 1000 constituents from iShares IWB ETF holdings CSV.
    Falls back to an empty list on any error (universe still uses S&P 500).
    """
    import io
    url = (
        "https://www.ishares.com/us/products/239707/ishares-russell-1000-etf/"
        "1467271812596.ajax?fileType=csv&fileName=IWB_holdings&dataType=fund"
    )
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Referer": "https://www.ishares.com/",
    }
    try:
        resp = requests.get(url, headers=headers, timeout=20)
        resp.raise_for_status()
        lines = resp.text.splitlines()
        # iShares CSVs have metadata rows at top; find the row with "Ticker" header
        header_idx = next(
            (i for i, l in enumerate(lines) if "Ticker" in l), 9
        )
        data_csv = "\n".join(lines[header_idx:])
        df = pd.read_csv(io.StringIO(data_csv))
        col = next((c for c in df.columns if c.strip().lower() == "ticker"), None)
        if col is None:
            log.warning("Russell 1000: 'Ticker' column not found in iShares CSV")
            return []
        tickers = df[col].dropna().astype(str).tolist()
        result = []
        for t in tickers:
            t = t.strip().replace(".", "-")
            # Skip cash, currency rows, empty, or rows that are clearly not equities
            if t and t != "-" and t.lower() != "nan" and len(t) <= 6:
                result.append(t)
        log.info(f"Russell 1000: fetched {len(result)} tickers from iShares IWB")
        return result
    except Exception as e:
        log.error(f"Failed to fetch Russell 1000 from iShares: {e}")
        return []


def _scrape_zacks_sell_list(driver) -> list[dict]:
    """
    Scrape Zacks sell list with VGM grades.
    Returns list of {ticker, company, value, growth, momentum, vgm} dicts.
    """
    try:
        driver.get("https://www.zacks.com/stocks/sell-list")
        import time as _time
        _time.sleep(3)
        from bs4 import BeautifulSoup

        # Ask DataTables to show all rows (same pattern as buy list)
        try:
            driver.execute_script("""
                document.querySelectorAll('.dataTables_length select').forEach(function(s){
                    s.value='-1';
                    s.dispatchEvent(new Event('change',{bubbles:true}));
                });
            """)
            _time.sleep(2)
        except Exception:
            pass

        soup = BeautifulSoup(driver.page_source, "html.parser")
        # Try known table IDs for sell list
        table = (soup.find("table", id="stocks_table")
                 or soup.find("table", id="full_one_list_table_full_one_list")
                 or soup.find("table"))
        if not table:
            return []

        # ── Detect VGM column positions by voting on A–F grades ─────────────
        grade_set = {"A", "B", "C", "D", "F", "A+", "B+", "C+", "D+", "A-", "B-", "C-", "D-"}
        grade_col_votes: dict[int, int] = {}
        for tr in table.find_all("tr")[1:10]:
            cells_samp = tr.find_all("td")
            for i, c in enumerate(cells_samp):
                v = c.get_text(strip=True).upper()
                if v in grade_set:
                    grade_col_votes[i] = grade_col_votes.get(i, 0) + 1

        grade_cols = sorted([i for i, cnt in grade_col_votes.items() if cnt >= 2])
        val_idx  = grade_cols[0] if len(grade_cols) > 0 else None
        grow_idx = grade_cols[1] if len(grade_cols) > 1 else None
        mom_idx  = grade_cols[2] if len(grade_cols) > 2 else None
        vgm_idx  = grade_cols[3] if len(grade_cols) > 3 else None
        log.info(f"Sell list VGM columns: val={val_idx} gro={grow_idx} mom={mom_idx} vgm={vgm_idx} "
                 f"(from grade votes: {grade_col_votes})")

        def _grade(idx, cells):
            """Extract grade from cell, checking text and data attributes."""
            if idx is not None and idx < len(cells):
                cell = cells[idx]
                # Try get_text first
                g = cell.get_text(strip=True)
                if g and g.upper() in {"A","A+","A-","B","B+","B-","C","C+","C-","D","D+","D-","F"}:
                    return g
                # Try data attributes
                for attr in ["data-value", "title", "data-grade"]:
                    v = cell.get(attr, "").strip()
                    if v and v.upper() in {"A","A+","A-","B","B+","B-","C","C+","C-","D","D+","D-","F"}:
                        return v
                # Check inner spans
                for span in cell.find_all(["span", "div"]):
                    sv = span.get_text(strip=True)
                    if sv and sv.upper() in {"A","A+","A-","B","B+","B-","C","C+","C-","D","D+","D-","F"}:
                        return sv
                    for attr in ["data-value", "title", "data-grade"]:
                        sv2 = span.get(attr, "").strip()
                        if sv2 and sv2.upper() in {"A","A+","A-","B","B+","B-","C","C+","C-","D","D+","D-","F"}:
                            return sv2
                return g or "—"
            return "—"

        rows = []
        _debug_row_logged = False
        for tr in table.find_all("tr")[1:]:
            cells = tr.find_all("td")
            if len(cells) < 2:
                continue

            # Extract ticker (first cell, or from a quote link)
            ticker_raw = cells[0].get_text(strip=True)
            if ticker_raw:
                ticker = ticker_raw.split()[0].upper()
            else:
                link = tr.find("a", href=re.compile(r"/stock/quote/"))
                if not link:
                    continue
                m = re.search(r"/stock/quote/([A-Z0-9.\-]{1,6})", link["href"])
                if not m:
                    continue
                ticker = m.group(1).replace(".", "-").upper()

            company = cells[1].get_text(strip=True) if len(cells) > 1 else ""

            # Debug: log all cells for first row
            if not _debug_row_logged:
                cell_map = {i: cells[i].get_text(strip=True)[:30] for i in range(len(cells))}
                log.info(f"Sell list debug row={ticker} ({len(cells)} cells): {cell_map}")
                _debug_row_logged = True

            rows.append({
                "ticker":    ticker,
                "company":   company,
                "value":     _grade(val_idx, cells),
                "growth":    _grade(grow_idx, cells),
                "momentum":  _grade(mom_idx, cells),
                "vgm":       _grade(vgm_idx, cells),
            })

        vgm_hit = sum(1 for r in rows if r.get("vgm", "—") not in ("—", ""))
        log.info(f"Zacks sell list: {len(rows)} tickers, {vgm_hit}/{len(rows)} with VGM grades")
        return rows
    except Exception as e:
        log.warning(f"Sell list scrape failed: {e}")
        return []


def _get_chrome_major_version():
    """Detect installed Chrome major version. Returns int or None if detection fails."""
    import subprocess
    chrome_paths = [
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",  # macOS
        "/usr/bin/google-chrome",                                         # Linux
        "/usr/bin/google-chrome-stable",                                  # Linux alt
        "google-chrome",                                                  # PATH
        "chrome",                                                         # PATH alt
    ]
    for path in chrome_paths:
        try:
            result = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=3)
            if result.returncode == 0:
                match = re.search(r"(\d+)\.", result.stdout)
                if match:
                    return int(match.group(1))
        except (FileNotFoundError, subprocess.TimeoutExpired, Exception):
            continue
    return None


_CHROME_VERSION_CACHE = None


def _chrome_version():
    """Return cached Chrome major version, detecting on first call."""
    global _CHROME_VERSION_CACHE
    if _CHROME_VERSION_CACHE is None:
        _CHROME_VERSION_CACHE = _get_chrome_major_version()
        if _CHROME_VERSION_CACHE:
            log.info(f"Detected Chrome version {_CHROME_VERSION_CACHE}")
        else:
            log.warning("Could not detect Chrome version — undetected_chromedriver will auto-match")
    return _CHROME_VERSION_CACHE


def _try_zacks_login(creds_path: str) -> object | None:
    """Attempt Selenium login to Zacks. Returns driver or None."""
    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.support.ui import WebDriverWait
    except ImportError:
        log.warning("Selenium not installed — Zacks scraping disabled")
        return None

    creds_file = Path(creds_path)
    if not creds_file.exists():
        log.warning(f"Zacks credentials not found: {creds_path}")
        return None

    with open(creds_file) as f:
        creds = json.load(f)

    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_argument(
        "--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    )

    try:
        # Try undetected-chromedriver first (use_subprocess=True prevents window-close crash on macOS)
        try:
            import undetected_chromedriver as uc
            uc_opts = uc.ChromeOptions()
            uc_opts.add_argument("--headless=new")
            uc_opts.add_argument("--no-sandbox")
            uc_opts.add_argument("--disable-dev-shm-usage")
            _v = _chrome_version()
            kwargs = {"options": uc_opts, "use_subprocess": True}
            if _v:
                kwargs["version_main"] = _v
            try:
                driver = uc.Chrome(**kwargs)
            except Exception as e:
                log.warning(f"uc.Chrome with version_main={_v} failed: {e} — retrying without pin")
                driver = uc.Chrome(options=uc_opts, use_subprocess=True)
        except Exception:
            driver = webdriver.Chrome(options=opts)
            driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
                "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
            })

        driver.get("https://www.zacks.com/logout.php")
        wait = WebDriverWait(driver, 10)
        wait.until(EC.presence_of_element_located((By.ID, "username")))

        # Dismiss cookie banner
        driver.execute_script(
            "try{document.getElementById('accept_cookie').click()}catch(e){}"
        )

        # Fill and submit login form
        driver.execute_script(f"""
            var u = document.getElementById('username');
            var p = document.getElementById('password');
            u.value = '{creds["username"]}';
            p.value = '{creds["password"]}';
            u.dispatchEvent(new Event('input', {{bubbles:true}}));
            p.dispatchEvent(new Event('input', {{bubbles:true}}));
            var btn = document.querySelector('#login form input[type=submit], #login form button[type=submit]');
            if(btn) btn.click();
        """)

        import time
        time.sleep(4)

        url = driver.current_url.lower()
        if "logout" in url or "signin" in url or "registration" in url:
            log.warning("Zacks login failed — session not established")
            driver.quit()
            return None

        log.info("Zacks login successful")
        return driver

    except Exception as e:
        log.warning(f"Zacks login error: {e}")
        return None


def get_zacks_rank1(creds_path: str) -> list[str]:
    """Thin wrapper — buy list is fetched inside fetch_all_zacks_data for efficiency."""
    result = fetch_all_zacks_data(creds_path)
    return result.get("zacks_r1", [])


def fetch_zacks_rank(ticker: str, creds_path: str) -> dict:
    """Fetch Zacks rank for a single ticker via requests (no login needed for basic data)."""
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        }
        resp = requests.get(
            f"https://www.zacks.com/stock/quote/{ticker}",
            headers=headers, timeout=10
        )
        if resp.status_code != 200:
            return {"rank": None, "error": f"HTTP {resp.status_code}"}

        text = resp.text
        # Extract rank from page
        rank_match = re.search(r'rank_chip.*?(\d)', text)
        if not rank_match:
            rank_match = re.search(r'rankrect_(\d)', text)
        if not rank_match:
            rank_match = re.search(r'Zacks Rank.*?(\d)', text)

        rank = int(rank_match.group(1)) if rank_match else None
        rank_text_map = {1: "Strong Buy", 2: "Buy", 3: "Hold", 4: "Sell", 5: "Strong Sell"}

        return {
            "rank": rank,
            "rank_text": rank_text_map.get(rank, "Unknown"),
            "error": None
        }
    except Exception as e:
        return {"rank": None, "error": str(e)}


def _ultimate_login_driver(creds: dict) -> object:
    """Login via the embedded form on the Zacks Ultimate page and return driver."""
    try:
        import undetected_chromedriver as uc
    except ImportError:
        from selenium import webdriver as uc
        return None

    opts = uc.ChromeOptions()
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--window-size=1400,900")
    driver = uc.Chrome(options=opts, use_subprocess=True, version_main=146)

    driver.get("https://www.zacks.com/ultimate/")
    import time
    time.sleep(4)
    try:
        driver.execute_script(
            "var c=document.getElementById('accept_cookie');if(c)c.click()"
        )
        time.sleep(1)
    except Exception:
        pass

    driver.execute_script(f"""
        var inputs=document.querySelectorAll(
            'input[type=text],input[type=email],input[name*=user],input[name*=email]');
        var pwds=document.querySelectorAll('input[type=password]');
        for(var i=0;i<inputs.length;i++){{
            inputs[i].value='{creds["username"]}';
            inputs[i].dispatchEvent(new Event('input',{{bubbles:true}}));
        }}
        for(var i=0;i<pwds.length;i++){{
            pwds[i].value='{creds["password"]}';
            pwds[i].dispatchEvent(new Event('input',{{bubbles:true}}));
        }}
        var btns=document.querySelectorAll('input[type=submit],button[type=submit]');
        if(btns.length>0)btns[0].click();
    """)
    time.sleep(6)
    return driver


def get_ultimate_content(creds_path: str) -> dict:
    """Thin wrapper — all Zacks data is fetched inside fetch_all_zacks_data."""
    result = fetch_all_zacks_data(creds_path)
    return {
        "overview":   result.get("ultimate_overview", {}),
        "all_trades": result.get("ultimate_all_trades", []),
        "commentary": result.get("ultimate_commentary", []),
        "confidential_commentary": result.get("confidential_commentary", []),
        "error": result.get("error"),
    }


def fetch_all_zacks_data(creds_path: str, force_fresh: bool = False) -> dict:
    """
    Single non-headless browser session fetching all Zacks premium data:
      - Zacks Rank #1 buy list (https://www.zacks.com/stocks/buy-list/)
      - Ultimate top movers 30d + all open trades (top_movers.php)
      - Ultimate commentary (ultimate/commentary.php)
      - Confidential commentary (confidential/commentary.php)

    Uses non-headless UC + Ultimate embedded-form login to bypass Incapsula.
    """
    import time

    empty = {
        "zacks_r1": [],
        "zacks_r1_scores": {},
        "zacks_sell_list": [],
        "ultimate_overview": {},
        "ultimate_all_trades": [],
        "ultimate_commentary": [],
        "ultimate_special_reports": [],
        "tazr_trades": [], "tazr_portfolio_stats": {}, "tazr_commentary": [],
        "bbt_trades": [], "bbt_portfolio_stats": {}, "bbt_commentary": [],
        "counterstrike_trades": [], "counterstrike_portfolio_stats": {}, "counterstrike_commentary": [],
        "headlinetrader_trades": [], "headlinetrader_portfolio_stats": {}, "headlinetrader_commentary": [],
        "alt_energy_trades": [], "alt_energy_portfolio_stats": {}, "alt_energy_commentary": [],
        "blockchain_trades": [], "blockchain_portfolio_stats": {}, "blockchain_commentary": [],
        "tech_innovators_trades": [], "tech_innovators_portfolio_stats": {}, "tech_innovators_commentary": [],
        "confidential_commentary": [],
        "confidential_overview": {},
        "error": None,
    }

    # ── Disk cache: skip Selenium on same-day re-runs (weekend-aware TTL) ───────
    # Weekend: 6h (so Monday morning gets fresh data)
    # Monday pre-market (before 9:30 AM ET): 1h (catch overnight changes)
    # Otherwise: 12h (reduced from legacy 20h for fresher data)
    from zoneinfo import ZoneInfo as _ZI
    _now_et = datetime.now(_ZI("America/New_York"))
    _dow = _now_et.weekday()  # 0=Mon … 6=Sun
    if _dow in (5, 6):                                   # Saturday / Sunday
        _ZACKS_CACHE_TTL = 6 * 3600       # 6 hours
    elif _dow == 0 and (_now_et.hour < 9 or (_now_et.hour == 9 and _now_et.minute < 30)):
        _ZACKS_CACHE_TTL = 3600           # 1 hour (Monday pre-market)
    else:
        _ZACKS_CACHE_TTL = 12 * 3600      # 12 hours
    if not force_fresh:
        cached = _cache_read("zacks_all", _ZACKS_CACHE_TTL)
        if cached:
            log.info(f"Zacks cache hit — skipping Selenium scrape (use force_fresh=True to override)")
            return cached

    creds_file = Path(creds_path)
    if not creds_file.exists():
        empty["error"] = f"Credentials not found: {creds_path}"
        return empty

    with open(creds_file) as f:
        creds = json.load(f)

    driver = None
    try:
        driver = _ultimate_login_driver(creds)
        if driver is None:
            empty["error"] = "Driver init failed"
            return empty

        # ── Ultimate main page — overview stats + all open trades ────────────
        soup = BeautifulSoup(driver.page_source, "html.parser")
        ultimate_overview  = _parse_ultimate_overview(soup)
        # All open trades are also on the ultimate main page
        ultimate_all_trades = _parse_ultimate_table(soup, "all_trades_sortable")
        # Fallback: top_movers.php has the same all_trades table
        if not ultimate_all_trades:
            try:
                driver.get("https://www.zacks.com/ultimate/top_movers.php")
                time.sleep(3)
                soup_tm = BeautifulSoup(driver.page_source, "html.parser")
                ultimate_all_trades = _parse_ultimate_table(soup_tm, "all_trades_sortable")
            except Exception:
                pass
        log.info(f"Ultimate: {len(ultimate_all_trades)} open trades, "
                 f"overview stats: {len(ultimate_overview.get('stats', {}))} items")

        # ── TAZR — start in background thread immediately so it overlaps ────────
        # TAZR login takes ~22s; by the time the main session finishes its
        # remaining pages (~35s), TAZR will already be done.
        # ── Premium portfolios — all scraped in one Selenium session ────────────
        # TAZR, Black Box Trader, Counterstrike, Headline Trader,
        # Alt Energy Innovators, Blockchain Innovators, Technology Innovators
        _PREMIUM_PORTFOLIOS = [
            ("tazr",            "https://www.zacks.com/tazr/",                        "TAZR"),
            ("bbt",             "https://www.zacks.com/blackboxtrader/",               "BBT"),
            ("counterstrike",   "https://www.zacks.com/counterstrike/",                "Counterstrike"),
            ("headlinetrader",  "https://www.zacks.com/headlinetrader/",               "Headline Trader"),
            ("alt_energy",      "https://www.zacks.com/alternativeenergyinnovators/",  "Alt Energy"),
            ("blockchain",      "https://www.zacks.com/blockchaininnovators/",         "Blockchain"),
            ("tech_innovators", "https://www.zacks.com/technologyinnovators/",         "Tech Innovators"),
        ]
        _premium_results: dict = {
            key: {"trades": [], "stats": {}, "commentary": []}
            for key, _, _ in _PREMIUM_PORTFOLIOS
        }

        def _scrape_zacks_portfolio_page(driver_inst, url: str, label: str) -> tuple[list, dict, list]:
            """Scrape a single Zacks premium portfolio page. Returns (trades, stats, commentary)."""
            driver_inst.get(url)
            time.sleep(6)
            try:
                driver_inst.execute_script("""
                    document.querySelectorAll('.dataTables_length select').forEach(function(s){
                        s.value='-1';
                        s.dispatchEvent(new Event('change',{bubbles:true}));
                    });
                """)
                time.sleep(3)
            except Exception:
                pass
            try:
                driver_inst.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(2)
                driver_inst.execute_script("window.scrollTo(0, 0);")
                time.sleep(1)
            except Exception:
                pass
            page_src = driver_inst.page_source
            soup = BeautifulSoup(page_src, "html.parser")
            trades, stats = _parse_tazr_table(soup)
            commentary = _parse_tazr_commentary(soup)
            log.info(f"{label}: {len(trades)} trades, {len(commentary)} commentary")
            # Debug dump when empty
            if not trades:
                dump_name = f"debug_{label.lower().replace(' ', '_')}_page.html"
                dump_path = str(Path(__file__).parent / "cache" / dump_name)
                try:
                    with open(dump_path, "w", encoding="utf-8") as df:
                        df.write(page_src)
                    log.warning(f"{label}: 0 trades — raw HTML saved to {dump_path}")
                except Exception:
                    pass
            return trades, stats, commentary

        def _premium_portfolio_worker(_creds=creds, _results=_premium_results):
            """Scrape all Zacks premium portfolios in one Selenium session."""
            _td = None
            try:
                _td = _ultimate_login_driver(_creds)
                if not _td:
                    return
                time.sleep(3)
                for key, url, label in _PREMIUM_PORTFOLIOS:
                    try:
                        trades, stats, commentary = _scrape_zacks_portfolio_page(_td, url, label)
                        _results[key]["trades"] = trades
                        _results[key]["stats"] = stats
                        _results[key]["commentary"] = commentary
                    except Exception as _pe:
                        log.warning(f"{label} scrape failed (non-fatal): {_pe}")
            except Exception as _e:
                log.warning(f"Premium portfolios scrape failed (non-fatal): {_e}")
            finally:
                if _td:
                    try: _td.quit()
                    except Exception as _qe: log.debug(f"Premium portfolios driver quit: {_qe}")

        _premium_thread = threading.Thread(target=_premium_portfolio_worker, daemon=True)
        _premium_thread.start()

        # ── Zacks Rank #1 buy list ───────────────────────────────────────────
        driver.get("https://www.zacks.com/stocks/buy-list/")
        time.sleep(3)
        # Ask DataTables to show all rows
        try:
            driver.execute_script("""
                document.querySelectorAll('.dataTables_length select').forEach(function(s){
                    s.value='-1';
                    s.dispatchEvent(new Event('change',{bubbles:true}));
                });
            """)
            time.sleep(2)
        except Exception:
            pass

        soup2 = BeautifulSoup(driver.page_source, "html.parser")
        tickers = []
        zacks_r1_scores: dict[str, dict] = {}  # ticker → {value, growth, momentum, vgm}
        table = soup2.find("table", id="full_one_list_table_full_one_list")
        if table:
            # ── Detect VGM column positions by scanning row data ─────────────
            # Header-based detection is unreliable because "Symbol" and "Company"
            # share one data cell despite being two header columns.
            # Primary: vote on columns that contain A–F grades across 5+ data rows.
            grade_set = {"A", "B", "C", "D", "F", "A+", "B+", "C+", "D+", "A-", "B-", "C-", "D-"}
            grade_col_votes: dict[int, int] = {}
            for tr in table.find_all("tr")[1:10]:
                cells_samp = tr.find_all("td")
                for i, c in enumerate(cells_samp):
                    v = c.get_text(strip=True).upper()
                    if v in grade_set:
                        grade_col_votes[i] = grade_col_votes.get(i, 0) + 1
            grade_cols = sorted([i for i, cnt in grade_col_votes.items() if cnt >= 2])
            val_idx  = grade_cols[0] if len(grade_cols) > 0 else None
            grow_idx = grade_cols[1] if len(grade_cols) > 1 else None
            mom_idx  = grade_cols[2] if len(grade_cols) > 2 else None
            vgm_idx  = grade_cols[3] if len(grade_cols) > 3 else None
            log.info(f"VGM columns: val={val_idx} gro={grow_idx} mom={mom_idx} vgm={vgm_idx} "
                     f"(from grade votes: {grade_col_votes})")

            _debug_row_logged = False
            for tr in table.find_all("tr")[1:]:
                cells = tr.find_all("td")
                link = tr.find("a", href=re.compile(r"/stock/quote/"))
                if not link:
                    continue
                m_t = re.search(r"/stock/quote/([A-Z0-9.\-]{1,6})", link["href"])
                if not m_t:
                    continue
                t = m_t.group(1).replace(".", "-").upper()
                if t not in tickers:
                    tickers.append(t)

                def _grade(idx, _cells=cells):
                    if idx is not None and idx < len(_cells):
                        cell = _cells[idx]
                        # Try get_text first
                        g = cell.get_text(strip=True)
                        if g and g.upper() in {"A","A+","A-","B","B+","B-","C","C+","C-","D","D+","D-","F"}:
                            return g
                        # Try data attributes (some Zacks cells use data-value or title)
                        for attr in ["data-value", "title", "data-grade"]:
                            v = cell.get(attr, "").strip()
                            if v and v.upper() in {"A","A+","A-","B","B+","B-","C","C+","C-","D","D+","D-","F"}:
                                return v
                        # Check inner spans
                        for span in cell.find_all(["span", "div"]):
                            sv = span.get_text(strip=True)
                            if sv and sv.upper() in {"A","A+","A-","B","B+","B-","C","C+","C-","D","D+","D-","F"}:
                                return sv
                            for attr in ["data-value", "title", "data-grade"]:
                                sv2 = span.get(attr, "").strip()
                                if sv2 and sv2.upper() in {"A","A+","A-","B","B+","B-","C","C+","C-","D","D+","D-","F"}:
                                    return sv2
                        return g or "—"
                    return "—"

                # Debug: log ALL cells for first row so we can map header → data
                if not _debug_row_logged:
                    cell_map = {i: cells[i].get_text(strip=True)[:30] for i in range(len(cells))}
                    log.info(f"VGM debug row={t} ({len(cells)} cells): {cell_map}")
                    _debug_row_logged = True

                zacks_r1_scores[t] = {
                    "value":    _grade(val_idx),
                    "growth":   _grade(grow_idx),
                    "momentum": _grade(mom_idx),
                    "vgm":      _grade(vgm_idx),
                }
        # Fallback: any quote link on page (no score data)
        if not tickers:
            for link in soup2.find_all("a", href=re.compile(r"/stock/quote/")):
                m = re.search(r"/stock/quote/([A-Z0-9.\-]{1,6})", link["href"])
                if m:
                    t = m.group(1).replace(".", "-").upper()
                    if t not in tickers:
                        tickers.append(t)
        vgm_hit = sum(1 for v in zacks_r1_scores.values() if v.get("vgm","—") not in ("—",""))
        log.info(f"Zacks Rank #1: {len(tickers)} tickers, {vgm_hit}/{len(zacks_r1_scores)} with VGM grades")

        # ── Ultimate commentary ──────────────────────────────────────────────
        driver.get("https://www.zacks.com/ultimate/commentary.php")
        time.sleep(3)
        soup3 = BeautifulSoup(driver.page_source, "html.parser")
        ultimate_commentary = _parse_ultimate_commentary(soup3)
        log.info(f"Ultimate commentary: {len(ultimate_commentary)} items")

        # ── Ultimate Special Reports ─────────────────────────────────────────
        ultimate_special_reports = []
        try:
            driver.get("https://www.zacks.com/ultimate/special_reports.php")
            time.sleep(3)
            soup_sr = BeautifulSoup(driver.page_source, "html.parser")
            ultimate_special_reports = _parse_ultimate_special_reports(soup_sr)
            log.info(f"Ultimate special reports: {len(ultimate_special_reports)} reports")
        except Exception as _e:
            log.warning(f"Special reports scrape failed (non-fatal): {_e}")

        # ── Confidential commentary ──────────────────────────────────────────
        confidential_commentary = []
        try:
            driver.get("https://www.zacks.com/confidential/commentary.php")
            time.sleep(3)
            soup4 = BeautifulSoup(driver.page_source, "html.parser")
            confidential_commentary = _parse_confidential_commentary(soup4)
            log.info(f"Confidential commentary: {len(confidential_commentary)} items")
        except Exception as _e:
            log.warning(f"Confidential commentary scrape failed (non-fatal): {_e}")

        # ── Confidential overview (main portfolio page) ──────────────────────
        confidential_overview = {}
        try:
            driver.get("https://www.zacks.com/confidential/")
            time.sleep(4)
            soup5 = BeautifulSoup(driver.page_source, "html.parser")
            confidential_overview = _parse_confidential_overview(soup5)
            log.info(
                f"Confidential overview: {len(confidential_overview.get('positions', []))} positions"
            )
        except Exception as _e:
            log.warning(f"Confidential overview scrape failed (non-fatal): {_e}")

        sell_list = []
        try:
            sell_list = _scrape_zacks_sell_list(driver)
            log.info(f"Zacks sell list: {len(sell_list)} tickers")
        except Exception as _e:
            log.warning(f"Sell list scrape failed (non-fatal): {_e}")

        # ── Join premium portfolios background thread ─────────────────────────
        _premium_thread.join(timeout=300)  # 7 portfolios × ~12s each ≈ 84s + buffer

        result = {
            "zacks_r1": tickers,
            "zacks_r1_scores": zacks_r1_scores,
            "zacks_sell_list": sell_list,
            "ultimate_overview": ultimate_overview,
            "ultimate_all_trades": ultimate_all_trades,
            "ultimate_commentary": ultimate_commentary,
            "ultimate_special_reports": ultimate_special_reports,
            "confidential_commentary": confidential_commentary,
            "confidential_overview": confidential_overview,
            "error": None,
        }
        # Inject all premium portfolio data into result
        for key, _, _ in _PREMIUM_PORTFOLIOS:
            pr = _premium_results.get(key, {})
            result[f"{key}_trades"]          = pr.get("trades", [])
            result[f"{key}_portfolio_stats"] = pr.get("stats", {})
            result[f"{key}_commentary"]      = pr.get("commentary", [])
        # Save to disk cache for same-day re-runs
        _cache_write("zacks_all", result)
        return result

    except Exception as e:
        log.warning(f"Zacks premium fetch failed: {e}")
        empty["error"] = str(e)
        return empty
    finally:
        if driver:
            try:
                driver.quit()
            except Exception:
                pass


def build_zacks_grade_map(zacks_data: dict) -> dict:
    """
    Build unified ticker → grade dict from buy list + sell list.
    Merges VGM grades from Rank #1 (buy) and sell list into a single map.

    Returns: {ticker: {value, growth, momentum, vgm, list, rank}}
    - list: "buy" or "sell"
    - rank: 1 for buy, 5 for sell
    """
    grade_map = {}

    # Add buy list (Rank #1)
    for ticker, grades in zacks_data.get("zacks_r1_scores", {}).items():
        grade_map[ticker] = {
            "value": grades.get("value", "—"),
            "growth": grades.get("growth", "—"),
            "momentum": grades.get("momentum", "—"),
            "vgm": grades.get("vgm", "—"),
            "list": "buy",
            "rank": 1,
        }

    # Add sell list (Rank 5), overwriting if ticker appears in both
    for row in zacks_data.get("zacks_sell_list", []):
        ticker = row.get("ticker", "")
        if not ticker:
            continue
        grade_map[ticker] = {
            "value": row.get("value", "—"),
            "growth": row.get("growth", "—"),
            "momentum": row.get("momentum", "—"),
            "vgm": row.get("vgm", "—"),
            "list": "sell",
            "rank": 5,
        }

    log.info(f"Built grade map: {len(grade_map)} tickers (buy={sum(1 for g in grade_map.values() if g['list']=='buy')}, "
             f"sell={sum(1 for g in grade_map.values() if g['list']=='sell')})")
    return grade_map


def _parse_ultimate_overview(soup) -> dict:
    """
    Parse the Zacks Ultimate main page (zacks.com/ultimate/).
    Extracts headline performance stats, service description, and any
    portfolio summary metrics shown on the overview page.
    Returns: {description, stats: {label: value}, highlights: [str]}
    """
    description = ""
    stats: dict[str, str] = {}
    highlights: list[str] = []

    # ── Service description / intro text ─────────────────────────────────────
    for tag in soup.find_all(["p", "div"], class_=re.compile(r"intro|desc|about|lead|sub|hero")):
        txt = tag.get_text(strip=True)
        if 40 < len(txt) < 500 and not description:
            description = txt

    # ── Headline stats — look for common patterns ─────────────────────────────
    # Pattern 1: .stat-value / .stat-label pairs
    for container in soup.find_all(["div", "ul", "section"],
                                   class_=re.compile(r"stat|perf|metric|summary|overview|result")):
        labels = container.find_all(class_=re.compile(r"label|name|title|key|caption"))
        values = container.find_all(class_=re.compile(r"value|number|amount|data|figure"))
        for lbl, val in zip(labels, values):
            k = lbl.get_text(strip=True)
            v = val.get_text(strip=True)
            if k and v and len(k) < 80:
                stats[k] = v

    # Pattern 2: dt/dd pairs
    if not stats:
        for dl in soup.find_all("dl"):
            for dt, dd in zip(dl.find_all("dt"), dl.find_all("dd")):
                k = dt.get_text(strip=True)
                v = dd.get_text(strip=True)
                if k and v and len(k) < 80:
                    stats[k] = v

    # Pattern 3: table with 2 columns (label | value)
    if not stats:
        for table in soup.find_all("table"):
            tbl_id  = (table.get("id") or "").lower()
            tbl_cls = " ".join(table.get("class") or []).lower()
            if any(kw in tbl_id + tbl_cls for kw in ["stat", "perf", "summary", "overview"]):
                for tr in table.find_all("tr"):
                    cells = [td.get_text(strip=True) for td in tr.find_all(["td", "th"])]
                    if len(cells) == 2 and cells[0] and cells[1]:
                        stats[cells[0]] = cells[1]

    # ── Highlight bullets / feature list ─────────────────────────────────────
    for ul in soup.find_all("ul", class_=re.compile(r"feature|highlight|benefit|list")):
        for li in ul.find_all("li"):
            txt = li.get_text(strip=True)
            if 10 < len(txt) < 300:
                highlights.append(txt)
        if highlights:
            break

    # ── Fallback: scrape any bold number-looking spans on the page ───────────
    if not stats:
        for el in soup.find_all(["span", "strong", "b"],
                                class_=re.compile(r"num|pct|return|gain|rate|win")):
            val = el.get_text(strip=True)
            if re.match(r'^[+\-]?\d[\d,\.]+%?$', val):
                prev = el.find_previous_sibling()
                label = prev.get_text(strip=True) if prev else ""
                if label and len(label) < 80:
                    stats[label] = val

    return {
        "description": description,
        "stats":       stats,
        "highlights":  highlights[:10],
    }


def _parse_ultimate_table(soup, table_id: str) -> list[dict]:
    """Parse a Zacks Ultimate sortable table by id."""
    table = soup.find("table", id=table_id)
    if not table:
        return []

    rows = []
    for tr in table.find_all("tr")[1:]:  # skip header
        cells = tr.find_all("td")
        if len(cells) < 7:
            continue
        # Extract ticker symbol from link
        ticker = ""
        link = tr.find("a", href=re.compile(r"/stock/quote/"))
        if link:
            m = re.search(r"/stock/quote/([A-Z0-9.\-]{1,6})", link["href"])
            ticker = m.group(1).replace(".", "-").upper() if m else ""

        def cell_text(i):
            return cells[i].get_text(strip=True) if i < len(cells) else ""

        company = cell_text(0).replace("Quick Quote", "").replace(ticker, "").strip()[:40]
        trade_type = cell_text(2)  # Long/Short
        date_added = cell_text(3)
        price_add = cell_text(4)
        price_last = cell_text(5)
        pct_chg = cell_text(6)
        service = cell_text(7) if len(cells) > 7 else ""

        if not ticker:
            continue

        rows.append({
            "company": company,
            "ticker": ticker,
            "type": trade_type,
            "date_added": date_added,
            "price_add": price_add,
            "price_last": price_last,
            "pct_chg": pct_chg,
            "service": service
        })
    return rows


def _parse_ultimate_commentary(soup) -> list[dict]:
    """Parse Zacks Ultimate commentary articles using p.ts_post date markers."""
    articles = []

    # Each article has a <p class="ts_post">Posted on M/D/YY</p> element
    # followed by the article title and excerpt text
    date_tags = soup.find_all("p", class_="ts_post")

    for date_tag in date_tags[:5]:
        date_text = date_tag.get_text(strip=True)
        date_m = re.search(r'(\d+/\d+/\d+)', date_text)
        if not date_m:
            continue
        date_str = date_m.group(1)

        # Title is typically in the preceding sibling or parent context
        # Walk backwards to find a heading or the title text
        title = ""
        prev = date_tag.find_previous_sibling()
        while prev:
            txt = prev.get_text(strip=True)
            if txt and len(txt) > 15 and len(txt) < 200:
                title = txt
                break
            prev = prev.find_previous_sibling()

        # Excerpt: text in the next sibling elements
        excerpt_parts = []
        nxt = date_tag.find_next_sibling()
        while nxt and len(excerpt_parts) < 3:
            txt = nxt.get_text(strip=True)
            if txt and len(txt) > 20:
                excerpt_parts.append(txt)
            nxt = nxt.find_next_sibling()
        excerpt = " ".join(excerpt_parts)[:500]

        if date_str and (title or excerpt):
            articles.append({
                "title": title or "Market Commentary",
                "date": date_str,
                "excerpt": excerpt
            })

    return articles


def _parse_confidential_commentary(soup) -> list[dict]:
    """
    Parse Zacks Confidential commentary page.
    Tries p.ts_post date markers first (same structure as Ultimate commentary),
    then falls back to article/div card scanning.
    """
    articles = []

    # Primary: same p.ts_post pattern as Ultimate commentary
    date_tags = soup.find_all("p", class_="ts_post")
    if date_tags:
        for date_tag in date_tags[:8]:
            date_text = date_tag.get_text(strip=True)
            date_m = re.search(r'(\d+/\d+/\d+)', date_text)
            if not date_m:
                continue
            date_str = date_m.group(1)

            title = ""
            prev = date_tag.find_previous_sibling()
            while prev:
                txt = prev.get_text(strip=True)
                if txt and 15 < len(txt) < 200:
                    title = txt
                    break
                prev = prev.find_previous_sibling()

            excerpt_parts = []
            nxt = date_tag.find_next_sibling()
            while nxt and len(excerpt_parts) < 3:
                txt = nxt.get_text(strip=True)
                if txt and len(txt) > 20:
                    excerpt_parts.append(txt)
                nxt = nxt.find_next_sibling()

            if date_str and (title or excerpt_parts):
                articles.append({
                    "title": title or "Confidential Commentary",
                    "date": date_str,
                    "excerpt": " ".join(excerpt_parts)[:500],
                })
    else:
        # Fallback: scan article/div cards
        for card in soup.find_all(["article", "div"], class_=re.compile(r"post|article|entry|ts_")):
            title_tag = card.find(["h1", "h2", "h3", "h4", "a"])
            title = title_tag.get_text(strip=True) if title_tag else ""
            if not title or len(title) < 10:
                continue

            date_tag = card.find(["span", "p", "time"], class_=re.compile(r"date|time|post"))
            date_text = date_tag.get_text(strip=True) if date_tag else ""
            date_m = re.search(r'(\d+[/-]\d+[/-]\d+)', date_text)
            date_str = date_m.group(1) if date_m else ""

            ps = card.find_all("p")
            excerpt = " ".join(p.get_text(strip=True) for p in ps[:2])[:500]

            articles.append({"title": title, "date": date_str, "excerpt": excerpt})
            if len(articles) >= 8:
                break

    return articles[:8]


def _parse_confidential_overview(soup) -> dict:
    """
    Parse the Zacks Confidential main overview page (https://www.zacks.com/confidential/).
    Extracts:
      - stats: dict of headline performance numbers (total return, win rate, etc.)
      - positions: list of current portfolio positions (ticker, direction, buy date,
                   buy price, current price, gain/loss pct, status)
      - description: brief service description text
    """
    stats: dict[str, str] = {}
    positions: list[dict] = []
    description = ""

    # ── Service description / intro text ─────────────────��───────────────────
    for tag in soup.find_all(["p", "div"], class_=re.compile(r"intro|desc|about|sub")):
        txt = tag.get_text(strip=True)
        if 40 < len(txt) < 400:
            description = txt
            break

    # ── Headline stats (return, win rate, avg gain etc.) ─────────────────────
    # Zacks typically renders these as .stat-value / .stat-label pairs or in a
    # .portfolio-stats / .perf-stats container
    for container in soup.find_all(["div", "ul", "section"],
                                   class_=re.compile(r"stat|perf|metric|summary|overview")):
        labels  = container.find_all(class_=re.compile(r"label|name|title|key"))
        values  = container.find_all(class_=re.compile(r"value|number|amount|data"))
        for lbl, val in zip(labels, values):
            k = lbl.get_text(strip=True)
            v = val.get_text(strip=True)
            if k and v and len(k) < 60:
                stats[k] = v

    # Fallback: dt/dd pairs
    if not stats:
        for dl in soup.find_all("dl"):
            for dt, dd in zip(dl.find_all("dt"), dl.find_all("dd")):
                k = dt.get_text(strip=True)
                v = dd.get_text(strip=True)
                if k and v:
                    stats[k] = v

    # ── Portfolio positions table ─────────────────────────────────────────────
    # Try tables with id/class hinting at portfolio or trades
    for table in soup.find_all("table"):
        tbl_id  = (table.get("id")    or "").lower()
        tbl_cls = " ".join(table.get("class") or []).lower()
        if not any(kw in tbl_id + tbl_cls
                   for kw in ["portfolio", "position", "trade", "open", "hold", "stock"]):
            continue

        headers = [th.get_text(strip=True).lower()
                   for th in table.find_all("th")]

        for tr in table.find_all("tr")[1:]:
            cells = [td.get_text(strip=True) for td in tr.find_all(["td", "th"])]
            if not cells or len(cells) < 2:
                continue

            # Map cells to known column names where possible
            def _col(keys):
                for k in keys:
                    for i, h in enumerate(headers):
                        if k in h and i < len(cells):
                            return cells[i]
                # Fallback: positional
                return ""

            # Extract ticker from any cell matching uppercase ticker pattern
            ticker = ""
            for c in cells:
                m = re.search(r'\b([A-Z]{1,5})\b', c)
                if m and m.group(1) not in ("N", "A", "BUY", "SELL", "LONG", "SHORT"):
                    ticker = m.group(1)
                    break

            if not ticker:
                continue

            row = {
                "ticker":      ticker,
                "company":     _col(["company", "name", "stock"]),
                "direction":   "Long"  if any("long"  in c.lower() for c in cells)
                               else "Short" if any("short" in c.lower() for c in cells)
                               else _col(["type", "direction", "side"]) or "Long",
                "date_added":  _col(["date", "added", "bought", "open"]),
                "buy_price":   _col(["buy", "entry", "cost", "price add", "added price"]),
                "current":     _col(["current", "last", "price last", "close"]),
                "pct_chg":     _col(["gain", "return", "chg", "%", "perf"]),
                "status":      _col(["status", "signal"]),
            }
            # Remove empty-string values so downstream can use .get()
            positions.append({k: v for k, v in row.items() if v})

        if positions:
            break   # found one useful table, stop

    # ── If no table found, scan for ticker links ─────────────────────────────���
    if not positions:
        seen: set[str] = set()
        for a in soup.find_all("a", href=re.compile(r"/stock/quote/")):
            m = re.search(r"/stock/quote/([A-Z0-9.\-]{1,6})", a["href"])
            if m:
                t = m.group(1).upper()
                if t not in seen:
                    seen.add(t)
                    positions.append({"ticker": t, "direction": "Long"})

    return {
        "description": description,
        "stats":       stats,
        "positions":   positions,
    }


# ── TAZR parser ──────────────────────────────────────────────────────────────

def _parse_tazr_table(soup) -> tuple[list[dict], dict]:
    """
    Parse the Zacks TAZR Open Portfolio table.
    Returns (rows, portfolio_stats) where portfolio_stats has long_pct, short_pct, cash_pct.

    Columns: Company, Sym, Type, %Val, +Date, Rpt Date, $Add, $Last, %Chg
    The "+Date" cell may contain "Details >>" link text instead of a date.
    """
    rows = []
    portfolio_stats = {}

    # ── Portfolio header stats (e.g. "100.00% Long | 0.00% Short (0.00% Cash Available)") ──
    for el in soup.find_all(string=re.compile(r"\d+\.\d+%\s+Long", re.I)):
        txt = el.strip()
        m_long  = re.search(r'([\d.]+)%\s+Long',  txt, re.I)
        m_short = re.search(r'([\d.]+)%\s+Short', txt, re.I)
        m_cash  = re.search(r'\(([\d.]+)%\s+Cash', txt, re.I)
        if m_long:
            portfolio_stats["long_pct"]  = m_long.group(1)
            portfolio_stats["short_pct"] = m_short.group(1) if m_short else "0.00"
            portfolio_stats["cash_pct"]  = m_cash.group(1)  if m_cash  else "0.00"
            break

    # ── Find the Open Portfolio table ───────────────────────────────────────
    table = (soup.find("table", id=re.compile(r"tazr|port_sort|open.?port|portfolio", re.I))
             or soup.find("table", class_=re.compile(r"tazr|open.?port", re.I)))
    if not table:
        # Fallback 1: Header-based — find table with portfolio-like headers
        for t in soup.find_all("table"):
            hdrs = " ".join(th.get_text(strip=True) for th in t.find_all("th")).lower()
            if "%val" in hdrs or ("sym" in hdrs and "$add" in hdrs) or \
               ("sym" in hdrs and "%chg" in hdrs) or ("$add" in hdrs and "$last" in hdrs):
                table = t
                break
    if not table:
        # Fallback 2: DataTables wrapper — Zacks uses dataTables_wrapper divs
        for wrapper in soup.find_all("div", class_=re.compile(r"dataTables_wrapper", re.I)):
            t = wrapper.find("table")
            if t:
                hdrs = " ".join(th.get_text(strip=True) for th in t.find_all("th")).lower()
                if "sym" in hdrs or "company" in hdrs or "%chg" in hdrs:
                    table = t
                    break
    if not table:
        # Fallback 3: Any table with stock-quote links (most reliable)
        for t in soup.find_all("table"):
            links = t.find_all("a", href=re.compile(r"/stock/quote/"))
            if len(links) >= 3:  # At least 3 stock links = likely the portfolio table
                table = t
                break
    if not table:
        return rows, portfolio_stats

    # ── Map header text → data cell index ────────────────────────────────────
    # Different Zacks portfolios have very different column layouts:
    #   TAZR:  Company, Sym, Type, %Val, +Date, Rpt Date, $Add, $Last, %Chg
    #   CS:    Company, Sym, %Val, +Date, Type, $Add, $Last, %Chg, Rpt Date
    #   BBT:   Company, Sym, +Date, $Add, $Last, %Chg
    #   AEI:   Company, Sym, Segment, $Mkt Cap, +Date, $Add, $Last, %Chg
    # Additionally, data rows often have 1 fewer <td> than <th> (Company missing).
    #
    # Strategy: identify which <th> positions correspond to known fields,
    # detect the header→data offset, and build a position-aware col_map.

    all_th = table.find_all("th")
    headers = [th.get_text(strip=True) for th in all_th]

    # Map each header position to a canonical name (if recognized)
    _KW_MAP = {
        "company": ["company", "name"],
        "sym":     ["sym", "tick"],
        "type":    ["type"],
        "pct_val": ["%val"],
        "date_add":["+ date", "+date", "date add", "added"],
        "rpt_date":["rpt date", "rpt", "report"],
        "price_add":["$add", "add price", "price add", "entry"],
        "price_last":["$last", "last price", "current"],
        "pct_chg": ["%chg", "% chg"],
        "segment": ["segment", "industry"],
        "mkt_cap": ["$mkt", "mkt cap", "market cap"],
    }

    # Build ordered list of recognized headers in the FIRST contiguous block.
    # After the first unrecognized header, remaining <th> are overflow company names.
    real_headers = []  # [(header_idx, canon_name), ...] — only real column headers
    overflow_company_names = []
    in_overflow = False
    for hi, h in enumerate(headers):
        hl = h.lower().strip()
        if not hl:
            continue
        if in_overflow:
            overflow_company_names.append(h)
            continue
        matched_canon = None
        for canon, keywords in _KW_MAP.items():
            if any(kw == hl or (len(kw) > 2 and kw in hl) for kw in keywords):
                matched_canon = canon
                break
        if matched_canon:
            real_headers.append((hi, matched_canon))
        else:
            # First unrecognized header = start of company name overflow
            in_overflow = True
            overflow_company_names.append(h)

    # Find first data row
    first_data_row = None
    tbody = table.find("tbody")
    if tbody:
        first_data_row = tbody.find("tr")
    if not first_data_row:
        for _tr in table.find_all("tr"):
            if _tr.find("td"):
                first_data_row = _tr
                break

    n_data_cols = len(first_data_row.find_all("td")) if first_data_row else len(real_headers)
    n_real_headers = len(real_headers)

    # Offset = how many real headers exceed data cell count (typically 0 or 1)
    col_offset = max(0, n_real_headers - n_data_cols)

    # Build col_map: skip first `col_offset` headers, then map 1:1
    col_map = {}
    data_idx = 0
    for pos_i, (hi, canon) in enumerate(real_headers):
        if pos_i < col_offset:
            continue
        if data_idx >= n_data_cols:
            break
        col_map[canon] = data_idx
        data_idx += 1

    _row_idx = 0

    for tr in table.find_all("tr")[1:]:
        cells = tr.find_all("td")
        if len(cells) < 2:
            continue

        def _cell(canon_name):
            ci = col_map.get(canon_name)
            if ci is not None and 0 <= ci < len(cells):
                return cells[ci].get_text(strip=True)
            return ""

        # Ticker: prefer stock-quote link, then cell text
        ticker = ""
        link = tr.find("a", href=re.compile(r"/stock/quote/"))
        if link:
            m = re.search(r"/stock/quote/([A-Z0-9.\-]{1,10})", link["href"])
            ticker = m.group(1).replace(".", "-").upper() if m else ""
        if not ticker:
            raw_sym = _cell("sym").upper().strip()
            raw_sym = re.sub(r"QUICK\s*QUOTE.*", "", raw_sym, flags=re.I).strip()
            if raw_sym and len(raw_sym) <= 6:
                ticker = raw_sym
        if not ticker:
            continue

        # Company: from data cell, overflow <th> names, or Sym cell text
        company = _cell("company")
        if not company and _row_idx < len(overflow_company_names):
            company = overflow_company_names[_row_idx]
        if not company:
            first_cell_text = cells[0].get_text(strip=True) if cells else ""
            company = re.sub(r"Quick\s*Quote.*", "", first_cell_text, flags=re.I).replace(ticker, "").strip()
        company = re.sub(r"Quick\s*Quote", "", company, flags=re.I).replace(ticker, "").strip()[:45]
        _row_idx += 1

        # +Date: may be "Details >>" link
        date_add_raw = ""
        details_link = ""
        date_ci = col_map.get("date_add")
        if date_ci is not None and 0 <= date_ci < len(cells):
            cell_el = cells[date_ci]
            a_el = cell_el.find("a")
            if a_el:
                href = a_el.get("href", "")
                if not href.startswith("http"):
                    href = "https://www.zacks.com" + href
                details_link = href
                date_add_raw = "Details"
            else:
                date_add_raw = cell_el.get_text(strip=True)

        rows.append({
            "company":      company,
            "ticker":       ticker,
            "type":         _cell("type"),
            "pct_val":      _cell("pct_val"),
            "date_add":     date_add_raw,
            "details_link": details_link,
            "rpt_date":     _cell("rpt_date"),
            "price_add":    _cell("price_add"),
            "price_last":   _cell("price_last"),
            "pct_chg":      _cell("pct_chg"),
        })
    return rows, portfolio_stats


def _parse_tazr_commentary(soup) -> list[dict]:
    """
    Parse TAZR Commentary section.
    Structure: "TAZR Commentary" heading → articles with author photo, bold title,
    "By AuthorName" line, "Posted M/D/YY", then body paragraphs + links.
    Returns list of {title, author, date, body_html, body_text} dicts.
    """
    articles = []

    # Find the TAZR Commentary heading, then scan siblings/children for articles
    commentary_section = None
    for tag in soup.find_all(["h2", "h3", "h4", "div", "b", "strong"]):
        if "tazr commentary" in tag.get_text(strip=True).lower():
            commentary_section = tag
            break

    # Collect article containers after the heading
    # Each article: [img?] [h-tag title] ["By Author"] ["Posted date"] [p paragraphs...]
    article_containers = []
    if commentary_section:
        # Walk next siblings to collect article-like blocks
        sib = commentary_section.find_next_sibling()
        current = {"title": "", "author": "", "date": "", "paras": [], "img_src": ""}
        while sib and len(articles) < 10:
            tag_name = sib.name if sib.name else ""
            txt = sib.get_text(strip=True)

            if tag_name in ("h1", "h2", "h3", "h4") and txt and len(txt) > 10:
                # New article starts
                if current["title"] and (current["paras"] or current["date"]):
                    articles.append(current)
                current = {"title": txt, "author": "", "date": "", "paras": [], "img_src": ""}
            elif re.match(r"^By\s+\w", txt):
                current["author"] = re.sub(r"^By\s+", "", txt).strip()
            elif re.match(r"^Posted\s+\d", txt, re.I):
                dm = re.search(r'(\d+/\d+/\d+)', txt)
                current["date"] = dm.group(1) if dm else txt.replace("Posted ", "")
            elif tag_name == "img":
                current["img_src"] = sib.get("src", "")
            elif tag_name == "p" and txt and len(txt) > 5:
                # Capture paragraph HTML to preserve <a> links
                current["paras"].append(str(sib))
            sib = sib.find_next_sibling()
        if current["title"] and (current["paras"] or current["date"]):
            articles.append(current)

    # Fallback: p.ts_post pattern (used on other Zacks premium pages)
    if not articles:
        date_tags = soup.find_all("p", class_="ts_post")
        for date_tag in date_tags[:8]:
            date_text = date_tag.get_text(strip=True)
            date_m = re.search(r'(\d+/\d+/\d+)', date_text)
            if not date_m:
                continue
            date_str = date_m.group(1)
            title = ""
            prev = date_tag.find_previous_sibling()
            while prev:
                ptxt = prev.get_text(strip=True)
                if ptxt and 15 < len(ptxt) < 200:
                    title = ptxt
                    break
                prev = prev.find_previous_sibling()
            paras = []
            nxt = date_tag.find_next_sibling()
            while nxt and len(paras) < 6:
                ptxt = nxt.get_text(strip=True)
                if ptxt and len(ptxt) > 20:
                    paras.append(str(nxt))
                nxt = nxt.find_next_sibling()
            if date_str and (title or paras):
                articles.append({
                    "title":   title or "TAZR Commentary",
                    "author":  "",
                    "date":    date_str,
                    "paras":   paras,
                    "img_src": "",
                })

    # Normalise: build body_text from paras for plain-text fallback
    result = []
    for a in articles[:8]:
        paras = a.get("paras", [])
        # Strip script/style tags from captured HTML
        body_html = "\n".join(paras)
        body_text = " ".join(
            BeautifulSoup(p, "html.parser").get_text(strip=True) for p in paras
        )
        result.append({
            "title":     a.get("title", ""),
            "author":    a.get("author", ""),
            "date":      a.get("date", ""),
            "img_src":   a.get("img_src", ""),
            "body_html": body_html,
            "body_text": body_text[:2000],
        })
    return result


def _parse_ultimate_special_reports(soup) -> list[dict]:
    """
    Parse Zacks Ultimate Special Reports page.
    Returns list of {title, date, url, description} dicts.
    """
    reports = []
    # Reports are typically in article cards, list items, or table rows
    # Try article/div cards first
    for card in soup.find_all(["article", "div", "li"],
                              class_=re.compile(r"report|post|article|entry|item")):
        title_tag = card.find(["h1", "h2", "h3", "h4", "a"])
        if not title_tag:
            continue
        title = title_tag.get_text(strip=True)
        if not title or len(title) < 10 or len(title) > 300:
            continue
        # URL
        link_tag = card.find("a", href=True)
        href = link_tag["href"] if link_tag else ""
        if href and not href.startswith("http"):
            href = "https://www.zacks.com" + href
        # Date
        date_tag = card.find(["span", "p", "time"],
                             class_=re.compile(r"date|time|post"))
        date_text = date_tag.get_text(strip=True) if date_tag else ""
        date_m = re.search(r'(\d+[/-]\d+[/-]\d+)', date_text)
        date_str = date_m.group(1) if date_m else ""
        # Description
        ps = card.find_all("p")
        desc = " ".join(p.get_text(strip=True) for p in ps[:2])[:400]
        reports.append({
            "title": title,
            "date": date_str,
            "url": href,
            "description": desc,
        })
        if len(reports) >= 20:
            break

    # Fallback: any table rows
    if not reports:
        for table in soup.find_all("table"):
            for tr in table.find_all("tr")[1:]:
                cells = tr.find_all("td")
                if len(cells) < 2:
                    continue
                link_tag = tr.find("a", href=True)
                title = cells[0].get_text(strip=True) if cells else ""
                href = link_tag["href"] if link_tag else ""
                if href and not href.startswith("http"):
                    href = "https://www.zacks.com" + href
                date_str = cells[1].get_text(strip=True) if len(cells) > 1 else ""
                if title and len(title) > 5:
                    reports.append({"title": title, "date": date_str, "url": href, "description": ""})
            if reports:
                break
    return reports[:20]


# ── Market data ──────────────────────────────────────────────────────────────

def _yf_ticker_normalize(ticker: str) -> str:
    """Yahoo Finance uses hyphens for class shares (BRK.B → BRK-B)."""
    return ticker.replace(".", "-")


def _tv_exchange_for(ticker: str, yf_exchange: str = "") -> str:
    """Map a yfinance exchange string to a TradingView exchange name."""
    m = {"NMS": "NASDAQ", "NGM": "NASDAQ", "NCM": "NASDAQ", "NNM": "NASDAQ",
         "NYQ": "NYSE",   "NYS": "NYSE",   "BTS": "NYSE",
         "PCX": "AMEX",   "ASE": "AMEX"}
    return m.get(yf_exchange, "NASDAQ")


def _fetch_via_tvfeed(ticker: str, n_bars: int = 130) -> pd.DataFrame | None:
    """
    Layer 3: fetch OHLCV from TradingView data feed.
    Tries NASDAQ first, then NYSE. Returns a yfinance-compatible DataFrame
    (columns: Open, High, Low, Close, Volume) or None on failure.
    """
    if not _TV_DATAFEED or _tv_feed is None:
        return None
    yt = _yf_ticker_normalize(ticker)
    for exchange in ("NASDAQ", "NYSE", "AMEX"):
        try:
            df = _tv_feed.get_hist(yt, exchange, interval=TvInterval.in_daily,
                                   n_bars=n_bars)
            if df is not None and not df.empty and len(df) >= 20:
                df = df.rename(columns={"open": "Open", "high": "High",
                                        "low": "Low", "close": "Close",
                                        "volume": "Volume"})
                df.index = pd.to_datetime(df.index)
                return df[["Open", "High", "Low", "Close", "Volume"]]
        except Exception:
            pass
    return None


def _ohlcv_cache_path(ticker: str) -> Path:
    p = Path(__file__).parent / "cache" / "ohlcv"
    p.mkdir(parents=True, exist_ok=True)
    return p / f"{ticker.replace('/', '_')}.parquet"

def _ohlcv_cache_load(ticker: str, max_age_hours: int = 12) -> "pd.DataFrame | None":
    """Load cached OHLCV if fresh enough — session-aware, weekend-aware.

    Rules:
      1. Basic age check (default 12h, reduced from 20h).
      2. After Friday close, cache expires by Monday 4 AM ET (not 20h later).
      3. If the cached data's last bar date is older than the previous trading
         day, force a refresh regardless of file age.
    """
    cp = _ohlcv_cache_path(ticker)
    if not cp.exists():
        return None
    import time as _t
    from zoneinfo import ZoneInfo as _ZI

    file_mtime = cp.stat().st_mtime
    age_h = (_t.time() - file_mtime) / 3600

    # ── Weekend / Monday-morning override ─────────────────────────────────────
    # If cache was written Friday/Saturday, expire it by Monday 4 AM ET so the
    # first Monday scan always pulls fresh data.
    _now_et = datetime.now(_ZI("America/New_York"))
    _dow = _now_et.weekday()  # 0=Mon … 6=Sun
    _file_dt = datetime.fromtimestamp(file_mtime, tz=_ZI("America/New_York"))

    if _dow == 0 and _now_et.hour >= 4 and _file_dt.weekday() >= 4:
        # It's Monday after 4 AM ET and cache was written Fri/Sat/Sun → stale
        return None

    # ── Standard age check ────────────────────────────────────────────────────
    if age_h > max_age_hours:
        return None

    try:
        df = pd.read_parquet(cp)
    except Exception:
        return None

    # ── Last-bar staleness check ──────────────────────────────────────────────
    # If the most recent OHLCV bar is older than the previous trading day,
    # force refresh (handles holidays, half-days, and gaps).
    if df is not None and len(df) > 0:
        try:
            last_bar = pd.Timestamp(df.index[-1])
            if last_bar.tzinfo is not None:
                last_bar = last_bar.tz_convert("America/New_York").normalize()
            else:
                last_bar = last_bar.normalize()

            # Compute previous trading day (skip weekends)
            prev_td = _now_et.date()
            if _now_et.hour < 16:  # before market close, previous day is "today"
                prev_td -= timedelta(days=1)
            while prev_td.weekday() >= 5:  # skip Sat/Sun
                prev_td -= timedelta(days=1)

            if last_bar.date() < prev_td:
                return None  # cached data is missing the latest trading day
        except Exception:
            pass  # if index is non-datetime, skip this check

    return df

def _ohlcv_cache_save(ticker: str, df: "pd.DataFrame") -> None:
    try:
        df.to_parquet(_ohlcv_cache_path(ticker))
    except Exception:
        pass


def fetch_market_data(tickers: list[str], period: str = "6mo") -> dict[str, pd.DataFrame]:
    """
    Bulk OHLCV fetch — Polygon.io primary, archive fallback, Yahoo last resort.

    Data flow:
      Layer 0 — Data Archive (Parquet files, instant, 1005 tickers)
      Layer 1 — Polygon.io API (reliable, no rate limits on Starter)
      Layer 2 — Yahoo Finance (last resort only, rate-limited)
    """
    if not tickers:
        return {}

    result: dict[str, pd.DataFrame] = {}
    needs_fetch: list[str] = []

    # ── Layer 0: Data Archive (Parquet) — instant, covers 1005 tickers ──────
    try:
        from data_archive import load_ticker as _archive_load
        for t in tickers:
            df = _archive_load(t)
            if df is not None and len(df) >= 20:
                if df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                cols = [c for c in ["Open", "High", "Low", "Close", "Volume"] if c in df.columns]
                result[t] = df[cols].dropna(how="all")
            else:
                needs_fetch.append(t)
        log.info(f"  Archive: {len(result)}/{len(tickers)} tickers loaded from Parquet")
    except Exception:
        needs_fetch = list(tickers)

    if not needs_fetch:
        return result

    # ── Layer 1: Polygon.io API — reliable, no rate limits ──────────────────
    polygon_hits = 0
    still_need = []
    from concurrent.futures import ThreadPoolExecutor, as_completed
    def _poly_fetch(t):
        try:
            df = get_polygon_ohlcv(t, days=365, timespan="day")
            if df is not None and len(df) >= 20:
                if df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                cols = [c for c in ["Open", "High", "Low", "Close", "Volume"] if c in df.columns]
                return t, df[cols].dropna(how="all")
        except Exception:
            pass
        return t, None

    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {pool.submit(_poly_fetch, t): t for t in needs_fetch}
        for fut in as_completed(futures):
            t, df = fut.result()
            if df is not None:
                result[t] = df
                polygon_hits += 1
            else:
                still_need.append(t)

    if polygon_hits:
        log.info(f"  Polygon: {polygon_hits} tickers fetched via API")
    needs_fetch = still_need

    cache_hits = len(result)
    log.info(f"Downloading market data for {len(needs_fetch)} tickers (cache: {cache_hits}/{len(tickers)} hits)...")
    if not needs_fetch:
        return result
    tickers = needs_fetch

    # ── Layer 1: batch yf.download ────────────────────────────────────────────
    import time as _time_mod
    import signal as _signal
    _l1_start    = _time_mod.time()
    _l1_timeout  = 600  # 10 min hard cap on all of Layer 1
    _rate_errors = 0
    batch_size = 25

    def _batch_timeout_handler(signum, frame):
        raise TimeoutError("yf.download batch timeout")

    for i in range(0, len(tickers), batch_size):
        if _time_mod.time() - _l1_start > _l1_timeout:
            log.warning(f"Layer 1 wall-clock timeout ({_l1_timeout}s) — {len(result)}/{len(tickers)} fetched, continuing with cache+analysis")
            break
        batch = tickers[i: i + batch_size]
        yf_batch = [_yf_ticker_normalize(t) for t in batch]
        yf_to_orig = {_yf_ticker_normalize(t): t for t in batch}
        try:
            # 45s per-batch hard timeout using SIGALRM (prevents indefinite hang)
            _signal.signal(_signal.SIGALRM, _batch_timeout_handler)
            _signal.alarm(45)
            data = yf.download(
                yf_batch, period=period, interval="1d",
                group_by="ticker", progress=False, threads=False,
                auto_adjust=True,
            )
            _signal.alarm(0)  # cancel alarm on success
            if len(batch) == 1:
                orig = batch[0]
                if not data.empty:
                    df1 = data.copy()
                    # Flatten MultiIndex columns from single-ticker yf.download
                    if df1.columns.nlevels > 1:
                        df1.columns = df1.columns.droplevel("Ticker")
                    # Drop rows where Close is NaN (e.g. today's incomplete bar)
                    if "Close" in df1.columns:
                        df1 = df1[df1["Close"].notna()]
                    if len(df1) >= 20:
                        result[orig] = df1
                        _ohlcv_cache_save(orig, df1)
            else:
                top = data.columns.get_level_values(0).unique() if not data.empty else []
                for yf_t in yf_batch:
                    orig = yf_to_orig[yf_t]
                    try:
                        if yf_t in top:
                            df = data[yf_t].dropna(how="all")
                            # Drop rows where Close is NaN (intraday incomplete bars)
                            if "Close" in df.columns:
                                df = df[df["Close"].notna()]
                            if not df.empty and len(df) >= 20:
                                result[orig] = df.copy()
                                _ohlcv_cache_save(orig, df.copy())
                    except Exception:
                        pass
        except Exception as e:
            err_str = str(e).lower()
            if "rate" in err_str or "too many" in err_str or "429" in err_str:
                _rate_errors += 1
                _backoff = min(30 * (2 ** (_rate_errors - 1)), 120)  # 30s, 60s, 120s cap
                log.warning(f"Rate limited (batch {i//batch_size+1}, attempt {_rate_errors}) — backoff {_backoff}s")
                time.sleep(_backoff)
            else:
                log.warning(f"Batch L1 failed ({batch[0]}…{batch[-1]}): {e}")
        time.sleep(0.4)

    # ── Layer 2: Polygon retry for missing tickers ────────────────────────────
    missing = [t for t in tickers if t not in result]
    if missing and _rate_errors >= 3:
        log.warning(f"Heavy rate-limiting in L1 ({_rate_errors} errors) — switching to Polygon Layer 2")
    if missing:
        log.info(f"Layer 2 (Polygon) retry for {len(missing)} missing tickers...")
        _l2_start   = _time_mod.time()
        _l2_timeout = 300  # 5 min hard cap
        # Determine lookback days from period string
        _period_days = {"1mo": 30, "3mo": 90, "6mo": 180, "1y": 365, "2y": 730}.get(period, 180)
        for ticker in missing:
            if _time_mod.time() - _l2_start > _l2_timeout:
                log.warning(f"Layer 2 wall-clock timeout ({_l2_timeout}s) — {len(result)}/{len(tickers)} fetched")
                break
            try:
                df = get_polygon_ohlcv(ticker, days=_period_days, timespan="day")
                if df is not None and len(df) >= 20:
                    # Standardize to expected columns
                    df = df[["Open", "High", "Low", "Close", "Volume"]].copy()
                    df = df[df["Close"].notna()]
                    result[ticker] = df
                    _ohlcv_cache_save(ticker, df)
                    continue
            except Exception as _p_e:
                log.debug(f"Polygon L2 failed for {ticker}: {_p_e}")
            # Polygon fallback: per-ticker yfinance
            yt = _yf_ticker_normalize(ticker)
            try:
                _signal.signal(_signal.SIGALRM, _batch_timeout_handler)
                _signal.alarm(8)
                df = yf.Ticker(yt).history(period=period, interval="1d",
                                           auto_adjust=True, timeout=7)
                _signal.alarm(0)
                if not df.empty:
                    df = df[["Open", "High", "Low", "Close", "Volume"]]
                    df = df[df["Close"].notna()]
                    if len(df) >= 20:
                        result[ticker] = df
                        _ohlcv_cache_save(ticker, df)
            except Exception as _l2e:
                _signal.alarm(0)
                log.debug(f"L2 yf fallback failed for {ticker}: {_l2e}")
            time.sleep(0.1)

    # ── Layer 3: tvDatafeed for anything still missing ────────────────────────
    still_missing = [t for t in tickers if t not in result]
    if still_missing:
        if _TV_DATAFEED:
            log.info(f"Layer 3 tvDatafeed for {len(still_missing)} tickers...")
            for ticker in still_missing:
                df = _fetch_via_tvfeed(ticker)
                if df is not None:
                    result[ticker] = df
                time.sleep(0.3)
        else:
            log.info(
                f"{len(still_missing)} tickers still missing after L1/L2 "
                f"(tvDatafeed not installed — pip install tvDatafeed)"
            )

    filled = len(result)
    pct = filled / len(tickers) * 100 if tickers else 0
    log.info(f"Market data: {filled}/{len(tickers)} tickers ({pct:.0f}% fill rate)")
    return result


def get_live_price(ticker: str) -> float | None:
    """Return real-time last price via yfinance fast_info (< 1s, no full history pull).
    Returns None if market is closed or ticker not found."""
    try:
        fi = yf.Ticker(ticker).fast_info
        p = float(fi.last_price or 0)
        return p if p > 0 else None
    except Exception:
        return None


def _info_cache_path(ticker: str) -> Path:
    """Return path for cached .info JSON file."""
    p = Path(__file__).parent / "cache" / "info"
    p.mkdir(parents=True, exist_ok=True)
    return p / f"{ticker.replace('/', '_')}.json"


def _info_cache_load(ticker: str, max_age_days: int = 3):
    """Load cached info if fresh enough (3-day TTL for swing traders). Returns dict or None."""
    cp = _info_cache_path(ticker)
    try:
        if cp.exists():
            age_hours = (datetime.utcnow() - datetime.utcfromtimestamp(cp.stat().st_mtime)).total_seconds() / 3600
            if age_hours < max_age_days * 24:
                data = json.loads(cp.read_text())
                if data:  # don't serve empty cache
                    return data
    except Exception:
        pass
    return None


def _info_cache_save(ticker: str, info: dict) -> None:
    """Save info dict to disk cache."""
    try:
        if info:  # only cache non-empty results
            _info_cache_path(ticker).write_text(json.dumps(info))
    except Exception:
        pass


def get_stock_info(ticker: str) -> dict:
    """Fetch fundamental data from yfinance info dict."""
    # Check disk cache first (3-day TTL for swing traders — valuation ratios need to stay fresh)
    cached = _info_cache_load(ticker)
    if cached is not None:
        return cached
    try:
        import signal as _sig

        def _timeout_handler(signum, frame):
            raise TimeoutError("yfinance info timeout")

        _sig.signal(_sig.SIGALRM, _timeout_handler)
        _sig.alarm(5)  # 5s max per ticker — 401s should fail within 2s
        try:
            stock = yf.Ticker(ticker)
            info = stock.info or {}
        finally:
            _sig.alarm(0)  # cancel alarm
        result = {
            "ticker": ticker,
            "sector": info.get("sector", "Unknown"),
            "industry": info.get("industry", "Unknown"),
            "market_cap": info.get("marketCap", 0),
            "revenue_growth": info.get("revenueGrowth"),
            "earnings_growth": info.get("earningsGrowth"),
            "profit_margin": info.get("profitMargins"),
            "gross_margin": info.get("grossMargins"),
            "operating_margin": info.get("operatingMargins"),
            "roe": info.get("returnOnEquity"),
            "roa": info.get("returnOnAssets"),
            "debt_to_equity": info.get("debtToEquity"),
            "current_ratio": info.get("currentRatio"),
            "pe_ratio": info.get("trailingPE"),
            "forward_pe": info.get("forwardPE"),
            "peg_ratio": info.get("pegRatio"),
            "beta": info.get("beta"),
            "dividend_yield": info.get("dividendYield"),
            "short_pct": info.get("shortPercentOfFloat"),
            "target_mean_price": info.get("targetMeanPrice"),
            "target_high_price": info.get("targetHighPrice"),
            "target_low_price":  info.get("targetLowPrice"),
            "shares_float":      info.get("floatShares"),
            "recommendation": info.get("recommendationKey"),
            "num_analysts": info.get("numberOfAnalystOpinions"),
            "52w_high": info.get("fiftyTwoWeekHigh"),
            "52w_low": info.get("fiftyTwoWeekLow"),
            "avg_volume": info.get("averageVolume"),
            "name": info.get("shortName", ticker),
            "free_cashflow":    info.get("freeCashflow"),
            "ev_to_ebitda":     info.get("enterpriseToEbitda"),
            "price_to_book":    info.get("priceToBook"),
            "institutional_pct": round(info.get("institutionsPercentHeld", 0) * 100, 1) if info.get("institutionsPercentHeld") else None,
            "forward_eps":      info.get("forwardEps"),
            "trailing_eps":     info.get("trailingEps"),
            "ps_ratio":             info.get("priceToSalesTrailing12Months"),
            "operating_cashflow":   info.get("operatingCashflow"),
            "total_cash":           info.get("totalCash"),
            "earnings_qoq_growth":  info.get("earningsQuarterlyGrowth"),
            "forward_eps_growth":   round((info.get("forwardEps", 0) / info.get("trailingEps", 1) - 1), 4) if info.get("trailingEps") and info.get("trailingEps") != 0 else None,
            "price_to_cashflow":    round(info.get("marketCap", 0) / info.get("operatingCashflow", 1), 2) if info.get("operatingCashflow") and info.get("operatingCashflow") > 0 else None,
            "error": None
        }
        _info_cache_save(ticker, result)
        return result
    except Exception as e:
        # Try stale cache as fallback on error (up to 30 days old)
        stale = _info_cache_load(ticker, max_age_days=30)
        if stale:
            return stale
        log.debug(f"get_stock_info({ticker}): {e}")
        return {"ticker": ticker, "error": str(e)}


def get_quarterly_revenue_growth(ticker: str) -> float | None:
    """Fetch QoQ revenue growth from quarterly financials."""
    try:
        t = yf.Ticker(ticker)
        qf = t.quarterly_financials
        if qf is None or qf.empty:
            return None
        rev_row = None
        for label in ["Total Revenue", "Revenue"]:
            if label in qf.index:
                rev_row = qf.loc[label]
                break
        if rev_row is None or len(rev_row) < 2:
            return None
        q1 = float(rev_row.iloc[0])
        q2 = float(rev_row.iloc[1])
        if q2 == 0:
            return None
        return round((q1 / q2 - 1), 4)
    except Exception:
        return None


def get_stock_info_batch(tickers: list[str], max_workers: int = 6) -> dict[str, dict]:
    """Fetch fundamental info for multiple tickers in parallel.

    Optimisations:
    1. Cache-first: serve tickers with a fresh disk cache instantly (no thread overhead).
    2. Only submit uncached tickers to the thread pool.
    3. Higher worker count (16) for the uncached subset — most will hit 401 quickly.
    """
    results = {}

    # ── Pass 1: serve from disk cache immediately ─────────────────────────────
    uncached = []
    for t in tickers:
        cached = _info_cache_load(t)  # 3-day TTL
        if cached is not None:
            results[t] = cached
        else:
            uncached.append(t)

    if not uncached:
        return results

    # ── Pass 2: fetch only the uncached tickers in parallel ───────────────────
    workers = min(16, max(max_workers, len(uncached)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(get_stock_info, t): t for t in uncached}
        for fut in as_completed(futures):
            ticker = futures[fut]
            try:
                results[ticker] = fut.result()
            except Exception as e:
                results[ticker] = {"ticker": ticker, "error": str(e)}
    return results


def get_market_regime(breadth: dict | None = None) -> dict:
    """
    Assess market regime from SPY + QQQ technicals + VIX + market breadth.
    4-regime classification:
    - risk_on_trending: SPY > 50/200, QQQ > 50, VIX < 18, breadth > 65%
    - risk_on_choppy: SPY > 50, VIX 18-25, breadth 40-65%
    - risk_off_trending: SPY < 50, VIX 25-35, breadth 20-40%
    - panic: VIX > 35 OR breadth < 20%
    Legacy mapping: risk_on_trending→bull, risk_on_choppy→neutral, risk_off→bear, panic→bear
    """
    try:
        # Polygon primary for SPY/QQQ (365 days of daily bars)
        _spy_df = get_polygon_ohlcv("SPY", days=365, timespan="day")
        _qqq_df = get_polygon_ohlcv("QQQ", days=365, timespan="day")

        # yfinance fallback
        if _spy_df is None or len(_spy_df) < 50:
            _spy_df = yf.download("SPY", period="1y", interval="1d", progress=False, auto_adjust=True)
        if _qqq_df is None or len(_qqq_df) < 50:
            _qqq_df = yf.download("QQQ", period="1y", interval="1d", progress=False, auto_adjust=True)

        if (_spy_df is None or len(_spy_df) < 10) and (_qqq_df is None or len(_qqq_df) < 10):
            return {"regime": "unknown", "regime4": "unknown", "spy_price": 0}

        close_series = _spy_df["Close"].squeeze().dropna()
        vol_series   = _spy_df["Volume"].squeeze().dropna() if "Volume" in _spy_df.columns else None
        if close_series.empty:
            return {"regime": "unknown", "regime4": "unknown", "spy_price": 0}

        close = close_series.values
        price = float(close[-1])

        ema50  = _ema(close, 50)
        sma200 = _sma(close, 200)

        # QQQ technicals
        qqq_close = _qqq_df["Close"].squeeze().dropna().values
        qqq_ema50 = _ema(qqq_close, 50) if len(qqq_close) >= 50 else qqq_close[-1]
        qqq_price = float(qqq_close[-1]) if len(qqq_close) > 0 else 0
        qqq_above_ema50 = qqq_price > qqq_ema50 if qqq_ema50 else False

        # Today's SPY % change (entry day gate)
        spy_daily_chg = ((close[-1] - close[-2]) / close[-2] * 100) if len(close) >= 2 else 0.0

        # SPY 1-month return
        spy_1m_ret = (price / float(close[-21]) - 1) * 100 if len(close) >= 21 else 0

        above_50  = price > ema50  if ema50  else False
        above_200 = price > sma200 if sma200 else False

        # 3-regime for legacy compatibility
        if above_50 and above_200:
            regime = "bull"
        elif not above_50 and not above_200:
            regime = "bear"
        else:
            regime = "neutral"

        # Get VIX and breadth
        vix_data   = get_vix_data()
        vix_cur    = (vix_data or {}).get("vix_current")
        if vix_cur is None:
            vix_cur = 20  # safe default when VIX fetch failed

        # Get market breadth (% of stocks above 50DMA)
        pct_above_50d = 50  # default fallback
        if breadth and isinstance(breadth, dict):
            _b = breadth.get("pct_above_50d")
            if _b is not None:
                pct_above_50d = _b

        # 4-regime classification with hysteresis
        # Load previous regime from cache for hysteresis buffer
        _hysteresis_fp = BASE_DIR / "cache" / "regime_hysteresis.json"
        _prev_regime4 = "risk_on_choppy"  # default if no cache
        try:
            if _hysteresis_fp.exists():
                _hyst_data = json.loads(_hysteresis_fp.read_text())
                _prev_regime4 = _hyst_data.get("regime4", "risk_on_choppy")
        except Exception:
            pass

        # Load hysteresis config (buffers to prevent whipsaws)
        _cfg_loaded = json.loads(CONFIG_PATH.read_text()) if CONFIG_PATH.exists() else {}
        _hyst_cfg = _cfg_loaded.get("regime_hysteresis", {})
        _vix_risk_off_enter = _hyst_cfg.get("vix_risk_off_enter", 22)
        _vix_risk_on_return = _hyst_cfg.get("vix_risk_on_return", 18)
        _breadth_bull_enter = _hyst_cfg.get("breadth_bullish_enter", 53)
        _breadth_bear_enter = _hyst_cfg.get("breadth_bearish_enter", 47)

        # Apply hysteresis: use buffered thresholds based on current regime direction
        _is_currently_risk_off = _prev_regime4 in ("risk_off_trending", "panic")
        _is_currently_risk_on = _prev_regime4 in ("risk_on_trending",)

        # VIX hysteresis: harder to enter risk-off, harder to leave it
        _vix_threshold_for_risk_on = _vix_risk_on_return if _is_currently_risk_off else 18
        _vix_threshold_for_risk_off = _vix_risk_off_enter if not _is_currently_risk_off else 18

        # Breadth hysteresis: require overshoot before flipping
        _breadth_for_bull = _breadth_bull_enter if not _is_currently_risk_on else 50
        _breadth_for_bear = _breadth_bear_enter if _is_currently_risk_on else 50

        if (vix_cur is not None and vix_cur > 35) or (pct_above_50d is not None and pct_above_50d < 20):
            regime4 = "panic"
        elif not above_50:
            regime4 = "risk_off_trending"
        elif (above_50 and above_200 and qqq_above_ema50
              and vix_cur is not None and vix_cur < _vix_threshold_for_risk_on
              and pct_above_50d is not None and pct_above_50d > max(65, _breadth_for_bull)):
            regime4 = "risk_on_trending"
        else:
            regime4 = "risk_on_choppy"

        # Persist current regime for next run's hysteresis
        try:
            _hysteresis_fp.parent.mkdir(parents=True, exist_ok=True)
            _hysteresis_fp.write_text(json.dumps({
                "regime4": regime4,
                "prev_regime4": _prev_regime4,
                "vix": vix_cur,
                "breadth_50d": pct_above_50d,
            }))
        except Exception:
            pass

        # Map 4-regime back to legacy 3-regime for backward compatibility
        _regime4_to_legacy = {
            "risk_on_trending": "bull",
            "risk_on_choppy": "neutral",
            "risk_off_trending": "bear",
            "panic": "bear",
        }
        _publish_regime_base = _regime4_to_legacy.get(regime4, "neutral")

        # Distribution days: down days on higher volume than prior day (last 25 sessions)
        dist_days = 0
        if vol_series is not None and len(vol_series) >= 26:
            vol = vol_series.values
            c   = close_series.values
            for i in range(-25, 0):
                if c[i] < c[i - 1] and vol[i] > vol[i - 1]:
                    dist_days += 1

        # Market cycle: four-phase model
        # Early bull: recovering from below 200d, breadth expanding
        # Mid bull: above all MAs, VIX low, cyclicals leading
        # Late bull: above MAs but defensives outperforming
        # Bear/correction: below 200d
        vix_data   = get_vix_data()
        vix_cur    = (vix_data or {}).get("vix_current")
        if vix_cur is None:
            vix_cur = 20  # safe default when VIX fetch failed
        spy_3m_ret = (price / float(close[-63]) - 1) * 100 if len(close) >= 63 else spy_1m_ret

        if not above_200:
            market_cycle = "bear"
        elif above_50 and above_200 and vix_cur is not None and vix_cur < 18 and spy_3m_ret is not None and spy_3m_ret > 5:
            market_cycle = "mid_bull"
        elif above_50 and above_200 and spy_1m_ret is not None and spy_1m_ret > 0:
            market_cycle = "early_bull" if (spy_3m_ret is not None and spy_3m_ret < 5) else "mid_bull"
        elif above_200 and not above_50:
            market_cycle = "late_bull" if (spy_1m_ret is not None and spy_1m_ret < 0) else "neutral"
        else:
            market_cycle = "neutral"

        # ── 2-bar confirmation: require 2 consecutive bars before publishing a regime4 flip ──
        # Prevents whipsaws when SPY briefly crosses EMA50/SMA200 for a single session.
        from datetime import date as _date
        _today_str = str(_date.today())
        _rh_fp = BASE_DIR / "cache" / "regime_history.json"
        try:
            _rh = json.loads(_rh_fp.read_text()) if _rh_fp.exists() else {}
        except Exception:
            _rh = {}

        _confirmed_regime4 = _rh.get("confirmed_regime4", regime4)
        _pending   = _rh.get("pending_flip", {})

        if regime4 == _confirmed_regime4:
            # Sustained regime — clear any stale pending flip
            _rh["confirmed_regime4"] = regime4
            _rh["pending_flip"] = {}
            _publish_regime4 = regime4
        elif _pending.get("regime4") == regime4 and _pending.get("date") != _today_str:
            # Second bar agrees with new regime → confirm the flip
            _rh["confirmed_regime4"] = regime4
            _rh["pending_flip"] = {}
            _rh["flip_confirmed_date"] = _today_str
            _publish_regime4 = regime4
            log.info(f"Market regime4 flip CONFIRMED: {_confirmed_regime4} → {regime4}")
        else:
            # First bar of a different regime → hold prior, store as pending
            if _pending.get("regime4") != regime4:
                log.info(f"Market regime4 flip PENDING: {_confirmed_regime4} → {regime4} (need 2nd bar)")
            _rh["pending_flip"] = {"regime4": regime4, "date": _today_str}
            _publish_regime4 = _confirmed_regime4

        # Legacy 3-regime for backward compatibility (from confirmed regime4)
        _publish_regime = _regime4_to_legacy.get(_publish_regime4, "neutral")

        try:
            _rh_fp.parent.mkdir(parents=True, exist_ok=True)
            _rh_fp.write_text(json.dumps(_rh))
        except Exception as e:
            log.debug(f"Regime history write failed: {e}")

        # Market cycle (4-phase for legacy compatibility)
        spy_3m_ret = (price / float(close[-63]) - 1) * 100 if len(close) >= 63 else spy_1m_ret
        if not above_200:
            market_cycle = "bear"
        elif above_50 and above_200 and vix_cur is not None and vix_cur < 18 and spy_3m_ret is not None and spy_3m_ret > 5:
            market_cycle = "mid_bull"
        elif above_50 and above_200 and spy_1m_ret is not None and spy_1m_ret > 0:
            market_cycle = "early_bull" if (spy_3m_ret is not None and spy_3m_ret < 5) else "mid_bull"
        elif above_200 and not above_50:
            market_cycle = "late_bull" if (spy_1m_ret is not None and spy_1m_ret < 0) else "neutral"
        else:
            market_cycle = "neutral"

        # Max position size based on regime4
        _max_size_pct_map = {
            "risk_on_trending": 100,
            "risk_on_choppy": 70,
            "risk_off_trending": 35,
            "panic": 0,
        }
        max_size_pct = _max_size_pct_map.get(_publish_regime4, 70)

        return {
            # Legacy 3-regime (backward compatible)
            "regime":               _publish_regime,
            "regime_raw":           regime,
            "regime_pending_flip":  _pending.get("regime") if regime != _publish_regime else None,
            # New 4-regime system
            "regime4":              _publish_regime4,
            "regime4_raw":          regime4,
            "qqq_above_ema50":      qqq_above_ema50,
            "qqq_price":            round(qqq_price, 2),
            "breadth_pct_50d":      pct_above_50d,
            "max_size_pct":         max_size_pct,
            # Technical levels
            "spy_price":            round(price, 2),
            "spy_ema50":            round(ema50,  2) if ema50  else None,
            "spy_sma200":           round(sma200, 2) if sma200 else None,
            "above_50ema":          above_50,
            "above_200sma":         above_200,
            # Market data
            "spy_1m_ret":           round(spy_1m_ret, 1),
            "spy_daily_chg":        round(float(spy_daily_chg), 2),
            "distribution_days":    dist_days,
            "market_cycle":         market_cycle,
            "vix":                  vix_data,
            "vix_current":          vix_cur,
        }
    except Exception as e:
        log.error(f"Market regime check failed: {e}")
        return {"regime": "unknown", "spy_price": 0}


@_mem_cached(ttl_seconds=7200)
def get_earnings_date(ticker: str) -> dict:
    """Check earnings proximity for a ticker."""
    try:
        stock = yf.Ticker(ticker)
        cal = stock.calendar
        if cal is not None and not (isinstance(cal, pd.DataFrame) and cal.empty):
            if isinstance(cal, dict):
                ed = cal.get("Earnings Date")
                if isinstance(ed, list) and ed:
                    ed = ed[0]
            elif isinstance(cal, pd.DataFrame):
                if "Earnings Date" in cal.columns:
                    ed = cal["Earnings Date"].iloc[0]
                elif "Earnings Date" in cal.index:
                    ed = cal.loc["Earnings Date"].iloc[0]
                else:
                    ed = None
            else:
                ed = None

            if ed is not None:
                if isinstance(ed, str):
                    ed = pd.to_datetime(ed, utc=True)
                elif hasattr(ed, 'date'):
                    if ed.tzinfo is None:
                        ed = ed.tz_localize("UTC")
                now = pd.Timestamp.now(tz="UTC")
                days = (ed - now).days
                return {
                    "earnings_date": str(ed.date()) if hasattr(ed, 'date') else str(ed),
                    "days_to_earnings": max(0, days),
                    "earnings_risk": 0 <= days <= 5
                }
        return {"earnings_date": None, "days_to_earnings": None, "earnings_risk": False}
    except Exception:
        return {"earnings_date": None, "days_to_earnings": None, "earnings_risk": False}


@_mem_cached(ttl_seconds=1800)
def get_news_sentiment(ticker: str) -> dict:
    """Simple news sentiment from Yahoo Finance RSS."""
    try:
        url = f"https://feeds.finance.yahoo.com/rss/2.0/headline?s={ticker}&region=US&lang=en-US"
        resp = requests.get(url, timeout=8)
        if resp.status_code != 200:
            return {"score": 0, "headlines": 0, "bias": "neutral"}

        soup = BeautifulSoup(resp.text, "xml")
        items = soup.find_all("item")[:10]

        positive = {"beat", "surge", "upgrade", "bullish", "growth", "profit",
                     "wins", "partnership", "deal", "buyback", "record", "strong",
                     "accelerat", "outperform", "raises", "positive"}
        negative = {"miss", "downgrade", "bearish", "cut", "loss", "lawsuit",
                    "recall", "decline", "warns", "layoff", "weak", "fall",
                    "underperform", "negative", "disappoint", "risk"}

        pos_count, neg_count = 0, 0
        for item in items:
            title = (item.find("title").text or "").lower()
            pos_count += sum(1 for w in positive if w in title)
            neg_count += sum(1 for w in negative if w in title)

        net = pos_count - neg_count
        if net >= 3:
            score, bias = 3, "bullish"
        elif net >= 1:
            score, bias = 1, "slightly bullish"
        elif net <= -3:
            score, bias = -3, "bearish"
        elif net <= -1:
            score, bias = -1, "slightly bearish"
        else:
            score, bias = 0, "neutral"

        return {"score": score, "headlines": len(items), "bias": bias,
                "positive": pos_count, "negative": neg_count}
    except Exception:
        return {"score": 0, "headlines": 0, "bias": "neutral"}


_sec_cik_map: dict[str, str] = {}   # ticker → zero-padded CIK (loaded once)
_sec_cik_loaded = False


def _load_sec_cik_map() -> None:
    """Load SEC company_tickers.json into module-level dict (one-time call, cached 24h)."""
    global _sec_cik_map, _sec_cik_loaded
    if _sec_cik_loaded:
        return
    cache_fp = BASE_DIR / "cache" / "_cache_sec_cik_map.json"
    # Use on-disk cache if fresh (< 24 h)
    if cache_fp.exists() and time.time() - cache_fp.stat().st_mtime < 86400:
        try:
            _sec_cik_map = json.loads(cache_fp.read_text())
            _sec_cik_loaded = True
            return
        except Exception:
            pass
    try:
        resp = requests.get(
            "https://www.sec.gov/files/company_tickers.json",
            timeout=15,
            headers={"User-Agent": "SwingTrade research@swingtradeapp.com"},
        )
        if resp.status_code == 200:
            raw = resp.json()  # {0: {cik_str: "...", ticker: "AAPL", ...}, ...}
            _sec_cik_map = {v["ticker"].upper(): str(v["cik_str"]).zfill(10)
                            for v in raw.values()}
            cache_fp.parent.mkdir(exist_ok=True)
            cache_fp.write_text(json.dumps(_sec_cik_map))
            _sec_cik_loaded = True
    except Exception as e:
        log.debug(f"SEC CIK map load failed: {e}")
        _sec_cik_loaded = True  # don't retry on every call


def get_insider_activity(ticker: str) -> dict:
    """Check recent insider trading via SEC EDGAR submissions API (Form 4 filings).
    Uses data.sec.gov/submissions/{CIK}.json — stable JSON, no scraping."""
    cached = _cache_read(f"insider_{ticker}", ttl_seconds=3600)
    if cached:
        return cached

    _empty = {"buys": 0, "sells": 0, "sentiment": "neutral"}

    # ── Primary: SEC submissions API via CIK ────────────────────────────────
    try:
        _load_sec_cik_map()
        cik = _sec_cik_map.get(ticker.upper())
        if not cik:
            raise ValueError(f"No CIK for {ticker}")

        url = f"https://data.sec.gov/submissions/CIK{cik}.json"
        resp = requests.get(url, timeout=12, headers={
            "User-Agent": "SwingTrade research@swingtradeapp.com"
        })
        if resp.status_code != 200:
            raise ValueError(f"SEC submissions HTTP {resp.status_code}")

        data = resp.json()
        filings = data.get("filings", {}).get("recent", {})
        forms   = filings.get("form", [])
        dates   = filings.get("filingDate", [])
        accnums = filings.get("accessionNumber", [])

        cutoff = datetime.now() - timedelta(days=90)
        buys = sells = 0
        for form, date_str, accn in zip(forms, dates, accnums):
            if form not in ("4", "4/A"):
                continue
            try:
                dt = datetime.strptime(date_str, "%Y-%m-%d")
            except Exception:
                continue
            if dt < cutoff:
                continue

            # Fetch the actual form XML to determine buy vs sell
            accn_clean = accn.replace("-", "")
            xml_url = (f"https://www.sec.gov/Archives/edgar/data/"
                       f"{int(cik)}/{accn_clean}/{accn}.txt")
            try:
                r2 = requests.get(xml_url, timeout=8, headers={
                    "User-Agent": "SwingTrade research@swingtradeapp.com"
                })
                txt = r2.text.lower()
                # transactionCode: P = purchase, S = sale
                if "transactioncode>p<" in txt or ">p</transactioncode>" in txt:
                    buys += 1
                elif "transactioncode>s<" in txt or ">s</transactioncode>" in txt:
                    sells += 1
            except Exception:
                # If XML fetch fails, use filing count heuristic (all Form 4 = activity)
                buys += 1

        # Stop after checking first 10 recent Form 4s to keep runtime short
        if buys + sells == 0 and len([f for f in forms if f in ("4", "4/A")]) > 0:
            # Couldn't determine direction — use count as proxy for activity
            count_4 = sum(1 for f, d in zip(forms, dates)
                          if f in ("4", "4/A")
                          and datetime.strptime(d[:10], "%Y-%m-%d") > cutoff)
            if count_4 >= 3:
                buys = count_4  # treat unknown as buy (insiders file more on open-market buys)

        sentiment = ("bullish" if buys > sells + 1
                     else "bearish" if sells > buys + 1
                     else "neutral")
        result = {
            "buys": buys,
            "sells": sells,
            "sentiment": sentiment,
            # Enhanced fields for hierarchy-weighted scoring
            "ceo_buy": False,   # will be enriched by OpenInsider fallback if needed
            "cfo_buy": False,
            "total_buy_value": 0,
            "max_single_buy": 0,
        }
        _cache_write(f"insider_{ticker}", result)
        return result

    except Exception as e:
        log.debug(f"SEC insider {ticker}: {e}")

    # ── Fallback: OpenInsider JSON endpoint with role + value extraction ────────
    try:
        url2 = (f"https://openinsider.com/screener?s={ticker}&o=&pl=&ph=&st=0&fd=90"
                f"&fdr=&td=0&tdr=&fdlyl=&fdlyh=&dtefrom=&dteto=&xp=1&xs=1&vession=3")
        resp2 = requests.get(url2, timeout=8, headers={"User-Agent": "Mozilla/5.0"})
        text = resp2.text

        purchases = re.findall(r'Purchase', text)
        sales_list = re.findall(r'(?<![A-Za-z])Sale(?! Disc)', text)
        b = len(purchases)
        s = len(sales_list)

        # CEO/CFO role detection from title column
        ceo_buy = bool(re.search(r'(CEO|Chief Executive|President.*CEO)', text, re.I)
                       and purchases)
        cfo_buy = bool(re.search(r'(CFO|Chief Financial)', text, re.I) and purchases)

        # Extract transaction values from "$X,XXX,XXX" patterns near "Purchase"
        val_matches = re.findall(r'Purchase[^<]{0,200}\$([0-9,]+)', text, re.DOTALL)
        buy_values = []
        for vm in val_matches:
            try:
                buy_values.append(int(vm.replace(",", "")))
            except ValueError:
                pass
        total_buy_value = sum(buy_values)
        max_single_buy  = max(buy_values) if buy_values else 0

        sent = "bullish" if b > s + 2 else "bearish" if s > b + 2 else "neutral"
        return {
            "buys": b, "sells": s, "sentiment": sent,
            "ceo_buy": ceo_buy, "cfo_buy": cfo_buy,
            "total_buy_value": total_buy_value,
            "max_single_buy": max_single_buy,
        }
    except Exception:
        return {**_empty, "ceo_buy": False, "cfo_buy": False,
                "total_buy_value": 0, "max_single_buy": 0}


_TV_EXCHANGE_MAP = {
    "NMS": "NASDAQ", "NGM": "NASDAQ", "NCM": "NASDAQ", "NNM": "NASDAQ",
    "NYQ": "NYSE",   "NYS": "NYSE",   "BTS": "NYSE",
    "PCX": "AMEX",   "ASE": "AMEX",
}


def get_tv_ratings_batch(tickers: list[str], exchange_map: dict | None = None) -> dict[str, dict]:
    """
    Fetch TradingView technical ratings for multiple tickers via the public scanner API.
    Returns dict: ticker → {recommendation, buy, neutral, sell, rec_value, rsi, macd_bullish}

    Premium membership gives real-time quotes (vs 15-min delayed on free plan).
    """
    if not tickers:
        return {}

    results = {}
    em = exchange_map or {}

    def _format(t):
        ex = _TV_EXCHANGE_MAP.get(em.get(t, ""), "NASDAQ")
        return f"{ex}:{t}"

    columns = [
        "name", "Recommend.All", "Recommend.MA", "Recommend.Other",
        "RSI", "MACD.macd", "MACD.signal", "close",
        "EMA20", "EMA50", "EMA200", "volume",
    ]

    batch_size = 200
    for i in range(0, len(tickers), batch_size):
        batch = tickers[i:i + batch_size]
        symbols = [_format(t) for t in batch]
        try:
            resp = requests.post(
                "https://scanner.tradingview.com/america/scan",
                json={
                    "symbols": {"tickers": symbols, "query": {"types": []}},
                    "columns": columns,
                },
                headers={"Content-Type": "application/json",
                         "User-Agent": "Mozilla/5.0"},
                timeout=15,
            )
            if resp.status_code != 200:
                log.warning(f"TV scanner HTTP {resp.status_code}")
                continue

            for row in resp.json().get("data", []):
                raw_ticker = row.get("s", "").split(":")[-1].upper()
                d = row.get("d", [])
                if not d or d[1] is None:
                    continue
                rec_val = d[1]  # -1 (strong sell) to +1 (strong buy)
                if   rec_val >= 0.5:  rec = "STRONG_BUY"
                elif rec_val >= 0.1:  rec = "BUY"
                elif rec_val >= -0.1: rec = "NEUTRAL"
                elif rec_val >= -0.5: rec = "SELL"
                else:                 rec = "STRONG_SELL"

                results[raw_ticker] = {
                    "recommendation": rec,
                    "rec_value":      round(rec_val, 3),
                    "ma_rec":         d[2],
                    "osc_rec":        d[3],
                    "rsi":            round(d[4], 1) if d[4] else None,
                    "macd":           round(d[5], 4) if d[5] else None,
                    "macd_signal":    round(d[6], 4) if len(d) > 6 and d[6] else None,
                    "ema20":          round(d[8],  2) if len(d) > 8  and d[8]  else None,
                    "ema50":          round(d[9],  2) if len(d) > 9  and d[9]  else None,
                    "ema200":         round(d[10], 2) if len(d) > 10 and d[10] else None,
                }
        except Exception as e:
            log.warning(f"TV scanner batch {i}–{i+batch_size} failed: {e}")

    log.info(f"TV ratings: {len(results)}/{len(tickers)} tickers")
    return results


_YF_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept": "application/json",
}


@_mem_cached(ttl_seconds=3600)
def get_analyst_data(ticker: str) -> dict:
    """
    Pull full analyst consensus data:
      - Price targets via yfinance analyst_price_targets
      - Recommendation breakdown via Yahoo Finance quoteSummary API
        (recommendationTrend gives the full 30-40 analyst count, not just the monthly snapshot)
      - Recent upgrades / downgrades via yfinance upgrades_downgrades
    """
    empty = {
        "target_mean": None, "target_high": None, "target_low": None,
        "upside_pct": None,
        "strong_buy": 0, "buy": 0, "hold": 0, "sell": 0, "strong_sell": 0,
        "total_analysts": 0, "consensus": "—",
        "recent_upgrades": 0, "recent_downgrades": 0,
        "latest_actions": [],
        "trend_history": [],   # last 4 months of analyst counts
        "rev_current_q_up7": 0, "rev_current_q_up30": 0,
        "rev_current_q_down7": 0, "rev_current_q_down30": 0,
        "rev_next_q_up7": 0, "rev_next_q_up30": 0,
        "rev_next_q_down7": 0, "rev_next_q_down30": 0,
        "eps_trend": {}, "earnings_estimate": {},
        "revenue_estimate": {}, "growth_estimates": {},
    }
    try:
        t = yf.Ticker(ticker)

        # ── Price targets ──────────────────────────────────────────────────────
        try:
            pt = t.analyst_price_targets
            if pt and isinstance(pt, dict):
                mean   = pt.get("mean")
                high   = pt.get("high")
                low    = pt.get("low")
                curr   = pt.get("current")
                upside = round((mean - curr) / curr * 100, 1) if mean and curr else None
                empty.update({"target_mean": mean, "target_high": high,
                              "target_low": low, "upside_pct": upside})
        except Exception:
            pass

        # ── Analyst recommendation counts (full — via quoteSummary API) ────────
        # Yahoo Finance's recommendationTrend returns the complete count of analysts
        # covering the stock (typically 25-45 for S&P 500 names), whereas
        # recommendations_summary only returns who rated in the latest month (5-12).
        try:
            url = (f"https://query2.finance.yahoo.com/v10/finance/quoteSummary/{ticker}"
                   f"?modules=recommendationTrend,financialData")
            resp = requests.get(url, headers=_YF_HEADERS, timeout=10)
            resp.raise_for_status()
            result = resp.json().get("quoteSummary", {}).get("result", [{}])[0]

            # recommendationTrend: periods "0m" (current), "-1m", "-2m", "-3m"
            trend_data = result.get("recommendationTrend", {}).get("trend", [])
            if trend_data:
                # Use the current period ("0m") for the main breakdown
                cur = trend_data[0]
                sb = int(cur.get("strongBuy",  0))
                b  = int(cur.get("buy",        0))
                h  = int(cur.get("hold",       0))
                s  = int(cur.get("sell",       0))
                ss = int(cur.get("strongSell", 0))
                total = sb + b + h + s + ss

                # If current period is thin, sum all periods for totals
                if total < 5 and len(trend_data) > 1:
                    for period in trend_data[1:]:
                        sb = max(sb, int(period.get("strongBuy",  0)))
                        b  = max(b,  int(period.get("buy",        0)))
                        h  = max(h,  int(period.get("hold",       0)))
                        s  = max(s,  int(period.get("sell",       0)))
                        ss = max(ss, int(period.get("strongSell", 0)))
                    total = sb + b + h + s + ss

                # Weighted score: SB=2, B=1, H=0, S=-1, SS=-2
                w = (sb*2 + b - s - ss*2) / total if total else 0
                if   w >= 1.5: consensus = "Strong Buy"
                elif w >= 0.5: consensus = "Buy"
                elif w >= -0.5:consensus = "Hold"
                elif w >= -1.5:consensus = "Sell"
                else:          consensus = "Strong Sell"

                empty.update({"strong_buy": sb, "buy": b, "hold": h,
                              "sell": s, "strong_sell": ss,
                              "total_analysts": total, "consensus": consensus})

                # Historical trend (last 4 months)
                empty["trend_history"] = [
                    {"period": p.get("period",""), "strongBuy": p.get("strongBuy",0),
                     "buy": p.get("buy",0), "hold": p.get("hold",0),
                     "sell": p.get("sell",0), "strongSell": p.get("strongSell",0)}
                    for p in trend_data[:4]
                ]

            # Fallback: use info.numberOfAnalystOpinions if quoteSummary total looks low
            fin = result.get("financialData", {})
            info_total = t.fast_info.analyst_price_target_count if hasattr(t, "fast_info") else 0
            if empty["total_analysts"] < 5:
                try:
                    info = t.info
                    n = info.get("numberOfAnalystOpinions", 0) or 0
                    if n > empty["total_analysts"]:
                        empty["total_analysts"] = n
                        rec_mean = info.get("recommendationMean", 3)
                        if   rec_mean <= 1.5: empty["consensus"] = "Strong Buy"
                        elif rec_mean <= 2.5: empty["consensus"] = "Buy"
                        elif rec_mean <= 3.5: empty["consensus"] = "Hold"
                        elif rec_mean <= 4.5: empty["consensus"] = "Sell"
                        else:                 empty["consensus"] = "Strong Sell"
                except Exception:
                    pass

        except Exception:
            # Hard fallback to yfinance recommendations_summary
            try:
                rec = t.recommendations_summary
                if rec is not None and not rec.empty:
                    row = rec.iloc[0]
                    sb = int(row.get("strongBuy",  0))
                    b  = int(row.get("buy",        0))
                    h  = int(row.get("hold",       0))
                    s  = int(row.get("sell",       0))
                    ss = int(row.get("strongSell", 0))
                    total = sb + b + h + s + ss
                    w = (sb*2 + b - s - ss*2) / total if total else 0
                    consensus = ("Strong Buy" if w >= 1.5 else "Buy" if w >= 0.5
                                 else "Hold" if w >= -0.5 else "Sell" if w >= -1.5 else "Strong Sell")
                    empty.update({"strong_buy": sb, "buy": b, "hold": h,
                                  "sell": s, "strong_sell": ss,
                                  "total_analysts": total, "consensus": consensus})
            except Exception:
                pass

        # ── Recent upgrades / downgrades ───────────────────────────────────────
        try:
            ud = t.upgrades_downgrades
            if ud is not None and not ud.empty:
                ud = ud.reset_index()
                cutoff = pd.Timestamp.now(tz="UTC") - pd.Timedelta(days=60)
                if "GradeDate" in ud.columns:
                    ud["GradeDate"] = pd.to_datetime(ud["GradeDate"], utc=True)
                    recent = ud[ud["GradeDate"] >= cutoff].head(20)
                else:
                    recent = ud.head(20)

                ups  = recent[recent.get("Action", pd.Series(dtype=str)).str.lower().isin(["up","init","reit"])] \
                       if "Action" in recent.columns else pd.DataFrame()
                dens = recent[recent.get("Action", pd.Series(dtype=str)).str.lower() == "down"] \
                       if "Action" in recent.columns else pd.DataFrame()

                latest = [
                    {"firm": r.get("Firm", ""), "to": r.get("ToGrade", ""),
                     "from": r.get("FromGrade", ""), "action": r.get("Action", ""),
                     "date": str(r.get("GradeDate", ""))[:10]}
                    for r in recent.head(6).to_dict("records")
                    if r.get("Firm") and r.get("ToGrade")
                ]

                empty["recent_upgrades"]   = len(ups)
                empty["recent_downgrades"] = len(dens)
                empty["latest_actions"]    = latest
        except Exception:
            pass

        # ── EPS Revisions (7d/30d up/down counts) ─────────────────────────
        try:
            eps_rev = t.get_eps_revisions()
            if eps_rev is not None and not eps_rev.empty:
                for period_key in ['0q', '+1q']:
                    if period_key in eps_rev.index:
                        row = eps_rev.loc[period_key]
                        prefix = 'current_q' if period_key == '0q' else 'next_q'
                        empty[f'rev_{prefix}_up7'] = int(row.get('upLast7days', 0) or 0)
                        empty[f'rev_{prefix}_up30'] = int(row.get('upLast30days', 0) or 0)
                        empty[f'rev_{prefix}_down7'] = int(row.get('downLast7days', 0) or 0)
                        empty[f'rev_{prefix}_down30'] = int(row.get('downLast30days', 0) or 0)
        except Exception:
            pass

        # ── EPS Trend (consensus at 7/30/60/90 days ago) ──────────────────
        try:
            eps_trend = t.get_eps_trend()
            if eps_trend is not None and not eps_trend.empty:
                trend_dict = {}
                for period_key in ['0q', '+1q']:
                    if period_key in eps_trend.index:
                        row = eps_trend.loc[period_key]
                        prefix = 'current_q' if period_key == '0q' else 'next_q'
                        trend_dict[f'{prefix}_current'] = float(row.get('current', 0) or 0)
                        trend_dict[f'{prefix}_7d'] = float(row.get('7daysAgo', 0) or 0)
                        trend_dict[f'{prefix}_30d'] = float(row.get('30daysAgo', 0) or 0)
                        trend_dict[f'{prefix}_60d'] = float(row.get('60daysAgo', 0) or 0)
                        trend_dict[f'{prefix}_90d'] = float(row.get('90daysAgo', 0) or 0)
                empty['eps_trend'] = trend_dict
        except Exception:
            pass

        # ── Earnings Estimate (forward EPS consensus) ─────────────────────
        try:
            ee = t.get_earnings_estimate()
            if ee is not None and not ee.empty:
                est = {}
                for period_key in ['0q', '+1q', '0y', '+1y']:
                    if period_key in ee.index:
                        row = ee.loc[period_key]
                        est[period_key] = {
                            'avg': float(row.get('avg', 0) or 0),
                            'low': float(row.get('low', 0) or 0),
                            'high': float(row.get('high', 0) or 0),
                            'num_analysts': int(row.get('numberOfAnalysts', 0) or 0),
                            'year_ago': float(row.get('yearAgoEps', 0) or 0),
                            'growth': float(row.get('growth', 0) or 0),
                        }
                empty['earnings_estimate'] = est
        except Exception:
            pass

        # ── Revenue Estimate ──────────────────────────────────────────────
        try:
            re_est = t.get_revenue_estimate()
            if re_est is not None and not re_est.empty:
                rev = {}
                for period_key in ['0q', '+1q', '0y', '+1y']:
                    if period_key in re_est.index:
                        row = re_est.loc[period_key]
                        rev[period_key] = {
                            'avg': float(row.get('avg', 0) or 0),
                            'low': float(row.get('low', 0) or 0),
                            'high': float(row.get('high', 0) or 0),
                            'num_analysts': int(row.get('numberOfAnalysts', 0) or 0),
                            'year_ago': float(row.get('yearAgoRevenue', 0) or 0),
                            'growth': float(row.get('growth', 0) or 0),
                        }
                empty['revenue_estimate'] = rev
        except Exception:
            pass

        # ── Growth Estimates vs industry/sector ───────────────────────────
        try:
            ge = t.get_growth_estimates()
            if ge is not None and not ge.empty:
                growth = {}
                for col in ge.columns:
                    col_data = {}
                    for idx in ge.index:
                        val = ge.loc[idx, col]
                        if val is not None and str(val) != 'nan':
                            col_data[str(idx)] = float(val) if isinstance(val, (int, float)) else str(val)
                    growth[str(col)] = col_data
                empty['growth_estimates'] = growth
        except Exception:
            pass

        return empty
    except Exception:
        return empty


@_mem_cached(ttl_seconds=1800)
def get_stocktwits_data(ticker: str) -> dict:
    """
    Pull social sentiment from StockTwits public API (no auth required).
    Returns bullish/bearish ratio, message volume, recent posts.
    """
    empty = {
        "bullish": 0, "bearish": 0, "neutral": 0,
        "bull_pct": 50, "message_volume": 0,
        "watchlist_count": 0, "trending": False,
        "messages": [], "error": None,
    }
    try:
        url = f"https://api.stocktwits.com/api/2/streams/symbol/{ticker}.json"
        resp = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        if resp.status_code == 404:
            empty["error"] = "symbol not found on StockTwits"
            return empty
        resp.raise_for_status()
        data = resp.json()

        messages = data.get("messages", [])
        bull = 0; bear = 0; neutral = 0
        recent = []
        for m in messages:
            sent_obj = (m.get("entities") or {}).get("sentiment") or {}
            sent = sent_obj.get("basic", "")
            if sent == "Bullish":   bull += 1
            elif sent == "Bearish": bear += 1
            else:                   neutral += 1
            if len(recent) < 8:
                recent.append({
                    "body":      (m.get("body") or "")[:180],
                    "user":      (m.get("user") or {}).get("username", "anon"),
                    "sentiment": sent,
                    "time":      (m.get("created_at") or "")[:16].replace("T", " "),
                })

        total_sentiment = bull + bear
        sym = data.get("symbol") or {}
        wcount = sym.get("watchlist_count", 0) or 0

        return {
            "bullish":        bull,
            "bearish":        bear,
            "neutral":        neutral,
            "bull_pct":       round(bull / total_sentiment * 100) if total_sentiment else 50,
            "message_volume": len(messages),
            "watchlist_count": wcount,
            "trending":       wcount > 50_000,
            "messages":       recent,
            "error":          None,
        }
    except Exception as e:
        empty["error"] = str(e)
        return empty


# ── VIX / Market Fear ────────────────────────────────────────────────────────

def get_vix_data() -> dict:
    """
    Fetch VIX (CBOE Volatility Index) level and trend.
    Returns: vix_current, vix_ma20, trend (rising/falling/stable),
             regime (fear/elevated/normal/complacency), spike_recovery.
    """
    empty = {"vix_current": None, "vix_ma20": None, "trend": "stable",
             "regime": "normal", "spike_recovery": False, "error": None}
    try:
        # Polygon primary: I:VIX index (90 days of daily bars)
        _vix_df = get_polygon_ohlcv("I:VIX", days=90, timespan="day")
        if _vix_df is None or len(_vix_df) < 10:
            # yfinance fallback
            _vix_yf = yf.download("^VIX", period="3mo", interval="1d",
                                   progress=False, auto_adjust=True)
            if _vix_yf.empty or len(_vix_yf) < 10:
                empty["error"] = "No VIX data"
                return empty
            close = _vix_yf["Close"].squeeze()
        else:
            close = _vix_df["Close"]
        current = float(close.iloc[-1])
        ma20 = float(close.rolling(20).mean().iloc[-1]) if len(close) >= 20 else current
        peak_20d = float(close.rolling(20).max().iloc[-1]) if len(close) >= 20 else current

        # Trend: compare last 5 days
        trend_val = float(close.iloc[-1]) - float(close.iloc[-5]) if len(close) >= 5 else 0
        trend = "rising" if trend_val > 1.5 else "falling" if trend_val < -1.5 else "stable"

        # Spike recovery: VIX was elevated but is now declining sharply
        spike_recovery = (peak_20d > 30 and current < peak_20d * 0.80 and trend == "falling")

        if current > 30:
            regime = "fear"
        elif current > 20:
            regime = "elevated"
        elif current < 15:
            regime = "complacency"
        else:
            regime = "normal"

        return {
            "vix_current":   round(current, 1),
            "vix_ma20":      round(ma20, 1),
            "peak_20d":      round(peak_20d, 1),
            "trend":         trend,
            "regime":        regime,
            "spike_recovery": spike_recovery,
            "error":         None,
        }
    except Exception as e:
        empty["error"] = str(e)
        return empty


# ── Sector ETF Rotation ───────────────────────────────────────────────────────

_SECTOR_ETFS = {
    "XLK":  "Technology",
    "XLF":  "Financials",
    "XLV":  "Healthcare",
    "XLE":  "Energy",
    "XLI":  "Industrials",
    "XLB":  "Materials",
    "XLRE": "Real Estate",
    "XLU":  "Utilities",
    "XLC":  "Communication Svcs",
    "XLP":  "Consumer Staples",
    "XLY":  "Consumer Disc.",
}

# US market-wide indices tracked alongside sector ETFs
_US_INDICES = {
    "QQQ": "Nasdaq 100",
    "DIA": "Dow Jones",
    "IWM": "Russell 2000",
    "MDY": "S&P MidCap",
    "TLT": "Long Treasury",
    "HYG": "High Yield",
    "GLD": "Gold",
    "UUP": "US Dollar",
}

_TICKER_TO_SECTOR = {
    # Technology
    "NVDA": "XLK", "MSFT": "XLK", "AAPL": "XLK", "AMD": "XLK", "INTC": "XLK",
    "AVGO": "XLK", "QCOM": "XLK", "MU": "XLK", "AMAT": "XLK", "KLAC": "XLK",
    "CRWD": "XLK", "PANW": "XLK", "ZS": "XLK", "NET": "XLK",
    # Healthcare
    "LLY": "XLV", "NVO": "XLV", "ABBV": "XLV", "BMY": "XLV", "MRK": "XLV",
    "AMGN": "XLV", "PFE": "XLV", "JNJ": "XLV", "MDT": "XLV", "UNH": "XLV",
    # Financials
    "JPM": "XLF", "BAC": "XLF", "WFC": "XLF", "GS": "XLF", "MS": "XLF",
    "BLK": "XLF", "V": "XLF", "MA": "XLF", "AXP": "XLF",
    # Communication Services
    "META": "XLC", "GOOGL": "XLC", "GOOG": "XLC", "NFLX": "XLC", "DIS": "XLC",
    "CMCSA": "XLC", "T": "XLC", "VZ": "XLC", "SNAP": "XLC", "PINS": "XLC",
    # Consumer Discretionary
    "AMZN": "XLY", "TSLA": "XLY", "HD": "XLY", "MCD": "XLY", "NKE": "XLY",
    "DECK": "XLY", "ONON": "XLY", "CMG": "XLY",
    # Energy
    "XOM": "XLE", "CVX": "XLE", "COP": "XLE", "EOG": "XLE", "SLB": "XLE",
    # Industrials
    "AXON": "XLI", "RTX": "XLI", "LMT": "XLI", "NOC": "XLI", "GD": "XLI",
    "CAT": "XLI", "DE": "XLI", "UNP": "XLI",
    # Materials
    "NEM": "XLB", "FCX": "XLB", "NUE": "XLB",
    # Real Estate
    "AMT": "XLRE", "PLD": "XLRE", "EQIX": "XLRE",
}


def get_sector_etf_data(lookback_days: int = 63) -> dict:
    """
    Fetch performance of all 11 sector ETFs vs SPY over `lookback_days`.
    Results are cached to disk for 1 hour to avoid redundant downloads.
    Returns dict: etf → {sector, perf_pct, vs_spy_pct, outperforming, rank}
    """
    _CACHE_KEY = f"sector_etf_{lookback_days}"
    cached = _cache_read(_CACHE_KEY, ttl_seconds=3600)
    if cached:
        log.debug("Sector ETF data: cache hit")
        return cached

    all_symbols = list(_SECTOR_ETFS.keys()) + list(_US_INDICES.keys()) + ["SPY", "SMH", "USO", "BTC-USD", "COPX"]
    try:
        raw = yf.download(all_symbols, period="1y", interval="1d",
                           progress=False, threads=False, auto_adjust=True)
        if raw.empty:
            return {}

        closes = raw["Close"] if isinstance(raw.columns, pd.MultiIndex) else raw
        n = min(lookback_days, len(closes) - 1)

        spy_perf = None
        results  = {}
        # ── Sector ETFs ────────────────────────────────────────────────
        for etf in list(_SECTOR_ETFS.keys()) + ["SPY"]:
            try:
                if etf not in closes.columns:
                    continue
                col = closes[etf].dropna()
                if len(col) < n + 1:
                    continue
                perf = (float(col.iloc[-1]) / float(col.iloc[-(n+1)]) - 1) * 100
                if etf == "SPY":
                    spy_perf = perf
                else:
                    results[etf] = {
                        "sector":   _SECTOR_ETFS.get(etf, etf),
                        "perf_pct": round(perf, 2),
                        "price":    round(float(col.iloc[-1]), 2),
                    }
            except Exception:
                pass

        if spy_perf is not None:
            perfs = []
            for etf, d in results.items():
                d["vs_spy_pct"]    = round(d["perf_pct"] - spy_perf, 2)
                d["outperforming"] = d["vs_spy_pct"] > 0
                perfs.append((etf, d["vs_spy_pct"]))
            perfs.sort(key=lambda x: x[1], reverse=True)
            for rank, (etf, _) in enumerate(perfs, 1):
                results[etf]["rank"] = rank

        results["SPY"] = {"sector": "S&P 500", "perf_pct": round(spy_perf or 0, 2),
                          "vs_spy_pct": 0.0, "outperforming": False, "rank": 0,
                          "price": round(float(closes["SPY"].dropna().iloc[-1]), 2) if "SPY" in closes.columns else 0}

        # ── US market indices ──────────────────────────────────────────
        indices: dict = {}
        for sym, label in _US_INDICES.items():
            try:
                if sym not in closes.columns:
                    continue
                col = closes[sym].dropna()
                if len(col) < n + 1:
                    continue
                perf  = (float(col.iloc[-1]) / float(col.iloc[-(n+1)]) - 1) * 100
                price = round(float(col.iloc[-1]), 2)
                vs    = round(perf - (spy_perf or 0), 2)
                indices[sym] = {
                    "label":         label,
                    "perf_pct":      round(perf, 2),
                    "vs_spy_pct":    vs,
                    "outperforming": vs > 0,
                    "price":         price,
                }
            except Exception:
                pass
        results["_indices"] = indices

        # ── EMA / SMA regime for key indices ──────────────────────────
        regime_syms = ["SPY", "QQQ", "DIA", "IWM", "SMH"]
        idx_regime = {}
        for sym in regime_syms:
            try:
                if sym not in closes.columns:
                    continue
                col = closes[sym].dropna()
                if len(col) < 200:
                    continue
                price = float(col.iloc[-1])
                ema21  = float(col.ewm(span=21, adjust=False).mean().iloc[-1])
                ema50  = float(col.ewm(span=50, adjust=False).mean().iloc[-1])
                sma200 = float(col.rolling(200).mean().iloc[-1])
                a21 = price > ema21
                a50 = price > ema50
                a200 = price > sma200
                bulls = sum([a21, a50, a200])
                trend = "BULL" if bulls == 3 else "BEAR" if bulls == 0 else "MIXED"
                ret_1m = round((price / float(col.iloc[-21]) - 1) * 100, 1) if len(col) >= 21 else 0
                ret_5d = round((price / float(col.iloc[-5]) - 1) * 100, 1) if len(col) >= 5 else 0
                idx_regime[sym] = {
                    "price": round(price, 2), "ema21": round(ema21, 2),
                    "ema50": round(ema50, 2), "sma200": round(sma200, 2),
                    "above_ema21": a21, "above_ema50": a50, "above_sma200": a200,
                    "trend": trend, "ret_1m": ret_1m, "ret_5d": ret_5d,
                }
            except Exception:
                pass
        results["_idx_regime"] = idx_regime

        # ── Extended macro: USO, BTC-USD, COPX, SMH ─────────────────
        ext_macro = {}
        for sym, key in [("USO", "uso"), ("BTC-USD", "btc"), ("COPX", "copx"), ("SMH", "smh")]:
            try:
                if sym not in closes.columns:
                    continue
                col = closes[sym].dropna()
                if len(col) < 20:
                    continue
                cur  = float(col.iloc[-1])
                ma20 = float(col.rolling(20).mean().iloc[-1])
                chg5 = round((cur / float(col.iloc[-5]) - 1) * 100, 1) if len(col) >= 5 else 0
                chg20 = round((cur / float(col.iloc[-20]) - 1) * 100, 1) if len(col) >= 20 else 0
                trend = "rising" if chg5 > 0.5 else "falling" if chg5 < -0.5 else "flat"
                ext_macro[key] = {"price": round(cur, 2), "ma20": round(ma20, 2),
                                  "chg5d": chg5, "chg20d": chg20, "trend": trend}
            except Exception:
                pass
        results["_ext_macro"] = ext_macro

        # ── Intermarket correlations (60-day) ────────────────────────
        intermarket = {}
        corr_pairs = [("SPY", "TLT", "Stock-Bond"), ("SPY", "UUP", "Equity-Dollar"),
                      ("SPY", "GLD", "Equity-Gold"), ("HYG", "SPY", "Credit-Equity")]
        for t1, t2, label in corr_pairs:
            try:
                if t1 not in closes.columns or t2 not in closes.columns:
                    continue
                r1 = closes[t1].dropna().pct_change().tail(60).dropna()
                r2 = closes[t2].dropna().pct_change().tail(60).dropna()
                combined = pd.concat([r1, r2], axis=1).dropna()
                if len(combined) < 30:
                    continue
                corr_val = float(combined.iloc[:, 0].corr(combined.iloc[:, 1]))
                intermarket[label] = {"t1": t1, "t2": t2, "corr": round(corr_val, 2)}
            except Exception:
                pass
        results["_intermarket"] = intermarket

        _cache_write(_CACHE_KEY, results)
        return results
    except Exception as e:
        log.warning(f"Sector ETF fetch failed: {e}")
        return {}


# ── Options IV Rank ───────────────────────────────────────────────────────────

@_mem_cached(ttl_seconds=1800)
def get_options_iv_data(ticker: str) -> dict:
    """
    Compute IV Rank and Put/Call ratio for a ticker using yfinance options chain.
    IV Rank = (current_IV - min_IV_52w) / (max_IV_52w - min_IV_52w) * 100

    Returns: iv_current, iv_rank, iv_pct_label, pc_ratio, uoa (unusual options activity flag).
    """
    empty = {"iv_current": None, "iv_rank": None, "iv_pct_label": "N/A",
             "pc_ratio": None, "uoa": False, "gamma_wall": None,
             "expiry_used": None, "error": None}
    try:
        t = yf.Ticker(ticker)
        exps = t.options
        if not exps:
            empty["error"] = "No options chain"
            return empty

        # Use the nearest expiry with enough OI (typically 2-6 weeks out)
        target_exp = None
        for exp in exps:
            days_out = (pd.Timestamp(exp) - pd.Timestamp.now()).days
            if 10 <= days_out <= 60:
                target_exp = exp
                break
        if not target_exp:
            target_exp = exps[0]

        chain = t.option_chain(target_exp)
        calls = chain.calls
        puts  = chain.puts

        # ATM strike
        price = float(t.fast_info.last_price or 0)
        if price <= 0 or calls.empty:
            empty["error"] = "No price or empty chain"
            return empty

        calls["moneyness"] = (calls["strike"] - price).abs()
        atm_idx = calls["moneyness"].idxmin()
        atm_iv  = float(calls.loc[atm_idx, "impliedVolatility"]) if atm_idx in calls.index else None

        # Put/Call ratio by volume
        total_call_vol = calls["volume"].fillna(0).sum()
        total_put_vol  = puts["volume"].fillna(0).sum()
        pc_ratio = round(total_put_vol / max(total_call_vol, 1), 2)

        # Unusual Options Activity: any single contract with volume > 3× open interest
        uoa = False
        for df in (calls, puts):
            if "volume" in df.columns and "openInterest" in df.columns:
                vol   = df["volume"].fillna(0)
                oi    = df["openInterest"].fillna(1)
                ratio = vol / oi.replace(0, 1)
                if (ratio > 3).any() and (vol > 500).any():
                    uoa = True
                    break

        # IV Rank — approximate using 52-week historical volatility from daily returns
        # Polygon primary, yfinance fallback
        _hist_df = get_polygon_ohlcv(ticker, days=365, timespan="day")
        if _hist_df is not None and len(_hist_df) >= 60:
            hist = _hist_df
        else:
            hist = yf.download(ticker, period="1y", interval="1d", progress=False, auto_adjust=True)
        iv_rank = None
        if not (hist is None or (hasattr(hist, 'empty') and hist.empty) or len(hist) < 60):
            ret = hist["Close"].squeeze().pct_change().dropna()
            # Rolling 30-day realized vol as a proxy for historical IV
            rv = ret.rolling(30).std() * (252 ** 0.5)
            rv_clean = rv.dropna()
            if len(rv_clean) >= 20:
                rv_min = float(rv_clean.min())
                rv_max = float(rv_clean.max())
                rv_cur = float(rv_clean.iloc[-1])
                iv_rank = round((rv_cur - rv_min) / max(rv_max - rv_min, 0.001) * 100, 0)

        if iv_rank is not None:
            if iv_rank < 30:    label = "Low (cheap options)"
            elif iv_rank < 70:  label = "Normal"
            else:               label = "High (expensive options)"
        else:
            label = "N/A"

        # Gamma wall: strike with highest combined open interest (calls + puts)
        gamma_wall = None
        try:
            c_oi = calls[["strike", "openInterest"]].dropna()
            p_oi = puts[["strike", "openInterest"]].dropna()
            combined = pd.concat([c_oi, p_oi]).groupby("strike")["openInterest"].sum()
            if not combined.empty:
                gamma_wall = float(combined.idxmax())
        except Exception:
            pass

        return {
            "iv_current":   round(atm_iv * 100, 1) if atm_iv else None,
            "iv_rank":      int(iv_rank) if iv_rank is not None else None,
            "iv_pct_label": label,
            "pc_ratio":     pc_ratio,
            "uoa":          uoa,
            "gamma_wall":   gamma_wall,
            "expiry_used":  target_exp,
            "error":        None,
        }
    except Exception as e:
        empty["error"] = str(e)
        return empty


# ── Macro Signals (HYG, DXY proxy, GLD) ──────────────────────────────────────

def get_macro_signals() -> dict:
    """
    Download HYG (credit spreads proxy), UUP (USD/DXY proxy), GLD (safe haven).
    Results cached to disk for 1 hour — macro signals don't change intra-hour.
    Returns current price, 20d MA, 5d change, trend, and composite risk signal.
    """
    cached = _cache_read("macro_signals", ttl_seconds=3600)
    if cached:
        log.debug("Macro signals: cache hit")
        return cached

    empty = {"hyg": {}, "dxy": {}, "gld": {}, "risk_signal": "neutral", "error": None}
    try:
        macro_tickers = ["HYG", "UUP", "GLD"]
        result = {}
        for t in macro_tickers:
            try:
                # Polygon primary (90 days of daily bars)
                df = get_polygon_ohlcv(t, days=90, timespan="day")
                if df is None or len(df) < 10:
                    # yfinance fallback
                    _yf_raw = yf.download(t, period="3mo", interval="1d", progress=False, auto_adjust=True)
                    if _yf_raw.empty:
                        result[t] = {}
                        continue
                    close = _yf_raw["Close"].squeeze()
                else:
                    close = df["Close"]
                cur   = float(close.iloc[-1])
                ma20  = float(close.rolling(20).mean().iloc[-1]) if len(close) >= 20 else cur
                chg5  = (cur - float(close.iloc[-5])) / float(close.iloc[-5]) * 100 if len(close) >= 5 else 0
                chg20 = (cur - float(close.iloc[-20])) / float(close.iloc[-20]) * 100 if len(close) >= 20 else 0
                trend = "rising" if chg5 > 0.5 else "falling" if chg5 < -0.5 else "flat"
                result[t] = {"price": round(cur, 2), "ma20": round(ma20, 2),
                             "chg5d": round(chg5, 2), "chg20d": round(chg20, 2), "trend": trend}
            except Exception as e:
                result[t] = {"error": str(e)}

        # Composite risk signal: HYG falling + UUP rising = risk-off (credit stress + dollar flight)
        hyg_trend = result.get("HYG", {}).get("trend", "flat")
        uup_trend = result.get("UUP", {}).get("trend", "flat")
        if hyg_trend == "falling" and uup_trend == "rising":
            risk_signal = "risk-off"
        elif hyg_trend == "rising" and uup_trend == "falling":
            risk_signal = "risk-on"
        else:
            risk_signal = "neutral"

        # FRED 10Y-2Y yield curve
        yield_curve = {}
        try:
            import io as _io
            yc_resp = requests.get(
                "https://fred.stlouisfed.org/graph/fredgraph.csv?id=T10Y2Y",
                timeout=8, headers={"User-Agent": "SwingTrade/1.0"})
            if yc_resp.status_code == 200:
                yc_df = pd.read_csv(_io.StringIO(yc_resp.text), parse_dates=["observation_date"])
                yc_df = yc_df.dropna()
                if len(yc_df) >= 2:
                    spread = float(yc_df["T10Y2Y"].iloc[-1])
                    spread_30d_ago = float(yc_df["T10Y2Y"].iloc[-min(22, len(yc_df)-1)])
                    trend = "steepening" if spread > spread_30d_ago + 0.05 else \
                            "flattening" if spread < spread_30d_ago - 0.05 else "stable"
                    yield_curve = {"spread": round(spread, 3), "inverted": spread < 0, "trend": trend}
        except Exception as _ye:
            log.debug(f"FRED yield curve: {_ye}")

        # CBOE equity put/call ratio
        put_call = {}
        try:
            pc_resp = requests.get(
                "https://www.cboe.com/us/options/market_statistics/daily/",
                timeout=8, headers={"User-Agent": "Mozilla/5.0"})
            if pc_resp.status_code == 200:
                from bs4 import BeautifulSoup as _BS
                soup = _BS(pc_resp.text, "html.parser")
                # Look for the equity P/C ratio in the stats table
                for row in soup.find_all("tr"):
                    cells = [td.get_text(strip=True) for td in row.find_all("td")]
                    if len(cells) >= 2 and "equity" in cells[0].lower():
                        try:
                            pc_val = float(cells[1])
                            signal = ("extreme_fear" if pc_val > 1.2 else
                                      "fear" if pc_val > 0.9 else
                                      "greed" if pc_val < 0.6 else "neutral")
                            put_call = {"equity_pc": pc_val, "signal": signal}
                            break
                        except ValueError:
                            pass
        except Exception as _pe:
            log.debug(f"CBOE P/C: {_pe}")

        out = {"hyg": result.get("HYG", {}), "dxy": result.get("UUP", {}),
               "gld": result.get("GLD", {}), "risk_signal": risk_signal,
               "yield_curve": yield_curve, "put_call": put_call, "error": None}
        _cache_write("macro_signals", out)
        return out
    except Exception as e:
        empty["error"] = str(e)
        return empty


# ── Market Breadth ────────────────────────────────────────────────────────────

def get_market_breadth(market_data: dict) -> dict:
    """
    Compute breadth from already-downloaded daily OHLCV: % of tickers above
    50d SMA and 100d SMA. No extra download needed.
    """
    above_50 = above_100 = above_200 = total = 0
    new_highs = new_lows = 0
    for df in market_data.values():
        try:
            close = df["Close"].squeeze() if isinstance(df["Close"], pd.DataFrame) else df["Close"]
            close = close.dropna()
            if close.empty:
                continue
            price = float(close.iloc[-1])
            n = len(close)
            total += 1
            if n >= 50:
                above_50  += 1 if price > float(close.rolling(50).mean().iloc[-1])  else 0
            if n >= 100:
                above_100 += 1 if price > float(close.rolling(100).mean().iloc[-1]) else 0
            if n >= 200:
                above_200 += 1 if price > float(close.rolling(200).mean().iloc[-1]) else 0
            # 52-week highs/lows (use available data, up to 252 trading days)
            lookback = min(n, 252)
            hi = float(close.iloc[-lookback:].max())
            lo = float(close.iloc[-lookback:].min())
            if price >= hi * 0.98:  # within 2% of 52w high
                new_highs += 1
            if price <= lo * 1.02:  # within 2% of 52w low
                new_lows += 1
        except Exception:
            pass

    pct_50  = round(above_50  / total * 100, 1) if total else 0
    pct_100 = round(above_100 / total * 100, 1) if total else 0
    pct_200 = round(above_200 / total * 100, 1) if total else 0
    hl_ratio = round(new_highs / max(new_lows, 1), 2)

    def _label(pct):
        if pct >= 70: return "strong"
        if pct >= 50: return "moderate"
        if pct >= 30: return "weak"
        if pct >= 25: return "very_weak"
        return "critical"

    return {
        "total":          total,
        "above_50d":      above_50,  "pct_above_50d":  pct_50,  "label_50":  _label(pct_50),
        "above_100d":     above_100, "pct_above_100d": pct_100, "label_100": _label(pct_100),
        "above_200d":     above_200, "pct_above_200d": pct_200, "label_200": _label(pct_200),
        "new_highs":      new_highs, "new_lows": new_lows, "hl_ratio": hl_ratio,
    }


# ── Extra Fundamentals (EV/EBITDA, P/FCF, revisions, institutional, buyback) ─

@_mem_cached(ttl_seconds=3600)
def get_extra_fundamentals(ticker: str) -> dict:
    """
    Supplementary fundamental signals not in get_stock_info():
    EV/EBITDA, P/FCF, estimate revisions (fwd vs trailing EPS),
    institutional ownership %, annual buyback yield.
    """
    empty = {"ev_ebitda": None, "p_fcf": None, "institutional_pct": None,
             "buyback_annual": None, "buyback_yield": None,
             "estimate_revision": None, "error": None}
    try:
        t  = yf.Ticker(ticker)
        info = t.info or {}

        ev_ebitda = info.get("enterpriseToEbitda")

        fcf  = info.get("freeCashflow")
        mcap = info.get("marketCap")
        p_fcf = round(mcap / fcf, 1) if fcf and fcf > 0 and mcap else None

        inst_pct_raw = info.get("institutionsPercentHeld")
        inst_pct = round(inst_pct_raw * 100, 1) if inst_pct_raw else None

        # Buyback cadence from annual cashflow statement
        buyback_annual = buyback_yield = None
        try:
            cf = t.cashflow
            if cf is not None and not (isinstance(cf, pd.DataFrame) and cf.empty):
                for row_name in ("Repurchase Of Capital Stock", "Common Stock Repurchased",
                                 "RepurchaseOfCapitalStock"):
                    if row_name in cf.index:
                        vals = cf.loc[row_name].dropna().values
                        if len(vals) > 0:
                            buyback_annual = abs(float(vals[0]))
                            if mcap and mcap > 0:
                                buyback_yield = round(buyback_annual / mcap * 100, 2)
                            break
        except Exception:
            pass

        # Estimate revision: forward EPS direction vs trailing EPS
        estimate_revision = None
        fwd  = info.get("forwardEps")
        trail = info.get("trailingEps")
        if fwd and trail and trail != 0:
            rev_pct = (fwd - trail) / abs(trail) * 100
            if   rev_pct > 15:  estimate_revision = "up_strong"
            elif rev_pct > 2:   estimate_revision = "up"
            elif rev_pct > -5:  estimate_revision = "flat"
            else:               estimate_revision = "down"

        return {"ev_ebitda": round(ev_ebitda, 1) if ev_ebitda else None,
                "p_fcf": p_fcf, "institutional_pct": inst_pct,
                "buyback_annual": buyback_annual, "buyback_yield": buyback_yield,
                "estimate_revision": estimate_revision, "error": None}
    except Exception as e:
        empty["error"] = str(e)
        return empty


# ── Weekly OHLCV ──────────────────────────────────────────────────────────────

def get_weekly_data(tickers: list[str], period: str = "1y",
                    cache_dir: "Path | None" = None,
                    cache_ttl_days: int = 1) -> dict[str, pd.DataFrame]:
    """
    Fetch weekly OHLCV bars for a list of tickers (yfinance interval='1wk').
    Caches results to disk (cache_dir/weekly/) with a TTL of cache_ttl_days.
    Returns dict: ticker → weekly DataFrame (Open/High/Low/Close/Volume).
    """
    if not tickers:
        return {}

    import datetime as _dt
    result: dict[str, pd.DataFrame] = {}
    to_fetch: list[str] = []
    now = _dt.datetime.utcnow()

    # Resolve cache directory
    if cache_dir is None:
        try:
            from pathlib import Path as _Path
            cache_dir = _Path(__file__).parent / "cache" / "weekly"
        except Exception:
            cache_dir = None
    if cache_dir is not None:
        try:
            cache_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            cache_dir = None

    # Load from cache where fresh
    for t in tickers:
        loaded = False
        if cache_dir is not None:
            fp = cache_dir / f"{t}.parquet"
            try:
                if fp.exists():
                    age = now - _dt.datetime.utcfromtimestamp(fp.stat().st_mtime)
                    if age.days < cache_ttl_days:
                        df = pd.read_parquet(fp)
                        if not df.empty and len(df) >= 12:
                            result[t] = df
                            loaded = True
            except Exception:
                pass
        if not loaded:
            to_fetch.append(t)

    cache_hits = len(tickers) - len(to_fetch)
    if cache_hits:
        log.info(f"Weekly cache: {cache_hits}/{len(tickers)} tickers loaded from disk")

    # Fetch remaining tickers in batches
    import signal as _wk_sig
    import time as _wk_time

    def _weekly_timeout_handler(signum, frame):
        raise TimeoutError("weekly yf.download batch timeout")

    batch_size = 25  # smaller batches = more granular timeouts
    _wk_start   = _wk_time.time()
    _wk_timeout = 300  # 5 min total cap for all weekly fetches

    for i in range(0, len(to_fetch), batch_size):
        if _wk_time.time() - _wk_start > _wk_timeout:
            log.warning(f"Weekly data: total time cap ({_wk_timeout}s) reached — {len(result)}/{len(tickers)} loaded")
            break
        batch = to_fetch[i: i + batch_size]
        yf_batch = [_yf_ticker_normalize(t) for t in batch]
        yf_to_orig = {_yf_ticker_normalize(t): t for t in batch}
        try:
            _wk_sig.signal(_wk_sig.SIGALRM, _weekly_timeout_handler)
            _wk_sig.alarm(45)  # 45s per batch of 25
            data = yf.download(
                yf_batch, period=period, interval="1wk",
                group_by="ticker", progress=False, threads=False,
                auto_adjust=True,
            )
            _wk_sig.alarm(0)
            if len(batch) == 1:
                orig = batch[0]
                if not data.empty and len(data) >= 12:
                    # Flatten MultiIndex columns from single-ticker download
                    if data.columns.nlevels > 1:
                        data.columns = data.columns.droplevel("Ticker")
                    df = data[["Open", "High", "Low", "Close", "Volume"]].copy()
                    result[orig] = df
                    if cache_dir is not None:
                        try: df.to_parquet(cache_dir / f"{orig}.parquet")
                        except Exception as _pe: log.debug(f"Weekly parquet write failed for {orig}: {_pe}")
            else:
                top = data.columns.get_level_values(0).unique() if not data.empty else []
                for yf_t in yf_batch:
                    orig = yf_to_orig[yf_t]
                    try:
                        if yf_t in top:
                            df = data[yf_t].dropna(how="all")
                            if not df.empty and len(df) >= 12:
                                df = df[["Open", "High", "Low", "Close", "Volume"]].copy()
                                result[orig] = df
                                if cache_dir is not None:
                                    try: df.to_parquet(cache_dir / f"{orig}.parquet")
                                    except Exception as _pe: log.debug(f"Weekly parquet write failed for {orig}: {_pe}")
                    except Exception as _te:
                        log.debug(f"Weekly data extraction failed for {yf_t}: {_te}")
        except Exception as e:
            _wk_sig.alarm(0)
            log.warning(f"Weekly data batch failed: {e}")
        time.sleep(0.3)

    # ── Polygon retry for weekly bars still missing ───────────────────────────
    wk_missing = [t for t in to_fetch if t not in result]
    if wk_missing:
        log.info(f"Weekly Polygon retry for {len(wk_missing)} tickers...")
        for ticker in wk_missing:
            try:
                df = get_polygon_ohlcv(ticker, days=365, timespan="week")
                if df is not None and len(df) >= 12:
                    df = df[["Open", "High", "Low", "Close", "Volume"]].copy()
                    df = df[df["Close"].notna()]
                    result[ticker] = df
                    if cache_dir is not None:
                        try: df.to_parquet(cache_dir / f"{ticker}.parquet")
                        except Exception: pass
            except Exception as _we:
                log.debug(f"Polygon weekly retry failed for {ticker}: {_we}")

    log.info(f"Weekly data: {len(result)}/{len(tickers)} tickers")
    return result


# ── Earnings Beat Rate ────────────────────────────────────────────────────────

@_mem_cached(ttl_seconds=7200)
def get_earnings_beat_rate(ticker: str) -> dict:
    """
    Compute EPS beat rate from yfinance earnings history.
    Returns: beat_rate (0-1), beats, misses, total quarters checked.
    Retries once on transient errors; logs HTTP 401 (crumb expiry) explicitly.
    """
    empty = {"beat_rate": None, "beats": 0, "misses": 0, "quarters": 0, "error": None}

    def _fetch():
        t = yf.Ticker(ticker)
        hist = t.earnings_history
        if hist is None or (isinstance(hist, pd.DataFrame) and hist.empty):
            hist = t.quarterly_earnings
            if hist is None or (isinstance(hist, pd.DataFrame) and hist.empty):
                empty["error"] = "No earnings history"
                return empty
            empty["error"] = "No EPS estimate history"
            return empty
        if isinstance(hist, pd.DataFrame):
            hist = hist.reset_index()
            if "epsActual" in hist.columns and "epsEstimate" in hist.columns:
                valid = hist[hist["epsEstimate"].notna() & hist["epsActual"].notna()].tail(8)
                beats = int((valid["epsActual"] >= valid["epsEstimate"]).sum())
                total = len(valid)
                misses = total - beats
                beat_rate = round(beats / total, 2) if total > 0 else None
                return {"beat_rate": beat_rate, "beats": beats,
                        "misses": misses, "quarters": total, "error": None}
        empty["error"] = "Unexpected data format"
        return empty

    for attempt in range(2):
        try:
            return _fetch()
        except Exception as e:
            err_str = str(e)
            is_401 = "401" in err_str or "Unauthorized" in err_str or "Invalid Crumb" in err_str
            if is_401:
                log.debug(f"Beat rate {ticker}: Yahoo crumb expired (HTTP 401)")
                empty["error"] = "HTTP 401 — crumb expired"
                return empty  # No point retrying on auth failure
            if attempt == 0:
                time.sleep(1)
                continue
            log.debug(f"Beat rate {ticker}: {err_str}")
            empty["error"] = err_str
            return empty
    return empty


# ── Helpers ──────────────────────────────────────────────────────────────────

def _ema(data, period):
    if len(data) < period:
        return None
    s = pd.Series(data)
    return float(s.ewm(span=period, adjust=False).mean().iloc[-1])


def _sma(data, period):
    if len(data) < period:
        return None
    return float(np.mean(data[-period:]))


# ── Fear & Greed Index ────────────────────────────────────────────────────────

def get_fear_greed() -> dict:
    """Fetch CNN Fear & Greed Index from alternative.me (free, no auth)."""
    cached = _cache_read("fear_greed", ttl_seconds=3600)
    if cached:
        return cached
    try:
        resp = requests.get("https://api.alternative.me/fng/?limit=7",
                            timeout=8, headers={"User-Agent": "SwingTrade/1.0"})
        data = resp.json().get("data", [])
        if not data:
            raise ValueError("empty response")
        current = data[0]
        value = int(current["value"])
        label = current["value_classification"]
        history = [int(d["value"]) for d in data]
        trend = ("rising" if history[0] > history[-1] + 5 else
                 "falling" if history[0] < history[-1] - 5 else "stable")
        result = {"value": value, "label": label, "trend": trend,
                  "history": history, "error": None}
        _cache_write("fear_greed", result)
        return result
    except Exception as e:
        log.debug(f"Fear & Greed: {e}")
        return {"value": 50, "label": "Neutral", "trend": "stable",
                "history": [], "error": str(e)}


# ── Congressional Trades ──────────────────────────────────────────────────────

# Module-level cache for congressional data (large file, download once per session)
_CONGRESSIONAL_CACHE: dict | None = None
_CONGRESSIONAL_CACHE_TIME: float = 0.0

@_mem_cached(ttl_seconds=3600)
def get_congressional_trades(ticker: str, days: int = 90) -> dict:
    """Fetch congressional stock trades from senatestockwatcher.com (free JSON API)."""
    import time as _time
    global _CONGRESSIONAL_CACHE, _CONGRESSIONAL_CACHE_TIME

    empty = {"purchases": 0, "sales": 0, "net": "neutral", "latest": "", "error": None}

    try:
        # Download full dataset at most once per 24h (cached in memory for session)
        now = _time.time()
        if _CONGRESSIONAL_CACHE is None or (now - _CONGRESSIONAL_CACHE_TIME) > 86400:
            url = ("https://senate-stock-watcher-data.s3-us-west-2.amazonaws.com"
                   "/aggregate/all_transactions.json")
            resp = requests.get(url, timeout=15, headers={"User-Agent": "SwingTrade/1.0"})
            if resp.status_code != 200:
                return {**empty, "error": f"HTTP {resp.status_code}"}
            _CONGRESSIONAL_CACHE = resp.json()
            _CONGRESSIONAL_CACHE_TIME = now

        from datetime import datetime, timedelta
        cutoff = datetime.now() - timedelta(days=days)
        purchases = sales = 0
        latest_senator = ""

        for tx in _CONGRESSIONAL_CACHE:
            tickers_in_tx = tx.get("ticker", "") or ""
            if ticker.upper() not in tickers_in_tx.upper():
                continue
            try:
                tx_date = datetime.strptime(tx.get("transaction_date", "")[:10], "%Y-%m-%d")
            except Exception:
                continue
            if tx_date < cutoff:
                continue
            tx_type = (tx.get("type") or "").lower()
            if "purchase" in tx_type or "buy" in tx_type:
                purchases += 1
                latest_senator = tx.get("senator", tx.get("first_name", "")) + " " + tx.get("last_name", "")
            elif "sale" in tx_type or "sell" in tx_type:
                sales += 1

        net = "bullish" if purchases >= 2 and purchases > sales else \
              "bearish" if sales > purchases + 1 else "neutral"

        return {"purchases": purchases, "sales": sales, "net": net,
                "latest": latest_senator.strip(), "error": None}
    except Exception as e:
        log.debug(f"Congressional trades {ticker}: {e}")
        return {**empty, "error": str(e)}


# ── Reddit WallStreetBets ─────────────────────────────────────────────────────

@_mem_cached(ttl_seconds=1800)
def get_reddit_wsb(ticker: str) -> dict:
    """Fetch WallStreetBets mention count from Reddit public JSON API (no auth)."""
    cached = _cache_read(f"wsb_{ticker}", ttl_seconds=1800)
    if cached:
        return cached
    try:
        url = (f"https://www.reddit.com/r/wallstreetbets/search.json"
               f"?q={ticker}&sort=new&limit=25&restrict_sr=1")
        resp = requests.get(url, timeout=8,
                            headers={"User-Agent": "SwingTrade/1.0 (research bot)"})
        if resp.status_code != 200:
            raise ValueError(f"Reddit HTTP {resp.status_code}")
        posts = resp.json().get("data", {}).get("children", [])
        mentions = len(posts)
        if mentions == 0:
            result = {"mentions": 0, "avg_score": 0, "sentiment": "neutral", "error": None}
        else:
            scores = [p["data"].get("score", 0) for p in posts]
            avg_score = sum(scores) / len(scores)
            pos = sum(1 for s in scores if s > 100)
            neg = sum(1 for s in scores if s < 0)
            sentiment = ("bullish" if pos > neg + 2 else
                         "bearish" if neg > pos else "neutral")
            result = {"mentions": mentions, "avg_score": round(avg_score, 1),
                      "sentiment": sentiment, "error": None}
        _cache_write(f"wsb_{ticker}", result)
        return result
    except Exception as e:
        log.debug(f"Reddit WSB {ticker}: {e}")
        return {"mentions": 0, "avg_score": 0, "sentiment": "neutral", "error": str(e)}


# ── Unusual Options Activity (Barchart) ───────────────────────────────────────

@_mem_cached(ttl_seconds=1800)
def get_unusual_options(ticker: str) -> dict:
    """
    Scrape Barchart.com unusual options activity for a ticker (free, no auth).
    Filters for vol > OI rows (institutional conviction).

    Returns call_flow_score and put_flow_score (0-3 each), dominant_flow,
    and a human-readable summary string.
    """
    _EMPTY = {
        "unusual_calls": [], "unusual_puts": [],
        "call_flow_score": 0, "put_flow_score": 0,
        "dominant_flow": "neutral", "summary": "",
    }
    cached = _cache_read(f"uoa_{ticker}", ttl_seconds=14400)
    if cached:
        return cached

    url = f"https://www.barchart.com/options/unusual-activity/{ticker}"
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
    }
    try:
        resp = requests.get(url, timeout=8, headers=headers)
        if resp.status_code != 200:
            log.debug(f"Unusual options {ticker}: HTTP {resp.status_code}")
            return _EMPTY

        soup = BeautifulSoup(resp.text, "html.parser")

        # Barchart renders its table inside a <table> or a vue-rendered component.
        # Look for any table containing option-like column headers.
        table = None
        for tbl in soup.find_all("table"):
            header_text = tbl.get_text(" ", strip=True).lower()
            if any(kw in header_text for kw in ["strike", "expir", "volume", "open int"]):
                table = tbl
                break

        unusual_calls: list[dict] = []
        unusual_puts: list[dict] = []

        if table:
            # Map header labels to column indices
            headers_row = table.find("tr")
            col_names: list[str] = []
            if headers_row:
                col_names = [th.get_text(strip=True).lower()
                             for th in headers_row.find_all(["th", "td"])]

            def _col_idx(*candidates) -> int | None:
                for c in candidates:
                    for i, h in enumerate(col_names):
                        if c in h:
                            return i
                return None

            idx_type   = _col_idx("type", "call", "put", "option type")
            idx_strike = _col_idx("strike")
            idx_expiry = _col_idx("expir", "exp")
            idx_vol    = _col_idx("volume", "vol")
            idx_oi     = _col_idx("open int", "oi")
            idx_size   = _col_idx("size", "label", "trade size")

            for tr in table.find_all("tr")[1:]:
                cells = tr.find_all(["td", "th"])
                if len(cells) < 3:
                    continue

                def _cell(idx) -> str:
                    if idx is not None and idx < len(cells):
                        return cells[idx].get_text(strip=True)
                    return ""

                raw_type   = _cell(idx_type).upper()
                raw_strike = _cell(idx_strike).replace("$", "").replace(",", "")
                raw_expiry = _cell(idx_expiry)
                raw_vol    = _cell(idx_vol).replace(",", "")
                raw_oi     = _cell(idx_oi).replace(",", "")
                raw_size   = _cell(idx_size)

                try:
                    strike = float(raw_strike) if raw_strike else 0.0
                    vol    = int(float(raw_vol))  if raw_vol    else 0
                    oi     = int(float(raw_oi))   if raw_oi     else 0
                except (ValueError, OverflowError):
                    continue

                # Only keep rows where volume exceeds open interest
                if vol <= oi or vol == 0:
                    continue

                vol_oi = round(vol / max(oi, 1), 2)
                row = {
                    "strike":  strike,
                    "expiry":  raw_expiry,
                    "volume":  vol,
                    "oi":      oi,
                    "vol_oi":  vol_oi,
                    "size":    raw_size,
                }

                is_put = "PUT" in raw_type or raw_type == "P"
                if is_put:
                    unusual_puts.append(row)
                else:
                    # Default to call if ambiguous
                    unusual_calls.append(row)

        # Sort by volume descending
        unusual_calls.sort(key=lambda r: r["volume"], reverse=True)
        unusual_puts.sort(key=lambda r: r["volume"], reverse=True)

        # Score 0-3: 0=none, 1=light (1-2 rows), 2=moderate (3-5), 3=heavy (6+)
        def _flow_score(rows: list[dict]) -> int:
            n = len(rows)
            if n == 0:   return 0
            if n <= 2:   return 1
            if n <= 5:   return 2
            return 3

        call_score = _flow_score(unusual_calls)
        put_score  = _flow_score(unusual_puts)

        if call_score > put_score:
            dominant = "bullish"
        elif put_score > call_score:
            dominant = "bearish"
        else:
            dominant = "neutral"

        # Human-readable summary (top-2 by volume)
        def _fmt_rows(rows: list[dict], label: str) -> str:
            if not rows:
                return ""
            top = rows[:2]
            parts = [f"${r['strike']:.0f}{label[0].upper()} ×{r['volume']:,}" for r in top]
            intensity = ["None", "Light", "Moderate", "Heavy"][_flow_score(rows)]
            return f"{intensity} {label} flow: {', '.join(parts)}"

        call_summary = _fmt_rows(unusual_calls, "call")
        put_summary  = _fmt_rows(unusual_puts, "put")
        summary = " | ".join(s for s in [call_summary, put_summary] if s)

        result = {
            "unusual_calls":    unusual_calls,
            "unusual_puts":     unusual_puts,
            "call_flow_score":  call_score,
            "put_flow_score":   put_score,
            "dominant_flow":    dominant,
            "summary":          summary,
        }
        _cache_write(f"uoa_{ticker}", result)
        return result

    except Exception as e:
        log.debug(f"Unusual options {ticker}: {e}")
        return _EMPTY


# ── Short Interest / Borrow Rate (Finviz) ─────────────────────────────────────

def get_borrow_rate(ticker: str) -> dict:
    """
    Scrape Finviz for short interest data: Short Float %, Days to Cover,
    and short interest in shares. Derives a squeeze_probability score (0.0-1.0).

    squeeze_probability = min(1.0, short_float_pct/30 + min(0.3, days_to_cover/20))
    """
    _EMPTY = {
        "short_float_pct": None,
        "days_to_cover":   None,
        "short_interest":  None,
        "squeeze_probability": 0.0,
    }
    cached = _cache_read(f"borrow_{ticker}", ttl_seconds=21600)
    if cached:
        return cached

    url = f"https://finviz.com/quote.ashx?t={ticker}"
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Referer":         "https://finviz.com/",
    }
    try:
        resp = requests.get(url, timeout=8, headers=headers)
        if resp.status_code != 200:
            log.debug(f"Borrow rate {ticker}: HTTP {resp.status_code}")
            return _EMPTY

        soup = BeautifulSoup(resp.text, "html.parser")

        # Finviz stats table: alternating label/value cells in <td class="snapshot-td2">
        # or in a table with class "snapshot-table2" / "table-dark-row"
        stat_map: dict[str, str] = {}
        for table in soup.find_all("table"):
            tbl_cls = " ".join(table.get("class") or [])
            if "snapshot" not in tbl_cls.lower() and "dark" not in tbl_cls.lower():
                continue
            cells = table.find_all("td")
            # Pairs: label cell followed by value cell
            for i in range(0, len(cells) - 1, 2):
                label = cells[i].get_text(strip=True)
                value = cells[i + 1].get_text(strip=True)
                if label:
                    stat_map[label] = value

        # If paired scan found nothing, try a flat cell walk (some Finviz layouts)
        if not stat_map:
            all_cells = [td.get_text(strip=True) for td in soup.find_all("td")]
            for i in range(0, len(all_cells) - 1, 2):
                if all_cells[i]:
                    stat_map[all_cells[i]] = all_cells[i + 1] if i + 1 < len(all_cells) else ""

        def _parse_float(raw: str) -> float | None:
            """Strip %, commas, M/B suffixes and return float, or None on failure."""
            raw = raw.strip().rstrip("%").replace(",", "")
            if not raw or raw in ("-", "N/A", ""):
                return None
            try:
                if raw.endswith("M"):
                    return float(raw[:-1]) * 1_000_000
                if raw.endswith("B"):
                    return float(raw[:-1]) * 1_000_000_000
                return float(raw)
            except ValueError:
                return None

        # Look for Short Float under various label spellings
        short_float_pct: float | None = None
        for label in ("Short Float", "Short Float %", "Shs Float", "Short% of Float"):
            raw = stat_map.get(label, "")
            if raw:
                short_float_pct = _parse_float(raw)
                if short_float_pct is not None:
                    break

        days_to_cover: float | None = None
        for label in ("Short Ratio", "Days to Cover", "Short Ratio (DTC)"):
            raw = stat_map.get(label, "")
            if raw:
                days_to_cover = _parse_float(raw)
                if days_to_cover is not None:
                    break

        short_interest: int | None = None
        for label in ("Short Interest", "Shares Short", "Short Volume"):
            raw = stat_map.get(label, "")
            if raw:
                val = _parse_float(raw)
                if val is not None:
                    short_interest = int(val)
                    break

        # Squeeze probability formula
        squeeze_prob = 0.0
        if short_float_pct is not None:
            base = min(1.0, short_float_pct / 30.0)
            dtc_bonus = min(0.3, (days_to_cover or 0.0) / 20.0)
            squeeze_prob = round(min(1.0, base + dtc_bonus), 3)

        result = {
            "short_float_pct":     short_float_pct,
            "days_to_cover":       days_to_cover,
            "short_interest":      short_interest,
            "squeeze_probability": squeeze_prob,
        }
        _cache_write(f"borrow_{ticker}", result)
        return result

    except Exception as e:
        log.debug(f"Borrow rate {ticker}: {e}")
        return _EMPTY


# ── SEC EDGAR Filings ────────────────────────────────────────────────────────

@_mem_cached(ttl_seconds=3600)
def get_sec_filings(ticker: str, forms: list[str] | None = None, days: int = 30) -> dict:
    """
    Fetch recent SEC EDGAR filings for a ticker.

    Uses EDGAR full-text search API (free, no auth, requires User-Agent with email).

    Args:
        ticker: Stock ticker (e.g., "NVDA")
        forms: Filing types to filter (default: ["8-K", "4", "SC 13D", "SC 13G"])
               8-K = material events (earnings, M&A, leadership changes)
               4 = insider transactions
               SC 13D/G = large shareholder disclosures
        days: Look back period in days

    Returns:
        {
            "filings": [
                {
                    "form": "8-K",
                    "filed": "2024-03-15",
                    "description": "Current report...",
                    "url": "https://www.sec.gov/Archives/...",
                },
                ...
            ],
            "has_material_event": bool,  # True if 8-K filed in last 5 days
            "insider_filing_count": int,  # Form 4 count in period
            "catalyst_signal": str,  # "material_event" | "insider_cluster" | "none"
            "error": None
        }
    """
    if forms is None:
        forms = ["8-K", "4", "SC 13D", "SC 13G"]

    cached = _cache_read(f"sec_{ticker}", ttl_seconds=3600)
    if cached:
        return cached

    try:
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        start_str = start_date.strftime("%Y-%m-%d")
        end_str = end_date.strftime("%Y-%m-%d")

        # Build URL for EDGAR full-text search API
        # Comma-separated form types
        form_str = ",".join(forms)

        # URL encode the ticker for exact match
        import urllib.parse
        ticker_encoded = urllib.parse.quote(f'"{ticker}"')

        url = (
            f"https://efts.sec.gov/LATEST/search-index"
            f"?q={ticker_encoded}"
            f"&dateRange=custom"
            f"&startdt={start_str}"
            f"&enddt={end_str}"
            f"&forms={form_str}"
        )

        headers = {
            "User-Agent": "SwingTrade/1.0 research@swingtradeagent.com",
            "Accept": "application/json",
        }

        resp = requests.get(url, headers=headers, timeout=10)
        resp.raise_for_status()

        # SEC API returns HTML by default; try JSON first, fall back to parsing
        try:
            data = resp.json()
            filings_raw = data.get("hits", {}).get("hits", [])
        except Exception:
            # Fall back to simple HTML parsing if JSON fails
            filings_raw = []

        # Process filings
        filings = []
        insider_count = 0
        has_material_event = False

        for filing in filings_raw:
            form_type = filing.get("form-type", "") or filing.get("form", "")
            filed_date_str = filing.get("filed", "") or filing.get("date", "")

            # Parse filed date
            try:
                filed_date = datetime.strptime(filed_date_str[:10], "%Y-%m-%d")
            except Exception:
                continue

            description = (filing.get("summary", "") or
                          filing.get("description", "") or
                          filing.get("title", "")).strip()[:150]

            url_path = filing.get("url", "") or filing.get("href", "")
            if url_path and not url_path.startswith("http"):
                url_path = f"https://www.sec.gov{url_path}"

            filings.append({
                "form": form_type,
                "filed": filed_date_str[:10],
                "description": description,
                "url": url_path,
            })

            # Count insider filings
            if form_type == "4":
                insider_count += 1

            # Check for material events in last 5 days
            if form_type == "8-K":
                days_ago = (end_date - filed_date).days
                if days_ago <= 5:
                    has_material_event = True

        # Determine catalyst signal
        catalyst_signal = "none"
        if has_material_event:
            catalyst_signal = "material_event"
        elif insider_count >= 3:
            catalyst_signal = "insider_cluster"

        result = {
            "filings": filings,
            "has_material_event": has_material_event,
            "insider_filing_count": insider_count,
            "catalyst_signal": catalyst_signal,
            "error": None,
        }

        _cache_write(f"sec_{ticker}", result)
        log.debug(f"SEC filings {ticker}: {len(filings)} found, catalyst={catalyst_signal}")
        return result

    except Exception as e:
        log.debug(f"SEC filings {ticker}: {e}")
        return {
            "filings": [],
            "has_material_event": False,
            "insider_filing_count": 0,
            "catalyst_signal": "none",
            "error": str(e),
        }


# ── Finnhub ──────────────────────────────────────────────────────────────────

def get_finnhub_data(ticker: str) -> dict:
    """
    Pull supplemental data from Finnhub free tier.
    Requires finnhub_api_key in config/config.json data_sources section.
    Returns empty dict gracefully if key is missing or calls fail.

    Fetches:
      - Basic financials (52w high/low, market cap, beta, PE, EPS)
      - Analyst recommendation trend (monthly breakdown)
      - Company news (last 7 days)
      - Earnings surprise history
    """
    _EMPTY = {
        "beta": None, "pe": None, "eps": None, "market_cap": None,
        "52w_high": None, "52w_low": None, "revenue_growth": None,
        "analyst_buy": 0, "analyst_hold": 0, "analyst_sell": 0,
        "news": [], "earnings_surprises": [],
        "source": "finnhub", "error": None,
    }
    try:
        try:
            from secrets_loader import finnhub_key as _fnk
            api_key = _fnk()
        except Exception:
            api_key = load_config().get("data_sources", {}).get("finnhub_api_key", "")
        if not api_key:
            return {**_EMPTY, "error": "no_api_key"}

        cache_key = f"finnhub_{ticker}"
        cached = _cache_read(cache_key, ttl_seconds=3600)  # 1-hour TTL
        if cached:
            return cached

        result = dict(_EMPTY)
        headers = {"X-Finnhub-Token": api_key}
        base = "https://finnhub.io/api/v1"

        # Basic financials
        try:
            r = requests.get(f"{base}/stock/metric", params={"symbol": ticker, "metric": "all"},
                             headers=headers, timeout=10)
            if r.status_code == 200:
                m = r.json().get("metric", {})
                result.update({
                    "beta":          m.get("beta"),
                    "pe":            m.get("peTTM"),
                    "eps":           m.get("epsTTM"),
                    "market_cap":    m.get("marketCapitalization"),
                    "52w_high":      m.get("52WeekHigh"),
                    "52w_low":       m.get("52WeekLow"),
                    "revenue_growth": m.get("revenueGrowthTTMYoy"),
                })
        except Exception:
            pass

        # Analyst recommendations (last 3 months)
        try:
            r = requests.get(f"{base}/stock/recommendation", params={"symbol": ticker},
                             headers=headers, timeout=10)
            if r.status_code == 200:
                recs = r.json()
                if recs:
                    latest = recs[0]
                    result["analyst_buy"]  = (latest.get("strongBuy", 0) or 0) + (latest.get("buy", 0) or 0)
                    result["analyst_hold"] = latest.get("hold", 0) or 0
                    result["analyst_sell"] = (latest.get("sell", 0) or 0) + (latest.get("strongSell", 0) or 0)
        except Exception:
            pass

        # Company news (last 7 days)
        try:
            to_dt = datetime.now().strftime("%Y-%m-%d")
            from_dt = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
            r = requests.get(f"{base}/company-news",
                             params={"symbol": ticker, "from": from_dt, "to": to_dt},
                             headers=headers, timeout=10)
            if r.status_code == 200:
                articles = r.json()[:5]
                result["news"] = [
                    {"headline": a.get("headline", ""), "source": a.get("source", ""),
                     "url": a.get("url", ""), "datetime": a.get("datetime", 0)}
                    for a in articles if a.get("headline")
                ]
        except Exception:
            pass

        # Earnings surprises (last 4 quarters)
        try:
            r = requests.get(f"{base}/stock/earnings", params={"symbol": ticker, "limit": 4},
                             headers=headers, timeout=10)
            if r.status_code == 200:
                surprises = r.json()
                result["earnings_surprises"] = [
                    {"period": s.get("period", ""), "actual": s.get("actual"),
                     "estimate": s.get("estimate"), "surprise_pct": s.get("surprisePercent")}
                    for s in surprises
                ]
        except Exception:
            pass

        _cache_write(cache_key, result)
        return result

    except Exception as e:
        log.debug(f"Finnhub {ticker}: {e}")
        return {**_EMPTY, "error": str(e)}


# ── FMP (Financial Modeling Prep) ────────────────────────────────────────────

def get_fmp_data(ticker: str) -> dict:
    """
    Pull supplemental data from Financial Modeling Prep free tier (250 calls/day).
    Requires fmp_api_key in config/config.json data_sources section.
    Returns empty dict gracefully if key is missing or calls fail.

    Fetches:
      - Key financial ratios (P/E, P/S, P/B, debt/equity, current ratio, ROE, ROA)
      - Analyst consensus estimates (EPS + revenue for next 2 quarters)
      - Institutional ownership (top holders)
    """
    _EMPTY = {
        "pe": None, "ps": None, "pb": None, "debt_equity": None,
        "current_ratio": None, "roe": None, "roa": None, "gross_margin": None,
        "ev_ebitda": None, "fcf_yield": None, "rev_per_sh": None,
        "market_cap": None, "sector": "", "industry": "",
        "source": "fmp", "error": None,
    }
    try:
        try:
            from secrets_loader import fmp_key as _fmpk
            api_key = _fmpk()
        except Exception:
            api_key = load_config().get("data_sources", {}).get("fmp_api_key", "")
        if not api_key:
            return {**_EMPTY, "error": "no_api_key"}

        cache_key = f"fmp_{ticker}"
        cached = _cache_read(cache_key, ttl_seconds=3600)
        if cached:
            return cached

        result = dict(_EMPTY)
        # FMP moved to /stable/ endpoints in Aug 2025; /api/v3/ legacy endpoints are now 403
        base = "https://financialmodelingprep.com/stable"
        params_base = {"apikey": api_key}

        # Annual ratios (P/E, P/S, P/B, debt/equity, current ratio, ROE, ROA, gross margin)
        try:
            r = requests.get(f"{base}/ratios", params={**params_base, "symbol": ticker, "period": "annual", "limit": 1}, timeout=10)
            if r.status_code == 200:
                data = r.json()
                if data:
                    d = data[0]
                    result.update({
                        "pe":            d.get("priceEarningsRatio"),
                        "ps":            d.get("priceToSalesRatio"),
                        "pb":            d.get("priceToBookRatio"),
                        "debt_equity":   d.get("debtEquityRatio"),
                        "current_ratio": d.get("currentRatio"),
                        "roe":           d.get("returnOnEquity"),
                        "roa":           d.get("returnOnAssets"),
                        "gross_margin":  d.get("grossProfitMargin"),
                    })
        except Exception:
            pass

        # Key metrics (additional: EV/EBITDA, FCF yield, revenue per share)
        try:
            r = requests.get(f"{base}/key-metrics", params={**params_base, "symbol": ticker, "period": "annual", "limit": 1}, timeout=10)
            if r.status_code == 200:
                data = r.json()
                if data:
                    d = data[0]
                    result["ev_ebitda"]   = d.get("enterpriseValueOverEBITDA")
                    result["fcf_yield"]   = d.get("freeCashFlowYield")
                    result["rev_per_sh"]  = d.get("revenuePerShare")
        except Exception:
            pass

        # Company profile (beta, market cap — as cross-check / supplement)
        try:
            r = requests.get(f"{base}/profile", params={**params_base, "symbol": ticker}, timeout=10)
            if r.status_code == 200:
                data = r.json()
                if data:
                    d = data[0]
                    if result.get("pe") is None:
                        result["pe"] = d.get("pe")
                    result["market_cap"] = d.get("marketCap")
                    result["sector"]     = d.get("sector", "")
                    result["industry"]   = d.get("industry", "")
        except Exception:
            pass

        _cache_write(cache_key, result)
        return result

    except Exception as e:
        log.debug(f"FMP {ticker}: {e}")
        return {**_EMPTY, "error": str(e)}


# ── Pre-market Volume ────────────────────────────────────────────────────────

@_mem_cached(ttl_seconds=900)
def get_premarket_volume(ticker: str) -> dict:
    """Detect unusual pre-market volume (4am–9:30am) vs 20-day average pre-market volume.

    Uses yfinance 1-minute data for today's pre-market session.
    Returns:
        premarket_vol: shares traded in pre-market today
        avg_premarket_vol: 20-day average pre-market volume
        vol_ratio: ratio of today vs average (>2 = unusual)
        unusual: bool (vol_ratio > 2)
        price_chg_pct: % price change in pre-market
    """
    cache_key = f"premarket_{ticker}"
    cached = _cache_read(cache_key, ttl_seconds=1800)  # 30-min cache
    if cached:
        return cached

    _empty = {"premarket_vol": 0, "avg_premarket_vol": 0, "vol_ratio": 1.0,
              "unusual": False, "price_chg_pct": 0.0}
    try:
        import pytz
        eastern = pytz.timezone("America/New_York")
        now_et = datetime.now(eastern)

        # Fetch 5-day 1-minute data (covers pre-market today + prior sessions)
        raw = yf.download(ticker, period="5d", interval="1m", progress=False,
                          auto_adjust=True, prepost=True)
        if raw.empty:
            return _empty

        close = raw["Close"].squeeze() if isinstance(raw["Close"], pd.DataFrame) else raw["Close"]
        vol   = raw["Volume"].squeeze() if isinstance(raw["Volume"], pd.DataFrame) else raw["Volume"]

        # Today's pre-market: 4:00am – 9:29am ET
        today_str = now_et.strftime("%Y-%m-%d")
        pm_start  = pd.Timestamp(f"{today_str} 04:00:00", tz=eastern)
        pm_end    = pd.Timestamp(f"{today_str} 09:29:00", tz=eastern)

        today_pm_mask = (raw.index >= pm_start) & (raw.index <= pm_end)
        today_pm_vol  = float(vol[today_pm_mask].sum()) if today_pm_mask.any() else 0
        today_pm_prices = close[today_pm_mask].dropna()
        pm_price_chg = 0.0
        if len(today_pm_prices) >= 2:
            pm_price_chg = round((float(today_pm_prices.iloc[-1]) - float(today_pm_prices.iloc[0]))
                                 / float(today_pm_prices.iloc[0]) * 100, 2)

        # 20-day average pre-market volume (prior trading days only)
        pm_vols_hist = []
        seen_dates = set()
        for ts, v in zip(raw.index, vol.values):
            try:
                ts_et = ts.astimezone(eastern) if ts.tzinfo else ts
                ds = ts_et.strftime("%Y-%m-%d")
                if ds == today_str or ds in seen_dates:
                    continue
                t_str = ts_et.strftime("%H:%M")
                if "04:00" <= t_str <= "09:29":
                    if ds not in seen_dates:
                        # accumulate per day
                        seen_dates.add(ds)
                        # collect vol for that day
                        day_mask = raw.index.normalize() == pd.Timestamp(ds)
                        pm_day_mask = day_mask & (raw.index.hour < 9) | (
                            day_mask & (raw.index.hour == 9) & (raw.index.minute < 30))
                        day_pm_vol = float(vol[pm_day_mask].sum()) if pm_day_mask.any() else 0
                        if day_pm_vol > 0:
                            pm_vols_hist.append(day_pm_vol)
            except Exception:
                continue

        avg_pm_vol = float(np.mean(pm_vols_hist)) if pm_vols_hist else 0
        vol_ratio  = round(today_pm_vol / avg_pm_vol, 2) if avg_pm_vol > 0 else 1.0
        unusual    = vol_ratio >= 2.0

        result = {
            "premarket_vol":     int(today_pm_vol),
            "avg_premarket_vol": int(avg_pm_vol),
            "vol_ratio":         vol_ratio,
            "unusual":           unusual,
            "price_chg_pct":     pm_price_chg,
        }
        _cache_write(cache_key, result)
        return result
    except Exception as e:
        log.debug(f"Pre-market volume {ticker}: {e}")
        return _empty


# ── Institutional Ownership Trend (13F proxy) ────────────────────────────────

@_mem_cached(ttl_seconds=3600)
def get_institutional_trend(ticker: str) -> dict:
    """Estimate institutional ownership trend from yfinance institutional holders data.

    Returns:
        inst_pct: current institutional ownership %
        inst_trend: "increasing" | "stable" | "decreasing"
        top_holders: list of top 5 holder names
        net_change_pct: estimated change in ownership % (positive = growing)
        total_holders: number of institutional holders
    """
    cache_key = f"inst_trend_{ticker}"
    cached = _cache_read(cache_key, ttl_seconds=86400)  # 24-hr cache (quarterly data)
    if cached:
        return cached

    _empty = {"inst_pct": None, "inst_trend": "unknown", "top_holders": [],
              "net_change_pct": 0, "total_holders": 0}
    try:
        t = yf.Ticker(ticker)
        info = t.fast_info if hasattr(t, "fast_info") else {}

        # Current institutional holding %
        inst_pct = None
        try:
            inst_pct = getattr(info, "shares_percent_institutions", None)
            if inst_pct is None:
                full_info = t.info or {}
                inst_pct = full_info.get("heldPercentInstitutions")
        except Exception:
            pass

        # Institutional holders table — check for recent filings trend
        try:
            holders_df = t.institutional_holders
        except Exception:
            holders_df = None

        top_holders = []
        total_holders = 0
        net_change_pct = 0.0
        inst_trend = "stable"

        if holders_df is not None and not holders_df.empty:
            total_holders = len(holders_df)
            top_holders = list(holders_df.get("Holder", holders_df.iloc[:, 0]).head(5))

            # Estimate trend from % Out change column if available
            for col in holders_df.columns:
                if "change" in str(col).lower() or "pct" in str(col).lower():
                    try:
                        changes = holders_df[col].dropna().astype(float)
                        net_change_pct = round(float(changes.mean()) * 100, 2)
                        if net_change_pct > 1:
                            inst_trend = "increasing"
                        elif net_change_pct < -1:
                            inst_trend = "decreasing"
                        break
                    except Exception:
                        pass

        result = {
            "inst_pct":        round(float(inst_pct) * 100, 1) if inst_pct else None,
            "inst_trend":      inst_trend,
            "top_holders":     top_holders,
            "net_change_pct":  net_change_pct,
            "total_holders":   total_holders,
        }
        _cache_write(cache_key, result)
        return result
    except Exception as e:
        log.debug(f"Institutional trend {ticker}: {e}")
        return _empty


# ── Gamma Squeeze Probability ────────────────────────────────────────────────

@_mem_cached(ttl_seconds=1800)
def get_gamma_squeeze_data(ticker: str) -> dict:
    """Compute gamma squeeze probability combining options OI and short interest.

    Gamma squeeze occurs when:
    1. Large OTM call open interest (dealers must delta-hedge by buying stock)
    2. High short float (shorts forced to cover as price rises)
    3. Low float (stock is easy to move)
    4. High RVOL (momentum already building)

    Returns:
        gamma_score: 0-100 score
        call_oi_skew: ratio of call OI to total OI
        short_float_pct: % of float sold short
        float_size: shares float in millions
        gamma_risk: "high" | "moderate" | "low"
    """
    cache_key = f"gamma_{ticker}"
    cached = _cache_read(cache_key, ttl_seconds=3600)
    if cached:
        return cached

    _empty = {"gamma_score": 0, "call_oi_skew": 0.5, "short_float_pct": 0,
              "float_size_m": 0, "gamma_risk": "low"}
    try:
        t = yf.Ticker(ticker)
        info = t.info or {}

        # Short interest
        short_float = float(info.get("shortPercentOfFloat") or info.get("short_pct") or 0)
        float_shares = float(info.get("floatShares") or 0)
        float_size_m = float_shares / 1_000_000 if float_shares > 0 else 0

        # Options chain — aggregate call vs put OI
        call_oi = put_oi = 0
        try:
            exp_dates = t.options[:3] if t.options else []  # first 3 expiries
            for exp in exp_dates:
                chain = t.option_chain(exp)
                call_oi += int(chain.calls["openInterest"].sum())
                put_oi  += int(chain.puts["openInterest"].sum())
        except Exception:
            pass

        total_oi = call_oi + put_oi
        call_oi_skew = round(call_oi / total_oi, 3) if total_oi > 0 else 0.5

        # Gamma score (0-100)
        score = 0
        # Short float component (max 40)
        if   short_float > 0.30: score += 40
        elif short_float > 0.20: score += 30
        elif short_float > 0.15: score += 20
        elif short_float > 0.10: score += 10

        # Call OI skew component (max 35)
        if   call_oi_skew > 0.75: score += 35
        elif call_oi_skew > 0.65: score += 25
        elif call_oi_skew > 0.55: score += 15

        # Low float multiplier (max 25)
        if   float_size_m < 20:  score += 25   # micro-float = extreme gamma risk
        elif float_size_m < 50:  score += 15
        elif float_size_m < 100: score += 8

        score = min(100, score)
        gamma_risk = "high" if score >= 65 else "moderate" if score >= 35 else "low"

        result = {
            "gamma_score":     score,
            "call_oi_skew":    call_oi_skew,
            "call_oi":         call_oi,
            "put_oi":          put_oi,
            "short_float_pct": round(short_float * 100, 1),
            "float_size_m":    round(float_size_m, 1),
            "gamma_risk":      gamma_risk,
        }
        _cache_write(cache_key, result)
        return result
    except Exception as e:
        log.debug(f"Gamma squeeze {ticker}: {e}")
        return _empty


# ── Earnings Estimate Trend (30-day consensus direction) ─────────────────────

@_mem_cached(ttl_seconds=3600)
def get_earnings_estimate_trend(ticker: str) -> dict:
    """Track the direction of analyst EPS estimate consensus over the past 30 days.

    Uses yfinance earnings estimate tables to compare current consensus
    vs ~30-day-prior consensus. A rising consensus is a strong bullish signal
    (PEAD tends to be stronger when estimates were revised upward pre-earnings).

    Returns:
        trend: "rising" | "falling" | "stable"
        current_eps_est: current consensus EPS estimate
        prior_eps_est: estimate 30 days ago (proxied from analyst revision counts)
        revision_direction: +1 rising, -1 falling, 0 stable
        surprise_history_mean: avg historical beat %
    """
    cache_key = f"eps_trend_{ticker}"
    cached = _cache_read(cache_key, ttl_seconds=86400)  # 24-hr cache
    if cached:
        return cached

    _empty = {"trend": "stable", "current_eps_est": None, "prior_eps_est": None,
              "revision_direction": 0, "surprise_history_mean": 0}
    try:
        t = yf.Ticker(ticker)

        # Analyst earnings estimates (current quarter + next quarter)
        try:
            ests = t.earnings_estimate
        except Exception:
            ests = None

        current_eps_est = None
        if ests is not None and not ests.empty:
            try:
                # "0q" = current quarter row
                row = ests.loc["0q"] if "0q" in ests.index else ests.iloc[0]
                avg_col = [c for c in ests.columns if "avg" in str(c).lower()]
                if avg_col:
                    current_eps_est = float(row[avg_col[0]])
                elif len(ests.columns) >= 1:
                    current_eps_est = float(row.iloc[0])
            except Exception:
                pass

        # Earnings history — compute avg beat %
        surprise_history_mean = 0.0
        try:
            hist = t.earnings_history if hasattr(t, "earnings_history") else None
            if hist is None:
                hist = t.quarterly_earnings
            if hist is not None and not hist.empty:
                if "Surprise(%)" in hist.columns:
                    surp = hist["Surprise(%)"].dropna()
                elif "surprisePct" in hist.columns:
                    surp = hist["surprisePct"].dropna()
                else:
                    surp = pd.Series(dtype=float)
                if len(surp) >= 2:
                    surprise_history_mean = round(float(surp.head(4).mean()), 1)
        except Exception:
            pass

        # Estimate revision direction — use analyst upgrade/downgrade proxy from info
        info = t.info or {}
        upgrades_30d   = info.get("upgrades_30d",    info.get("upgrades_10d",   0) or 0)
        downgrades_30d = info.get("downgrades_30d", info.get("downgrades_10d", 0) or 0)

        if upgrades_30d > downgrades_30d:
            trend = "rising"
            revision_direction = 1
        elif downgrades_30d > upgrades_30d:
            trend = "falling"
            revision_direction = -1
        else:
            trend = "stable"
            revision_direction = 0

        # Cross-check: if surprise history is consistently positive, bias toward rising
        if surprise_history_mean > 5 and trend == "stable":
            trend = "rising"
            revision_direction = 1

        result = {
            "trend":                  trend,
            "current_eps_est":        current_eps_est,
            "revision_direction":     revision_direction,
            "surprise_history_mean":  surprise_history_mean,
        }
        _cache_write(cache_key, result)
        return result
    except Exception as e:
        log.debug(f"EPS estimate trend {ticker}: {e}")
        return _empty


# ── FINVIZ Elite ──────────────────────────────────────────────────────────────

_FINVIZ_BASE = "https://elite.finviz.com"
_FINVIZ_VIEWS = {
    "valuation":    121,   # EPS Growth This/Next Year, PEG, Forward P/E, P/S, P/B, P/C, P/FCF, Dividend Yield
    "ownership":    131,   # Shares Float, Short Float, Short Ratio, Insider Own, Institutional Own
    "performance":  141,   # Perf Week/Month/Quarter/Half/Year, Volatility, Avg Volume, Rel Volume
    "financial":    161,   # ROE, ROA, Gross/Operating/Profit Margin, Current Ratio, Earnings Date
    "technical":    171,   # Beta, ATR, RSI(14), 52W High/Low, SMA 20/50/200
}


def _finviz_token() -> str:
    try:
        from secrets_loader import finviz_token as _ft
        return _ft()
    except Exception:
        return load_config().get("data_sources", {}).get("finviz_token", "")


def _finviz_pct(val: str | None) -> float | None:
    """Parse FINVIZ percentage strings like '12.34%' or '-5.67%' → float or None."""
    if not val or val in ("-", "N/A", ""):
        return None
    try:
        return float(str(val).replace("%", "").replace(",", "").strip())
    except ValueError:
        return None


def _finviz_float(val: str | None) -> float | None:
    """Parse FINVIZ numeric strings like '1.23B', '456.78M', '12.34' → float or None."""
    if not val or val in ("-", "N/A", ""):
        return None
    s = str(val).replace(",", "").strip()
    try:
        if s.endswith("B"):
            return float(s[:-1]) * 1e9
        if s.endswith("M"):
            return float(s[:-1]) * 1e6
        if s.endswith("K"):
            return float(s[:-1]) * 1e3
        return float(s)
    except ValueError:
        return None


def get_finviz_bulk() -> dict[str, dict]:
    """
    Fetch FINVIZ Elite screener data for all S&P 500 + Nasdaq stocks in 5 parallel calls.
    Returns dict keyed by uppercase ticker → merged row from all views.
    Cache TTL: 4 hours (data is intraday-stable for our use case).

    Columns merged per ticker:
      valuation:   eps_growth_this_yr, eps_growth_next_yr, peg, fwd_pe, ps
      ownership:   shares_float, short_float_pct, short_ratio, insider_own_pct, inst_own_pct
      performance: rel_volume, avg_volume, perf_week_pct, perf_month_pct, volatility_w_pct
      financial:   roe_pct, roa_pct, gross_margin_pct, oper_margin_pct, profit_margin_pct,
                   current_ratio, earnings_date
      technical:   beta, atr, rsi14, high_52w, low_52w, sma20_pct, sma50_pct, sma200_pct
    """
    today = datetime.now().strftime("%Y%m%d")
    cache_key = f"finviz_bulk_{today}"
    cached = _cache_read(cache_key, ttl_seconds=4 * 3600)
    if cached:
        return cached

    token = _finviz_token()
    if not token:
        log.warning("FINVIZ: no token configured — skipping bulk fetch")
        return {}

    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Accept": "text/csv,*/*",
        "Referer": "https://elite.finviz.com/screener.ashx",
    }

    def _fetch_view(view_id: int) -> pd.DataFrame | None:
        url = f"{_FINVIZ_BASE}/export.ashx"
        params = {"v": view_id, "auth": token}
        try:
            r = requests.get(url, params=params, headers=headers, timeout=30)
            if r.status_code != 200:
                log.warning(f"FINVIZ view {view_id}: HTTP {r.status_code}")
                return None
            from io import StringIO
            df = pd.read_csv(StringIO(r.text))
            if "Ticker" not in df.columns:
                log.warning(f"FINVIZ view {view_id}: no Ticker column")
                return None
            df["Ticker"] = df["Ticker"].str.upper().str.strip()
            return df.set_index("Ticker")
        except Exception as e:
            log.warning(f"FINVIZ view {view_id}: {e}")
            return None

    # Fetch all 5 views in parallel
    frames: dict[str, pd.DataFrame | None] = {}
    with ThreadPoolExecutor(max_workers=5) as ex:
        futs = {ex.submit(_fetch_view, vid): name for name, vid in _FINVIZ_VIEWS.items()}
        for fut in as_completed(futs):
            name = futs[fut]
            frames[name] = fut.result()

    # Column mappings per view
    _col_map: dict[str, dict[str, str]] = {
        "valuation": {
            "EPS Growth This Year": "eps_growth_this_yr",
            "EPS Growth Next Year": "eps_growth_next_yr",
            "PEG":                  "peg",
            "Forward P/E":          "fwd_pe",
            "P/S":                  "ps",
        },
        "ownership": {
            "Shares Float":          "shares_float",
            "Short Float":           "short_float_pct",
            "Short Ratio":           "short_ratio",
            "Insider Ownership":     "insider_own_pct",
            "Institutional Ownership": "inst_own_pct",
        },
        "performance": {
            "Relative Volume":       "rel_volume",
            "Average Volume":        "avg_volume",
            "Performance (Week)":    "perf_week_pct",
            "Performance (Month)":   "perf_month_pct",
            "Volatility (Week)":     "volatility_w_pct",
        },
        "financial": {
            "Return on Equity":      "roe_pct",
            "Return on Assets":      "roa_pct",
            "Gross Margin":          "gross_margin_pct",
            "Operating Margin":      "oper_margin_pct",
            "Profit Margin":         "profit_margin_pct",
            "Current Ratio":         "current_ratio",
            "Earnings Date":         "earnings_date",
        },
        "technical": {
            "Beta":                  "beta",
            "Average True Range":    "atr",
            "Relative Strength Index (14)": "rsi14",
            "52-Week High":          "high_52w",
            "52-Week Low":           "low_52w",
            "20-Day Simple Moving Average": "sma20_pct",
            "50-Day Simple Moving Average": "sma50_pct",
            "200-Day Simple Moving Average": "sma200_pct",
        },
    }

    # Merge all views into one dict keyed by ticker
    merged: dict[str, dict] = {}
    for view_name, df in frames.items():
        if df is None:
            continue
        col_map = _col_map.get(view_name, {})
        for ticker, row in df.iterrows():
            if ticker not in merged:
                merged[ticker] = {}
            for src_col, dst_col in col_map.items():
                # Try exact column name first; FINVIZ may add spaces
                val = row.get(src_col)
                if val is None:
                    # Try case-insensitive partial match
                    for c in df.columns:
                        if src_col.lower() in c.lower():
                            val = row.get(c)
                            break
                if val is not None and str(val).strip() not in ("-", "N/A", ""):
                    merged[ticker][dst_col] = str(val).strip()

    # Parse numeric types
    pct_fields = {
        "eps_growth_this_yr", "eps_growth_next_yr", "short_float_pct",
        "insider_own_pct", "inst_own_pct", "perf_week_pct", "perf_month_pct",
        "volatility_w_pct", "roe_pct", "roa_pct", "gross_margin_pct",
        "oper_margin_pct", "profit_margin_pct", "sma20_pct", "sma50_pct", "sma200_pct",
    }
    float_fields = {
        "peg", "fwd_pe", "ps", "shares_float", "short_ratio", "rel_volume",
        "avg_volume", "current_ratio", "beta", "atr", "rsi14", "high_52w", "low_52w",
    }
    for ticker, data in merged.items():
        for f in pct_fields:
            if f in data:
                data[f] = _finviz_pct(data[f])
        for f in float_fields:
            if f in data:
                data[f] = _finviz_float(data[f])

    if merged:
        _cache_write(cache_key, merged)
        log.info(f"FINVIZ bulk: fetched {len(merged)} tickers across {len(frames)} views")
    return merged


def get_finviz_news() -> list[dict]:
    """
    Fetch latest market news from FINVIZ Elite news export.
    Returns list of dicts with keys: title, source, date, url, category.
    Cache TTL: 30 minutes.
    """
    cache_key = "finviz_news"
    cached = _cache_read(cache_key, ttl_seconds=1800)
    if cached:
        return cached

    token = _finviz_token()
    if not token:
        return []

    try:
        url = f"{_FINVIZ_BASE}/news_export.ashx"
        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Referer": "https://elite.finviz.com/news.ashx",
        }
        r = requests.get(url, params={"v": 1, "auth": token}, headers=headers, timeout=15)
        if r.status_code != 200:
            log.warning(f"FINVIZ news: HTTP {r.status_code}")
            return []

        from io import StringIO
        df = pd.read_csv(StringIO(r.text))
        articles = []
        for _, row in df.iterrows():
            articles.append({
                "title":    str(row.get("Title", "")),
                "source":   str(row.get("Source", "")),
                "date":     str(row.get("Date", "")),
                "url":      str(row.get("Url", "")),
                "category": str(row.get("Category", "")),
            })
        _cache_write(cache_key, articles)
        log.info(f"FINVIZ news: fetched {len(articles)} articles")
        return articles
    except Exception as e:
        log.warning(f"FINVIZ news: {e}")
        return []


def get_finviz_options(ticker: str, expiry: str) -> dict:
    """
    Fetch options chain from FINVIZ Elite for a given ticker and expiry.
    expiry format: 'YYYY-MM-DD'
    Returns: {"calls": [...], "puts": [...]} each item has strike, iv, delta, gamma, theta, vega, oi, volume.
    """
    cache_key = f"finviz_opts_{ticker}_{expiry}"
    cached = _cache_read(cache_key, ttl_seconds=3600)
    if cached:
        return cached

    token = _finviz_token()
    if not token:
        return {"calls": [], "puts": []}

    try:
        url = f"{_FINVIZ_BASE}/export/options"
        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Referer": f"https://elite.finviz.com/quote.ashx?t={ticker}",
        }
        r = requests.get(url, params={"t": ticker, "ty": "oc", "e": expiry, "auth": token},
                         headers=headers, timeout=15)
        if r.status_code != 200:
            log.warning(f"FINVIZ options {ticker} {expiry}: HTTP {r.status_code}")
            return {"calls": [], "puts": []}

        from io import StringIO
        df = pd.read_csv(StringIO(r.text))
        if df.empty:
            return {"calls": [], "puts": []}

        def _parse_chain(side: str) -> list[dict]:
            sub = df[df.get("Type", pd.Series()).str.upper() == side.upper()] if "Type" in df.columns else df
            out = []
            for _, row in sub.iterrows():
                out.append({
                    "strike":  _finviz_float(str(row.get("Strike", ""))),
                    "iv":      _finviz_pct(str(row.get("Implied Volatility", ""))),
                    "delta":   _finviz_float(str(row.get("Delta", ""))),
                    "gamma":   _finviz_float(str(row.get("Gamma", ""))),
                    "theta":   _finviz_float(str(row.get("Theta", ""))),
                    "vega":    _finviz_float(str(row.get("Vega", ""))),
                    "oi":      _finviz_float(str(row.get("Open Interest", ""))),
                    "volume":  _finviz_float(str(row.get("Volume", ""))),
                })
            return out

        result = {"calls": _parse_chain("call"), "puts": _parse_chain("put")}
        _cache_write(cache_key, result)
        return result
    except Exception as e:
        log.warning(f"FINVIZ options {ticker}: {e}")
        return {"calls": [], "puts": []}


def get_finviz_quote(ticker: str) -> pd.DataFrame | None:
    """
    Fetch daily OHLCV history from FINVIZ Elite as a yfinance-compatible DataFrame.
    Returns DataFrame with columns [Open, High, Low, Close, Volume] indexed by Date,
    or None on failure. Can be used as fallback if yfinance is unavailable.
    Cache TTL: 24 hours.
    """
    cache_key = f"finviz_quote_{ticker}"
    cached = _cache_read(cache_key, ttl_seconds=86400)
    if cached:
        try:
            df = pd.DataFrame(cached)
            df["Date"] = pd.to_datetime(df["Date"])
            return df.set_index("Date")
        except Exception:
            pass

    token = _finviz_token()
    if not token:
        return None

    try:
        url = f"{_FINVIZ_BASE}/quote_export.ashx"
        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Referer": f"https://elite.finviz.com/quote.ashx?t={ticker}",
        }
        r = requests.get(url, params={"t": ticker, "p": "d", "auth": token},
                         headers=headers, timeout=15)
        if r.status_code != 200:
            log.warning(f"FINVIZ quote {ticker}: HTTP {r.status_code}")
            return None

        from io import StringIO
        df = pd.read_csv(StringIO(r.text), parse_dates=["Date"])
        if df.empty or "Close" not in df.columns:
            return None

        df = df.sort_values("Date").set_index("Date")
        # Cache as serializable list of records
        _cache_write(cache_key, df.reset_index().assign(Date=df.reset_index()["Date"].astype(str)).to_dict("records"))
        return df
    except Exception as e:
        log.warning(f"FINVIZ quote {ticker}: {e}")
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# POLYGON.IO INTEGRATION
# REST API key stored in config["data_sources"]["polygon_api_key"]
# ═══════════════════════════════════════════════════════════════════════════════

_POLYGON_BASE = "https://api.polygon.io"


def _polygon_key() -> str:
    try:
        from secrets_loader import polygon_key as _pk
        return _pk()
    except Exception:
        return load_config().get("data_sources", {}).get("polygon_api_key", "")


def _polygon_get(path: str, params: dict | None = None, timeout: int = 15) -> dict | None:
    """Single authenticated GET to Polygon REST API. Returns parsed JSON or None."""
    key = _polygon_key()
    if not key:
        return None
    p = {"apiKey": key, **(params or {})}
    try:
        r = requests.get(f"{_POLYGON_BASE}{path}", params=p, timeout=timeout)
        if r.status_code == 200:
            return r.json()
        # 403 on I:VIX/index tickers is expected on Starter plan — demote to debug
        lvl = log.debug if r.status_code == 403 else log.warning
        lvl(f"Polygon {path}: HTTP {r.status_code}")
    except Exception as e:
        log.warning(f"Polygon {path}: {e}")
    return None


_FAILOVER_COUNTS = {"polygon": 0, "archive": 0, "yfinance": 0, "failed": 0}


def failover_counts() -> dict:
    """Return the current vendor-failover counters (reset via reset_failover_counts())."""
    return dict(_FAILOVER_COUNTS)


def reset_failover_counts() -> None:
    for k in _FAILOVER_COUNTS:
        _FAILOVER_COUNTS[k] = 0


def fetch_ohlcv_with_failover(ticker: str, days: int = 400) -> tuple[pd.DataFrame | None, str]:
    """AI-35: Vendor failover chain — Polygon → archive → yfinance.

    Returns (df, tier_used). tier ∈ {"polygon","archive","yfinance","failed"}.
    Updates module-level _FAILOVER_COUNTS for end-of-scan summary.

    Caching is preserved at each layer (Polygon has its own cache key; archive
    is already parquet-backed; yfinance adds a simple download with prepost=False).
    """
    # 1) Polygon (primary) — skipped in degraded mode to avoid cascading network errors
    if not _DEGRADED_MODE:
        try:
            df = get_polygon_ohlcv(ticker, days=days, timespan="day", multiplier=1)
            if df is not None and len(df) >= 20:
                _FAILOVER_COUNTS["polygon"] += 1
                return df, "polygon"
        except Exception as e:
            log.debug(f"[failover] {ticker}: polygon error — {e}")
    else:
        log.debug(f"[failover] {ticker}: skipping polygon (degraded mode)")

    # 2) Archive (local parquet)
    try:
        archive_path = BASE_DIR / "data" / "ohlcv" / f"{ticker}.parquet"
        if archive_path.exists():
            df = pd.read_parquet(archive_path)
            if df is not None and len(df) >= 20:
                _FAILOVER_COUNTS["archive"] += 1
                log.info(f"  [failover] {ticker}: archive fallback (polygon empty/failed)")
                return df, "archive"
    except Exception as e:
        log.debug(f"[failover] {ticker}: archive error — {e}")

    # 3) yfinance (last resort)
    try:
        raw = yf.download(ticker, period=f"{min(days,365*2)}d", interval="1d",
                          progress=False, auto_adjust=True)
        if raw is not None and not raw.empty and len(raw) >= 20:
            # Normalize columns to match Polygon shape
            if hasattr(raw.columns, "get_level_values"):
                raw.columns = raw.columns.get_level_values(0) if raw.columns.nlevels > 1 else raw.columns
            _FAILOVER_COUNTS["yfinance"] += 1
            log.info(f"  [failover] {ticker}: yfinance fallback (polygon+archive empty)")
            return raw, "yfinance"
    except Exception as e:
        log.debug(f"[failover] {ticker}: yfinance error — {e}")

    _FAILOVER_COUNTS["failed"] += 1
    return None, "failed"


def get_polygon_ohlcv(
    ticker: str,
    days: int = 365,
    timespan: str = "day",   # "day" | "minute" | "hour"
    multiplier: int = 1,
) -> pd.DataFrame | None:
    """
    Fetch OHLCV bars from Polygon.io.

    Returns a DataFrame with columns [Open, High, Low, Close, Volume, VWAP, Transactions]
    indexed by date (for day bars) or datetime (for intraday).
    Results are cached: 24h for daily, 30min for intraday.
    """
    from datetime import date, timedelta as td
    cache_ttl = 86400 if timespan == "day" else 1800
    today = date.today().isoformat()
    date_from = (date.today() - td(days=days)).isoformat()
    cache_key = f"polygon_{timespan}_{multiplier}_{ticker}_{today}_{days}"

    cached = _cache_read(cache_key, cache_ttl)
    if cached is not None:
        try:
            df = pd.DataFrame(cached)
            df["t"] = pd.to_datetime(df["t"], unit="ms", utc=True).dt.tz_convert("America/New_York")
            df = df.set_index("t").rename(columns={
                "o": "Open", "h": "High", "l": "Low", "c": "Close",
                "v": "Volume", "vw": "VWAP", "n": "Transactions"
            })
            return df
        except Exception:
            pass

    path = f"/v2/aggs/ticker/{ticker}/range/{multiplier}/{timespan}/{date_from}/{today}"
    data = _polygon_get(path, params={"adjusted": "true", "sort": "asc", "limit": 50000})
    if not data or not data.get("results"):
        return None

    results = data["results"]
    _cache_write(cache_key, results)

    df = pd.DataFrame(results)
    df["t"] = pd.to_datetime(df["t"], unit="ms", utc=True).dt.tz_convert("America/New_York")
    df = df.set_index("t").rename(columns={
        "o": "Open", "h": "High", "l": "Low", "c": "Close",
        "v": "Volume", "vw": "VWAP", "n": "Transactions"
    })
    return df


def get_polygon_snapshot(tickers: list[str]) -> dict[str, dict]:
    """
    Bulk snapshot: get current price, day change, prev close, VWAP for up to 250 tickers.
    Returns {ticker: {price, change_pct, prev_close, volume, vwap, ...}}
    Cached for 5 minutes.
    """
    if not tickers:
        return {}

    cache_key = f"polygon_snap_{'_'.join(sorted(tickers)[:10])}_{int(time.time()//300)}"
    cached = _cache_read(cache_key, 300)
    if cached is not None:
        return cached

    # Polygon supports comma-separated tickers (max 250)
    chunks = [tickers[i:i+250] for i in range(0, len(tickers), 250)]
    result: dict[str, dict] = {}

    for chunk in chunks:
        # In degraded mode, skip live snapshot calls entirely
        if _DEGRADED_MODE:
            log.debug(f"Skipping snapshot batch of {len(chunk)} tickers (degraded mode)")
            continue
        # Retry batch call with exponential backoff (max ~14s sleep total)
        data = _retry_batch_call(
            _polygon_get,
            args=("/v2/snapshot/locale/us/markets/stocks/tickers",),
            kwargs={"params": {"tickers": ",".join(chunk)}},
            max_retries=3,
            base_delay=2,
            label=f"Polygon snapshot batch ({len(chunk)} tickers)",
        )
        if not data or not data.get("tickers"):
            continue
        for snap in data["tickers"]:
            t = snap.get("ticker", "")
            day = snap.get("day", {})
            prev = snap.get("prevDay", {})
            result[t] = {
                "price":       snap.get("lastTrade", {}).get("p") or day.get("c"),
                "change_pct":  snap.get("todaysChangePerc"),
                "change_abs":  snap.get("todaysChange"),
                "prev_close":  prev.get("c"),
                "volume":      day.get("v"),
                "vwap":        day.get("vw"),
                "open":        day.get("o"),
                "high":        day.get("h"),
                "low":         day.get("l"),
                "close":       day.get("c"),
            }

    _cache_write(cache_key, result)
    return result


def get_polygon_news(ticker: str, limit: int = 10) -> list[dict]:
    """
    Fetch recent news for a ticker from Polygon.io.
    Returns list of {title, source, published_utc, article_url, sentiment}.
    Cached 30 minutes.
    """
    cache_key = f"polygon_news_{ticker}_{int(time.time()//1800)}"
    cached = _cache_read(cache_key, 1800)
    if cached is not None:
        return cached

    data = _polygon_get("/v2/reference/news", params={"ticker": ticker, "limit": limit, "order": "desc"})
    if not data or not data.get("results"):
        return []

    articles = []
    for a in data["results"]:
        # Polygon provides insights with sentiment per ticker
        sentiment = None
        for ins in a.get("insights", []):
            if ins.get("ticker") == ticker:
                sentiment = ins.get("sentiment")  # "positive"|"negative"|"neutral"
                break
        articles.append({
            "title":         a.get("title", ""),
            "source":        a.get("publisher", {}).get("name", ""),
            "published_utc": a.get("published_utc", ""),
            "url":           a.get("article_url", ""),
            "sentiment":     sentiment,
        })

    _cache_write(cache_key, articles)
    return articles


def get_polygon_options_chain(ticker: str, expiry: str | None = None) -> dict:
    """
    Fetch options chain snapshot for a ticker (nearest expiry by default).
    Returns {"calls": [...], "puts": [...], "expiries": [...]}
    Each contract: {strike, expiry, iv, delta, gamma, theta, vega, oi, volume, last}
    Cached 1 hour.
    """
    cache_key = f"polygon_opts_{ticker}_{expiry or 'nearest'}_{int(time.time()//3600)}"
    cached = _cache_read(cache_key, 3600)
    if cached is not None:
        return cached

    params: dict = {
        "underlying_asset": ticker,
        "limit": 250,
        "sort": "strike_price",
        "order": "asc",
        "contract_type": "call",
    }
    if expiry:
        params["expiration_date"] = expiry

    calls_raw = _polygon_get("/v3/snapshot/options/" + ticker, params={
        "limit": 250, "sort": "strike_price", "order": "asc"
    }) or {}

    contracts = calls_raw.get("results", [])
    if not contracts:
        return {"calls": [], "puts": [], "expiries": []}

    # Collect unique expiries
    expiries = sorted({c.get("details", {}).get("expiration_date", "") for c in contracts if c.get("details", {}).get("expiration_date")})

    calls, puts = [], []
    for c in contracts:
        det = c.get("details", {})
        greeks = c.get("greeks", {})
        day = c.get("day", {})
        row = {
            "strike":  det.get("strike_price"),
            "expiry":  det.get("expiration_date"),
            "type":    det.get("contract_type"),
            "iv":      c.get("implied_volatility"),
            "delta":   greeks.get("delta"),
            "gamma":   greeks.get("gamma"),
            "theta":   greeks.get("theta"),
            "vega":    greeks.get("vega"),
            "oi":      c.get("open_interest"),
            "volume":  day.get("volume"),
            "last":    day.get("close") or day.get("last"),
        }
        if det.get("contract_type") == "call":
            calls.append(row)
        else:
            puts.append(row)

    result = {"calls": calls, "puts": puts, "expiries": expiries}
    _cache_write(cache_key, result)
    return result


def get_polygon_technicals(ticker: str) -> dict:
    """
    Fetch EMAs (8, 21, 50, 200), RSI(14), and MACD from Polygon indicators API.
    Returns {ema8, ema21, ema50, ema200, rsi14, macd_val, macd_signal, macd_hist}
    Cached 1 hour.
    """
    cache_key = f"polygon_tech_{ticker}_{int(time.time()//3600)}"
    cached = _cache_read(cache_key, 3600)
    if cached is not None:
        return cached

    result: dict = {}

    def _ema(period: int) -> float | None:
        d = _polygon_get(f"/v1/indicators/ema/{ticker}", params={"timespan": "day", "window": period, "series_type": "close", "limit": 1})
        v = (d or {}).get("results", {}).get("values", [{}])
        return v[0].get("value") if v else None

    def _rsi() -> float | None:
        d = _polygon_get(f"/v1/indicators/rsi/{ticker}", params={"timespan": "day", "window": 14, "series_type": "close", "limit": 1})
        v = (d or {}).get("results", {}).get("values", [{}])
        return v[0].get("value") if v else None

    def _macd() -> tuple:
        d = _polygon_get(f"/v1/indicators/macd/{ticker}", params={"timespan": "day", "short_window": 12, "long_window": 26, "signal_window": 9, "series_type": "close", "limit": 1})
        vals = (d or {}).get("results", {}).get("values", [{}])
        if vals:
            return vals[0].get("value"), vals[0].get("signal"), vals[0].get("histogram")
        return None, None, None

    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
        f_e8   = ex.submit(_ema, 8)
        f_e21  = ex.submit(_ema, 21)
        f_e50  = ex.submit(_ema, 50)
        f_e200 = ex.submit(_ema, 200)
        f_rsi  = ex.submit(_rsi)
        f_macd = ex.submit(_macd)

        result["ema8"]        = f_e8.result()
        result["ema21"]       = f_e21.result()
        result["ema50"]       = f_e50.result()
        result["ema200"]      = f_e200.result()
        result["rsi14"]       = f_rsi.result()
        mv, ms, mh            = f_macd.result()
        result["macd_val"]    = mv
        result["macd_signal"] = ms
        result["macd_hist"]   = mh

    _cache_write(cache_key, result)
    return result


def get_polygon_multi_timeframe(ticker: str) -> dict:
    """
    Fetch 1H, 4H, Daily, Weekly OHLCV for the Timeframes tab.
    Returns {"1H": df, "4H": df, "Daily": df, "Weekly": df}
    """
    cache_key = f"polygon_mtf_{ticker}_{int(time.time()//1800)}"
    cached = _cache_read(cache_key, 1800)
    if cached is not None:
        # Deserialise
        out = {}
        for tf, recs in cached.items():
            if recs:
                df = pd.DataFrame(recs)
                df["t"] = pd.to_datetime(df["t"], unit="ms", utc=True).dt.tz_convert("America/New_York")
                out[tf] = df.set_index("t").rename(columns={"o":"Open","h":"High","l":"Low","c":"Close","v":"Volume","vw":"VWAP"})
        return out

    import concurrent.futures
    configs = {
        "1H":     (1, "hour",  30),
        "4H":     (4, "hour",  60),
        "Daily":  (1, "day",  180),
        "Weekly": (1, "week", 365),
    }

    raw: dict = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        futures = {ex.submit(get_polygon_ohlcv, ticker, days=d, timespan=ts, multiplier=m): tf
                   for tf, (m, ts, d) in configs.items()}
        for f, tf in futures.items():
            try:
                raw[tf] = f.result()
            except Exception:
                raw[tf] = None

    # Serialise for cache
    serial = {}
    out = {}
    for tf, df in raw.items():
        if df is not None:
            records = df.reset_index().assign(t=lambda d: d["t"].astype("int64") // 10**6).to_dict("records")
            serial[tf] = records
            out[tf] = df
        else:
            serial[tf] = []
            out[tf] = None

    _cache_write(cache_key, serial)
    return out
