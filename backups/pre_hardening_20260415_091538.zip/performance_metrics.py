"""Performance analytics module for the swing-trade dashboard Performance Tab."""

from __future__ import annotations

import statistics
from datetime import date, datetime
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _closed(trades: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Return only closed trades (have exit_date and pnl_dollar)."""
    out = []
    for t in trades or []:
        if t.get("exit_date") and t.get("pnl_dollar") is not None:
            out.append(t)
    return out


def _parse_date(s: Any) -> Optional[date]:
    """Parse an ISO date string into a date, or return None."""
    if s is None:
        return None
    if isinstance(s, (datetime,)):
        return s.date()
    if isinstance(s, date):
        return s
    try:
        return datetime.fromisoformat(str(s)[:10]).date()
    except Exception:
        return None


def _sorted_by_exit(trades: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Sort closed trades by exit_date ascending."""
    return sorted(
        _closed(trades),
        key=lambda t: _parse_date(t.get("exit_date")) or date.min,
    )


def _pct_color(pct: float) -> str:
    """Map pnl pct to a hex color (red/green gradient)."""
    if pct is None or np.isnan(pct):
        return "#cccccc"
    clamped = max(-20.0, min(20.0, float(pct)))
    intensity = int(min(255, abs(clamped) / 20.0 * 200 + 40))
    if clamped >= 0:
        return f"#{0:02x}{intensity:02x}{0:02x}"
    return f"#{intensity:02x}{0:02x}{0:02x}"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def compute_equity_curve(
    trades: List[Dict[str, Any]], starting_equity: float = 5000
) -> List[Dict[str, Any]]:
    """Return equity curve as list of {date, equity, pnl_cumulative} sorted by exit_date."""
    closed = _sorted_by_exit(trades)
    out: List[Dict[str, Any]] = []
    equity = float(starting_equity)
    cum = 0.0
    for t in closed:
        pnl = float(t.get("pnl_dollar") or 0.0)
        equity += pnl
        cum += pnl
        d = _parse_date(t.get("exit_date"))
        out.append(
            {
                "date": d.isoformat() if d else None,
                "equity": round(equity, 2),
                "pnl_cumulative": round(cum, 2),
            }
        )
    return out


def compute_drawdown_stats(equity_curve: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compute max/current drawdown and average recovery days from an equity curve."""
    if not equity_curve:
        return {
            "max_dd_pct": 0.0,
            "max_dd_dates": (None, None),
            "current_dd_pct": 0.0,
            "days_in_current_dd": 0,
            "avg_recovery_days": 0.0,
        }

    eq = [float(p["equity"]) for p in equity_curve]
    dates = [_parse_date(p["date"]) for p in equity_curve]
    peak = eq[0]
    peak_date = dates[0]
    max_dd = 0.0
    max_peak_d: Optional[date] = None
    max_trough_d: Optional[date] = None

    recoveries: List[int] = []
    in_dd = False
    dd_peak_eq = peak
    dd_peak_date = peak_date

    for i, e in enumerate(eq):
        if e > peak:
            peak = e
            peak_date = dates[i]
            if in_dd:
                if dd_peak_date and dates[i]:
                    recoveries.append((dates[i] - dd_peak_date).days)
                in_dd = False
        dd = (e - peak) / peak * 100.0 if peak else 0.0
        if dd < max_dd:
            max_dd = dd
            max_peak_d = peak_date
            max_trough_d = dates[i]
        if e < peak and not in_dd:
            in_dd = True
            dd_peak_eq = peak
            dd_peak_date = peak_date

    current_dd = (eq[-1] - peak) / peak * 100.0 if peak else 0.0
    days_in_current_dd = 0
    if current_dd < 0 and peak_date and dates[-1]:
        days_in_current_dd = (dates[-1] - peak_date).days

    avg_recovery = float(np.mean(recoveries)) if recoveries else 0.0

    return {
        "max_dd_pct": round(max_dd, 2),
        "max_dd_dates": (
            max_peak_d.isoformat() if max_peak_d else None,
            max_trough_d.isoformat() if max_trough_d else None,
        ),
        "current_dd_pct": round(current_dd, 2),
        "days_in_current_dd": int(days_in_current_dd),
        "avg_recovery_days": round(avg_recovery, 1),
    }


def compute_risk_metrics(
    equity_curve: List[Dict[str, Any]],
    daily_returns: Optional[List[float]] = None,
) -> Dict[str, Any]:
    """Compute Sharpe, Sortino, Calmar and daily-return stats (rf=0, annualized)."""
    zero = {
        "sharpe_ann": 0.0,
        "sortino_ann": 0.0,
        "calmar": 0.0,
        "avg_daily_return": 0.0,
        "std_daily_return": 0.0,
    }
    if daily_returns is None:
        if len(equity_curve) < 2:
            return zero
        eq = np.array([float(p["equity"]) for p in equity_curve], dtype=float)
        daily_returns = list(np.diff(eq) / eq[:-1])

    if not daily_returns:
        return zero

    arr = np.array(daily_returns, dtype=float)
    avg = float(np.mean(arr))
    std = float(np.std(arr, ddof=1)) if len(arr) > 1 else 0.0
    downside = arr[arr < 0]
    d_std = float(np.std(downside, ddof=1)) if len(downside) > 1 else 0.0

    sharpe = float(avg / std * np.sqrt(252)) if std > 0 else 0.0
    sortino = float(avg / d_std * np.sqrt(252)) if d_std > 0 else 0.0

    calmar = 0.0
    if equity_curve:
        dd = compute_drawdown_stats(equity_curve)
        max_dd = abs(dd["max_dd_pct"]) / 100.0
        ann_return = avg * 252
        calmar = (ann_return / max_dd) if max_dd > 0 else 0.0

    return {
        "sharpe_ann": round(sharpe, 3),
        "sortino_ann": round(sortino, 3),
        "calmar": round(calmar, 3),
        "avg_daily_return": round(avg, 5),
        "std_daily_return": round(std, 5),
    }


def compute_regime_attribution(trades: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Group closed trades by regime and compute per-regime WR, avg pct and profit factor."""
    closed = _closed(trades)
    if not closed:
        return []

    groups: Dict[str, List[Dict[str, Any]]] = {}
    for t in closed:
        groups.setdefault(t.get("regime") or "unknown", []).append(t)

    out: List[Dict[str, Any]] = []
    for regime, ts in groups.items():
        n = len(ts)
        wins = sum(1 for t in ts if t.get("win") or (t.get("pnl_dollar") or 0) > 0)
        losses = n - wins
        wr = wins / n if n else 0.0
        avg_pct = float(np.mean([float(t.get("pnl_pct") or 0.0) for t in ts]))
        gross_win = sum(float(t.get("pnl_dollar") or 0.0) for t in ts if (t.get("pnl_dollar") or 0) > 0)
        gross_loss = abs(sum(float(t.get("pnl_dollar") or 0.0) for t in ts if (t.get("pnl_dollar") or 0) < 0))
        pf = (gross_win / gross_loss) if gross_loss > 0 else (float("inf") if gross_win > 0 else 0.0)
        out.append(
            {
                "regime": regime,
                "n": n,
                "wins": wins,
                "losses": losses,
                "wr": round(wr, 4),
                "avg_pct": round(avg_pct, 2),
                "pf": round(pf, 3) if pf != float("inf") else None,
            }
        )
    out.sort(key=lambda r: r["n"], reverse=True)
    return out


def compute_hold_period_stats(trades: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Group closed trades by setup_family and compute hold-period stats."""
    closed = _closed(trades)
    if not closed:
        return []
    groups: Dict[str, List[int]] = {}
    for t in closed:
        d = t.get("days_held")
        if d is None:
            continue
        groups.setdefault(t.get("setup_family") or "unknown", []).append(int(d))
    out: List[Dict[str, Any]] = []
    for fam, days in groups.items():
        if not days:
            continue
        out.append(
            {
                "setup_family": fam,
                "avg_days": round(float(np.mean(days)), 2),
                "min_days": int(min(days)),
                "max_days": int(max(days)),
                "median_days": round(float(statistics.median(days)), 2),
                "n": len(days),
            }
        )
    out.sort(key=lambda r: r["n"], reverse=True)
    return out


def compute_time_of_day_stats(trades: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Bucket entries by ET time and compute WR / avg pct per bucket."""
    buckets = {
        "9:30-10:30 ET": [],
        "10:30-15:00 ET": [],
        "15:00-16:00 ET": [],
    }
    for t in _closed(trades):
        et = t.get("entry_time")
        if not et:
            continue
        try:
            hh, mm = str(et).split(":")[:2]
            minutes = int(hh) * 60 + int(mm)
        except Exception:
            continue
        if 9 * 60 + 30 <= minutes < 10 * 60 + 30:
            buckets["9:30-10:30 ET"].append(t)
        elif 10 * 60 + 30 <= minutes < 15 * 60:
            buckets["10:30-15:00 ET"].append(t)
        elif 15 * 60 <= minutes < 16 * 60:
            buckets["15:00-16:00 ET"].append(t)

    out: List[Dict[str, Any]] = []
    for label, ts in buckets.items():
        n = len(ts)
        wr = (sum(1 for t in ts if t.get("win") or (t.get("pnl_dollar") or 0) > 0) / n) if n else 0.0
        avg_pct = float(np.mean([float(t.get("pnl_pct") or 0.0) for t in ts])) if n else 0.0
        out.append(
            {
                "bucket": label,
                "n": n,
                "wr": round(wr, 4),
                "avg_pct": round(avg_pct, 2),
            }
        )
    return out


def _failure_reason(t: Dict[str, Any]) -> str:
    """Heuristically infer a failure reason from trade fields."""
    exit_reason = (t.get("exit_reason") or "").lower()
    if "stop" in exit_reason or "sl" in exit_reason:
        if t.get("rvol") is not None and float(t.get("rvol") or 0) < 1.0:
            return "low RVOL"
    if "gap" in exit_reason:
        return "gap down"
    if "earnings" in exit_reason or any(
        "earnings" in str(c).lower() for c in (t.get("catalyst_tags") or [])
    ):
        return "earnings miss"
    if "regime" in exit_reason or "flip" in exit_reason:
        return "regime flip during hold"
    if t.get("rvol") is not None and float(t.get("rvol") or 0) < 1.0:
        return "low RVOL"
    return "adverse price action"


def compute_worst_trades(
    trades: List[Dict[str, Any]], n: int = 5
) -> List[Dict[str, Any]]:
    """Return the worst n closed trades by pnl_pct with an inferred failure reason."""
    closed = _closed(trades)
    if not closed:
        return []
    sorted_t = sorted(closed, key=lambda t: float(t.get("pnl_pct") or 0.0))
    out: List[Dict[str, Any]] = []
    for t in sorted_t[:n]:
        out.append(
            {
                "ticker": t.get("ticker"),
                "entry_date": t.get("entry_date"),
                "exit_date": t.get("exit_date"),
                "entry_price": t.get("entry_price"),
                "exit_price": t.get("exit_price"),
                "pnl_pct": round(float(t.get("pnl_pct") or 0.0), 2),
                "setup_type": t.get("setup_type"),
                "regime": t.get("regime"),
                "failure_reason": _failure_reason(t),
            }
        )
    return out


def _size_rec(wr: float, expectancy: float) -> str:
    """Map WR and expectancy to a position-size recommendation."""
    if wr >= 0.70 and expectancy >= 0.3:
        return "full"
    if wr >= 0.60 and expectancy >= 0.15:
        return "75%"
    if wr >= 0.50 and expectancy >= 0.0:
        return "50%"
    return "reduce bar"


def compute_score_bucket_stats(trades: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Bucket closed trades by score and compute WR, avg pct, expectancy and size rec."""
    closed = _closed(trades)
    buckets: List[Tuple[str, float, float]] = [
        ("85+", 85.0, float("inf")),
        ("75-84", 75.0, 85.0),
        ("65-74", 65.0, 75.0),
        ("55-64", 55.0, 65.0),
        ("<55", float("-inf"), 55.0),
    ]
    out: List[Dict[str, Any]] = []
    for label, lo, hi in buckets:
        ts = [t for t in closed if t.get("score") is not None and lo <= float(t["score"]) < hi]
        n = len(ts)
        if n == 0:
            out.append(
                {
                    "bucket_label": label,
                    "n": 0,
                    "wr": 0.0,
                    "avg_pct": 0.0,
                    "expectancy_per_dollar": 0.0,
                    "size_recommendation": "reduce bar",
                }
            )
            continue
        wins = [t for t in ts if t.get("win") or (t.get("pnl_dollar") or 0) > 0]
        losses = [t for t in ts if t not in wins]
        wr = len(wins) / n
        avg_pct = float(np.mean([float(t.get("pnl_pct") or 0.0) for t in ts]))
        avg_win = float(np.mean([float(t.get("pnl_dollar") or 0.0) for t in wins])) if wins else 0.0
        avg_loss_amt = (
            float(np.mean([abs(float(t.get("pnl_dollar") or 0.0)) for t in losses])) if losses else 0.0
        )
        expectancy = (
            (wr * avg_win - (1 - wr) * avg_loss_amt) / avg_loss_amt if avg_loss_amt > 0 else 0.0
        )
        out.append(
            {
                "bucket_label": label,
                "n": n,
                "wr": round(wr, 4),
                "avg_pct": round(avg_pct, 2),
                "expectancy_per_dollar": round(expectancy, 3),
                "size_recommendation": _size_rec(wr, expectancy),
            }
        )
    return out


def compute_monthly_pnl_heatmap(trades: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Build a monthly PnL% heatmap payload with years, months and per-cell color."""
    closed = _closed(trades)
    if not closed:
        return {"years": [], "months": []}
    rows = []
    for t in closed:
        d = _parse_date(t.get("exit_date"))
        if not d:
            continue
        rows.append({"year": d.year, "month": d.month, "pct": float(t.get("pnl_pct") or 0.0)})
    if not rows:
        return {"years": [], "months": []}
    df = pd.DataFrame(rows)
    agg = df.groupby(["year", "month"])["pct"].sum().reset_index()
    years = sorted(df["year"].unique().tolist())
    months: List[Dict[str, Any]] = []
    for _, r in agg.iterrows():
        pct = float(r["pct"])
        months.append(
            {
                "year": int(r["year"]),
                "month": int(r["month"]),
                "pnl_pct": round(pct, 2),
                "color": _pct_color(pct),
            }
        )
    return {"years": years, "months": months}


def compute_streak(trades: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compute current and longest win/loss streaks chronologically."""
    closed = _sorted_by_exit(trades)
    if not closed:
        return {
            "current_streak": 0,
            "streak_type": "W",
            "longest_win_streak": 0,
            "longest_loss_streak": 0,
        }
    results = [bool(t.get("win")) or (float(t.get("pnl_dollar") or 0.0) > 0) for t in closed]
    longest_w = longest_l = 0
    cur_w = cur_l = 0
    for r in results:
        if r:
            cur_w += 1
            cur_l = 0
            longest_w = max(longest_w, cur_w)
        else:
            cur_l += 1
            cur_w = 0
            longest_l = max(longest_l, cur_l)
    if results[-1]:
        current_streak = cur_w
        streak_type = "W"
    else:
        current_streak = cur_l
        streak_type = "L"
    return {
        "current_streak": int(current_streak),
        "streak_type": streak_type,
        "longest_win_streak": int(longest_w),
        "longest_loss_streak": int(longest_l),
    }


def compute_expectancy(trades: List[Dict[str, Any]]) -> float:
    """Compute dollar-weighted expectancy per $1 risked across closed trades."""
    closed = _closed(trades)
    if not closed:
        return 0.0
    wins = [float(t.get("pnl_dollar") or 0.0) for t in closed if (t.get("pnl_dollar") or 0) > 0]
    losses = [abs(float(t.get("pnl_dollar") or 0.0)) for t in closed if (t.get("pnl_dollar") or 0) < 0]
    n = len(closed)
    wr = len(wins) / n if n else 0.0
    avg_win = float(np.mean(wins)) if wins else 0.0
    avg_loss = float(np.mean(losses)) if losses else 0.0
    if avg_loss == 0:
        return 0.0
    return round((wr * avg_win - (1 - wr) * avg_loss) / avg_loss, 4)


def compute_rolling_wr_vs_backtest(
    trades: List[Dict[str, Any]],
    backtest_wr: float = 0.857,
    window: int = 30,
) -> Dict[str, Any]:
    """Compare a rolling live WR against backtest WR and flag drift/alarm status."""
    closed = _sorted_by_exit(trades)
    if not closed:
        return {
            "rolling_wr": 0.0,
            "backtest_wr": backtest_wr,
            "delta": -backtest_wr,
            "status": "alarm",
        }
    recent = closed[-window:]
    wins = sum(1 for t in recent if t.get("win") or (t.get("pnl_dollar") or 0) > 0)
    rolling_wr = wins / len(recent) if recent else 0.0
    delta = rolling_wr - backtest_wr
    abs_pp = abs(delta) * 100.0
    if abs_pp <= 10:
        status = "on-track"
    elif abs_pp <= 20:
        status = "drift"
    else:
        status = "alarm"
    return {
        "rolling_wr": round(rolling_wr, 4),
        "backtest_wr": round(float(backtest_wr), 4),
        "delta": round(delta, 4),
        "status": status,
    }


def compute_unique_trades(runs: List[Dict[str, Any]]) -> int:
    """Count distinct tickers across all runs (dedup)."""
    tickers = set()
    for run in runs or []:
        for t in run.get("trades", []) or []:
            tk = t.get("ticker")
            if tk:
                tickers.add(str(tk).upper())
        for tk in run.get("tickers", []) or []:
            if tk:
                tickers.add(str(tk).upper())
    return len(tickers)
