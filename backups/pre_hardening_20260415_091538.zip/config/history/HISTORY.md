# SwingTrade Config Change History

Append-only log of profile switches.

## 2026-04-15 08:21:26 PDT — switched to `industry_standard`

**Note:** dropped 85% WR lock 2026-04-15, moving to industry-standard swing targets

**Backup:** `config/history/config_backup_20260415_082126.json`

| Key | Before | After |
|---|---|---|
| `decisions.buy_min_score` | `65` | `58` |
| `decisions.buy_min_rr` | `3.0` | `2.0` |
| `decisions.watch_min_score` | `50` | `45` |
| `decisions.avoid_below` | `50` | `40` |
| `regime_thresholds.bull.buy_min_score` | `60` | `58` |
| `regime_thresholds.bull.watch_min_score` | `48` | `45` |
| `regime_thresholds.bull.rs_min` | `75` | `60` |
| `regime_thresholds.bull.rr_min` | `2.5` | `2.0` |
| `regime_thresholds.neutral.buy_min_score` | `62` | `58` |
| `regime_thresholds.neutral.watch_min_score` | `50` | `45` |
| `regime_thresholds.neutral.rs_min` | `75` | `60` |
| `regime_thresholds.neutral.rr_min` | `2.5` | `2.0` |
| `regime_thresholds.neutral.high_vix_extra_score` | `8` | `6` |
| `regime_thresholds.bear.buy_min_score` | `68` | `65` |
| `regime_thresholds.bear.watch_min_score` | `60` | `55` |
| `regime_thresholds.bear.rs_min` | `75` | `70` |
| `regime_thresholds.bear.rr_min` | `4.0` | `3.0` |
| `regime_thresholds.bear.high_vix_extra_score` | `10` | `8` |
| `regime4_thresholds.risk_on_trending.buy_min_score` | `65` | `58` |
| `regime4_thresholds.risk_on_trending.rs_min` | `80` | `65` |
| `regime4_thresholds.risk_on_trending.rr_min` | `3.0` | `2.0` |
| `regime4_thresholds.risk_on_choppy.buy_min_score` | `72` | `60` |
| `regime4_thresholds.risk_on_choppy.rs_min` | `75` | `60` |
| `regime4_thresholds.risk_on_choppy.rr_min` | `3.0` | `2.0` |
| `regime4_thresholds.risk_off_trending.buy_min_score` | `78` | `70` |
| `regime4_thresholds.risk_off_trending.rs_min` | `80` | `70` |
| `regime4_thresholds.risk_off_trending.rr_min` | `4.0` | `3.0` |
